# Privacy inspector: collects facts about this PC. This script ONLY READS; it changes nothing
# and sends nothing anywhere. The app turns these facts into the report.
param([string]$InputFile, [string]$OutputFile)

$ErrorActionPreference = 'Stop'
$out = @{
    ok = $true; errors = @(); registry = @{}; permissions = @{}; startup = @(); programs = @()
    appx = @(); processes = @(); connections = @(); dns = @(); system = @{}
}

function Invoke-Section([string]$name, [scriptblock]$body) {
    try { & $body } catch { $script:out.errors += ($name + ': ' + [string]$_.Exception.Message) }
}

function Read-RegValue([string]$hive, [string]$path, [string]$name) {
    $result = @{ exists = $false; kind = ''; value = $null }
    try {
        $key = $hive + ':\' + $path
        if (Test-Path -LiteralPath $key) {
            $item = Get-Item -LiteralPath $key
            if ($item.GetValueNames() -contains $name) {
                $result.exists = $true
                $result.kind = [string]$item.GetValueKind($name)
                $result.value = $item.GetValue($name)
            }
        }
    } catch { }
    return $result
}

function ConvertTo-UnixMs($fileTime) {
    $value = [long]$fileTime
    if ($value -le 0) { return 0 }
    return [long](($value - 116444736000000000) / 10000)
}

function Get-AppAccess($key, [bool]$packaged) {
    $start = $key.GetValue('LastUsedTimeStart', 0)
    $stop = $key.GetValue('LastUsedTimeStop', 0)
    return @{
        name = [string]$key.PSChildName
        packaged = $packaged
        value = [string]$key.GetValue('Value', '')
        lastUsed = (ConvertTo-UnixMs $stop)
        inUse = (([long]$start -gt 0) -and ([long]$stop -eq 0))
    }
}

# 1) Windows privacy settings listed in the app's database
Invoke-Section 'registry' {
    $in = [System.IO.File]::ReadAllText($InputFile) | ConvertFrom-Json
    foreach ($check in @($in.checks)) {
        if (($check.hive -ne 'HKCU') -and ($check.hive -ne 'HKLM')) { continue }
        $out.registry[[string]$check.id] = Read-RegValue ([string]$check.hive) ([string]$check.path) ([string]$check.name)
    }
}

# 2) Which apps may use the camera, microphone, location and contacts
Invoke-Section 'permissions' {
    foreach ($cap in 'webcam', 'microphone', 'location', 'contacts') {
        $base = 'Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\' + $cap
        $apps = New-Object System.Collections.ArrayList
        $root = 'HKCU:\' + $base
        if (Test-Path -LiteralPath $root) {
            foreach ($sub in @(Get-ChildItem -LiteralPath $root -ErrorAction SilentlyContinue)) {
                if ($sub.PSChildName -eq 'NonPackaged') {
                    foreach ($desktopApp in @(Get-ChildItem -LiteralPath $sub.PSPath -ErrorAction SilentlyContinue)) {
                        [void]$apps.Add((Get-AppAccess $desktopApp $false))
                    }
                } else {
                    [void]$apps.Add((Get-AppAccess $sub $true))
                }
            }
        }
        $out.permissions[$cap] = @{
            user = [string](Read-RegValue 'HKCU' $base 'Value').value
            device = [string](Read-RegValue 'HKLM' $base 'Value').value
            apps = @($apps)
        }
    }
}

# 3) Programs that start with Windows
Invoke-Section 'startup' {
    $out.startup = @(Get-CimInstance -ClassName Win32_StartupCommand | ForEach-Object {
        @{ name = [string]$_.Name; command = [string]$_.Command; location = [string]$_.Location; user = [string]$_.User }
    })
}

# 4) Installed programs
Invoke-Section 'programs' {
    $seen = @{}
    $list = New-Object System.Collections.ArrayList
    $roots = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
             'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall',
             'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall'
    foreach ($root in $roots) {
        if (-not (Test-Path -LiteralPath $root)) { continue }
        foreach ($key in @(Get-ChildItem -LiteralPath $root -ErrorAction SilentlyContinue)) {
            $name = [string]$key.GetValue('DisplayName', '')
            if (-not $name) { continue }
            if ($key.GetValue('SystemComponent', 0) -eq 1) { continue }
            if ($seen.ContainsKey($name)) { continue }
            $seen[$name] = $true
            [void]$list.Add(@{ name = $name; publisher = [string]$key.GetValue('Publisher', ''); version = [string]$key.GetValue('DisplayVersion', '') })
        }
    }
    $out.programs = @($list)
}

Invoke-Section 'appx' {
    $out.appx = @(Get-AppxPackage | ForEach-Object { [string]$_.Name } | Select-Object -Unique)
}

# 5) Running programs (for "heavy background apps")
Invoke-Section 'processes' {
    $out.processes = @(Get-Process | ForEach-Object {
        $path = ''
        try { $path = [string]$_.Path } catch { $path = '' }
        @{ id = [int]$_.Id; name = [string]$_.ProcessName; ws = [long]$_.WorkingSet64; window = [bool]$_.MainWindowTitle; path = $path }
    })
}

# 6) Open internet connections, and the names Windows recently looked up (to name the addresses)
Invoke-Section 'connections' {
    $out.connections = @(Get-NetTCPConnection -State Established -ErrorAction SilentlyContinue |
        Where-Object { $_.RemoteAddress -notmatch '^(127\.|0\.0\.0\.0$|::1$|::$)' } |
        ForEach-Object { @{ pid = [int]$_.OwningProcess; remote = [string]$_.RemoteAddress; port = [int]$_.RemotePort } })
}

Invoke-Section 'dns' {
    $out.dns = @(Get-DnsClientCache -ErrorAction SilentlyContinue |
        Where-Object { ($_.Type -eq 1) -or ($_.Type -eq 28) } |
        ForEach-Object { @{ name = [string]$_.Entry; ip = [string]$_.Data } })
}

Invoke-Section 'system' {
    $os = Get-CimInstance -ClassName Win32_OperatingSystem
    $out.system = @{ caption = [string]$os.Caption; build = [string]$os.BuildNumber }
}

[System.IO.File]::WriteAllText($OutputFile, ($out | ConvertTo-Json -Depth 6 -Compress))
