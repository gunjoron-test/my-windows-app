# Clipboard and browser cleaner.
#   mode "scan"   ONLY READS: lists what could be deleted and how large it is (the preview).
#   mode "apply"  deletes exactly the items the user ticked, after the app asked for confirmation.
#
# Safety rules:
#   * Only known browser folders of the current user are touched; folder names are taken from
#     the disk, never from the request, so no other path can be deleted.
#   * A browser that is running is skipped (its files are in use); no program is ever closed.
#   * Bookmarks, saved passwords and extensions are never touched. Firefox keeps history and
#     bookmarks in one file, so Firefox history is NOT deleted here.
param([string]$InputFile, [string]$OutputFile)

$ErrorActionPreference = 'Stop'
$out = @{ ok = $false; message = ''; browsers = @(); results = @(); clipboard = @{ requested = $false; cleared = $false; history = $false } }

function Get-Browsers {
    $local = $env:LOCALAPPDATA
    $roaming = $env:APPDATA
    return @(
        @{ id = 'chrome'; name = 'Google Chrome'; process = 'chrome'; kind = 'chromium'; root = (Join-Path $local 'Google\Chrome\User Data'); cacheRoot = '' },
        @{ id = 'edge'; name = 'Microsoft Edge'; process = 'msedge'; kind = 'chromium'; root = (Join-Path $local 'Microsoft\Edge\User Data'); cacheRoot = '' },
        @{ id = 'brave'; name = 'Brave'; process = 'brave'; kind = 'chromium'; root = (Join-Path $local 'BraveSoftware\Brave-Browser\User Data'); cacheRoot = '' },
        @{ id = 'firefox'; name = 'Mozilla Firefox'; process = 'firefox'; kind = 'firefox'; root = (Join-Path $roaming 'Mozilla\Firefox\Profiles'); cacheRoot = (Join-Path $local 'Mozilla\Firefox\Profiles') }
    )
}

function Get-ProfileNames($browser) {
    if (-not (Test-Path -LiteralPath $browser.root)) { return @() }
    $folders = @(Get-ChildItem -LiteralPath $browser.root -Directory -ErrorAction SilentlyContinue)
    if ($browser.kind -eq 'chromium') {
        return @($folders | Where-Object {
            (($_.Name -eq 'Default') -or ($_.Name -like 'Profile *')) -and (Test-Path -LiteralPath (Join-Path $_.FullName 'Preferences'))
        } | ForEach-Object { [string]$_.Name })
    }
    return @($folders | ForEach-Object { [string]$_.Name })
}

function Get-Kinds($browser) {
    if ($browser.kind -eq 'chromium') { return @('cookies', 'history', 'cache') }
    return @('cookies', 'cache')
}

function Get-TargetPaths($browser, [string]$profileName, [string]$kind) {
    $base = Join-Path $browser.root $profileName
    $names = @()
    if ($browser.kind -eq 'chromium') {
        if ($kind -eq 'cookies') { $names = @('Network\Cookies', 'Network\Cookies-journal') }
        elseif ($kind -eq 'history') { $names = @('History', 'History-journal', 'Visited Links', 'Top Sites', 'Top Sites-journal') }
        elseif ($kind -eq 'cache') { $names = @('Cache', 'Code Cache') }
        return @($names | ForEach-Object { Join-Path $base $_ })
    }
    if ($kind -eq 'cookies') { return @('cookies.sqlite', 'cookies.sqlite-wal', 'cookies.sqlite-shm' | ForEach-Object { Join-Path $base $_ }) }
    if ($kind -eq 'cache') { return @(Join-Path (Join-Path $browser.cacheRoot $profileName) 'cache2') }
    return @()
}

function Get-PathSize([string]$path) {
    if (-not (Test-Path -LiteralPath $path)) { return [long]0 }
    $item = Get-Item -LiteralPath $path -Force
    if ($item.PSIsContainer) {
        $sum = (Get-ChildItem -LiteralPath $path -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
        if ($sum) { return [long]$sum }
        return [long]0
    }
    return [long]$item.Length
}

function Test-Running($browser) {
    return (@(Get-Process -Name $browser.process -ErrorAction SilentlyContinue).Count -gt 0)
}

try {
    $in = [System.IO.File]::ReadAllText($InputFile) | ConvertFrom-Json
    $mode = [string]$in.mode
    $browsers = Get-Browsers

    if ($mode -eq 'scan') {
        $found = @()
        foreach ($browser in $browsers) {
            $profiles = @()
            foreach ($profileName in @(Get-ProfileNames $browser)) {
                $items = @()
                foreach ($kind in @(Get-Kinds $browser)) {
                    $bytes = [long]0
                    foreach ($path in @(Get-TargetPaths $browser $profileName $kind)) { $bytes += (Get-PathSize $path) }
                    $items += @{ kind = $kind; bytes = $bytes }
                }
                $profiles += @{ name = $profileName; items = @($items) }
            }
            if ($profiles.Count -gt 0) {
                $found += @{ id = $browser.id; name = $browser.name; running = (Test-Running $browser); profiles = @($profiles) }
            }
        }
        $out.browsers = @($found)
    }
    elseif ($mode -eq 'apply') {
        $results = @()
        foreach ($target in @($in.targets)) {
            $browser = $browsers | Where-Object { $_.id -eq [string]$target.browser } | Select-Object -First 1
            $entry = @{ browser = [string]$target.browser; profile = [string]$target.profile; kind = [string]$target.kind; ok = $false; freed = [long]0; message = '' }
            if (-not $browser) { $entry.message = 'unknown-browser'; $results += $entry; continue }
            # The profile and the kind must be ones that really exist for this browser.
            if (@(Get-ProfileNames $browser) -notcontains [string]$target.profile) { $entry.message = 'unknown-profile'; $results += $entry; continue }
            if (@(Get-Kinds $browser) -notcontains [string]$target.kind) { $entry.message = 'unknown-kind'; $results += $entry; continue }
            if (Test-Running $browser) { $entry.message = 'running'; $results += $entry; continue }

            $failed = $false
            foreach ($path in @(Get-TargetPaths $browser ([string]$target.profile) ([string]$target.kind))) {
                if (-not (Test-Path -LiteralPath $path)) { continue }
                $size = Get-PathSize $path
                try {
                    Remove-Item -LiteralPath $path -Recurse -Force
                    $entry.freed = [long]$entry.freed + $size
                } catch {
                    $failed = $true
                    $entry.message = [string]$_.Exception.Message
                }
            }
            $entry.ok = (-not $failed)
            $results += $entry
        }
        $out.results = @($results)

        if ([bool]$in.clipboard) {
            $out.clipboard.requested = $true
            try {
                Add-Type -AssemblyName System.Windows.Forms
                [System.Windows.Forms.Clipboard]::Clear()
                $out.clipboard.cleared = $true
            } catch { }
            try {
                $null = [Windows.ApplicationModel.DataTransfer.Clipboard, Windows.ApplicationModel.DataTransfer, ContentType = WindowsRuntime]
                $out.clipboard.history = [bool][Windows.ApplicationModel.DataTransfer.Clipboard]::ClearHistory()
            } catch { }
        }
    }
    else { throw 'Unknown mode.' }

    $out.ok = $true
} catch {
    $out.message = [string]$_.Exception.Message
}

[System.IO.File]::WriteAllText($OutputFile, ($out | ConvertTo-Json -Depth 7 -Compress))
