# Startup manager: switches one startup entry on or off, exactly like Task Manager does
# (a value in the "StartupApproved" registry key). The program and its own startup entry are
# not touched, so this is always reversible. Entries for all users need administrator rights.
# When run with administrator rights the input arrives as $InputJson (not from a file).
param([string]$InputFile, [string]$OutputFile, [string]$InputJson)

$ErrorActionPreference = 'Stop'
$out = @{ ok = $false; message = '' }

try {
    $raw = $InputJson
    if (-not $raw) { $raw = [System.IO.File]::ReadAllText($InputFile) }
    $in = $raw | ConvertFrom-Json
    $scope = [string]$in.scope
    $approvedKey = [string]$in.approvedKey
    $name = [string]$in.name
    if (@('HKCU', 'HKLM') -notcontains $scope) { throw 'Invalid scope.' }
    if (@('Run', 'Run32', 'StartupFolder') -notcontains $approvedKey) { throw 'Invalid key.' }
    if ([string]::IsNullOrWhiteSpace($name) -or $name.Length -gt 260) { throw 'Invalid name.' }

    $key = $scope + ':\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\' + $approvedKey
    if (-not (Test-Path -LiteralPath $key)) { New-Item -Path $key -Force | Out-Null }

    $bytes = New-Object byte[] 12
    if ([bool]$in.enable) {
        $bytes[0] = 2
    } else {
        $bytes[0] = 3
        $stamp = [BitConverter]::GetBytes([DateTime]::UtcNow.ToFileTimeUtc())
        [Array]::Copy($stamp, 0, $bytes, 4, 8)
    }
    New-ItemProperty -LiteralPath $key -Name $name -PropertyType Binary -Value $bytes -Force | Out-Null
    $out.ok = $true
} catch {
    $out.message = [string]$_.Exception.Message
}

[System.IO.File]::WriteAllText($OutputFile, ($out | ConvertTo-Json -Compress))
