# Junk file cleaner.
#   mode "scan"   ONLY READS: what could be deleted in each category, and how much space.
#   mode "clean"  deletes the files of the categories the user ticked (after confirmation).
#
# Safety rules:
#   * Only a fixed list of cache/temporary folders inside the current user's
#     AppData\Local folder is used. Paths never come from the request.
#   * Personal folders (Documents, Desktop, Downloads, Pictures ...), system folders and
#     the Recycle Bin are never touched.
#   * Links/junctions are never followed. Files in use are skipped.
#   * Temporary files younger than 7 days are kept (like Windows Disk Cleanup does), because
#     an installer or a running program may still need them.
param([string]$InputFile, [string]$OutputFile)

$ErrorActionPreference = 'Stop'
$out = @{ ok = $false; message = ''; categories = @() }
$local = [System.IO.Path]::GetFullPath($env:LOCALAPPDATA).TrimEnd('\')
$maxFiles = 200000

function Get-Categories {
    return @(
        @{ id = 'temp'; root = $env:TEMP; pattern = '*'; minAgeHours = 168; dirs = $true },
        @{ id = 'inetcache'; root = (Join-Path $local 'Microsoft\Windows\INetCache'); pattern = '*'; minAgeHours = 0; dirs = $false },
        @{ id = 'thumbs'; root = (Join-Path $local 'Microsoft\Windows\Explorer'); pattern = 'thumbcache_*.db'; minAgeHours = 0; dirs = $false },
        @{ id = 'wer'; root = (Join-Path $local 'Microsoft\Windows\WER'); pattern = '*'; minAgeHours = 0; dirs = $true },
        @{ id = 'dumps'; root = (Join-Path $local 'CrashDumps'); pattern = '*'; minAgeHours = 0; dirs = $false },
        @{ id = 'shader'; root = (Join-Path $local 'D3DSCache'); pattern = '*'; minAgeHours = 0; dirs = $true }
    )
}

# The folder must exist, be inside AppData\Local, and not be AppData\Local itself.
function Test-SafeRoot([string]$root) {
    if (-not $root) { return $false }
    try { $full = [System.IO.Path]::GetFullPath($root).TrimEnd('\') } catch { return $false }
    if (-not $full.StartsWith($local + '\', [StringComparison]::OrdinalIgnoreCase)) { return $false }
    if (-not [System.IO.Directory]::Exists($full)) { return $false }
    $info = New-Object System.IO.DirectoryInfo($full)
    return (($info.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -eq 0)
}

# Walks the folder without following links; returns files and the sub-folders seen.
function Get-JunkFiles([string]$root, [string]$pattern, [int]$minAgeHours) {
    $cutoff = (Get-Date).AddHours(-$minAgeHours)
    $files = New-Object System.Collections.ArrayList
    $dirs = New-Object System.Collections.ArrayList
    $stack = New-Object System.Collections.Stack
    $stack.Push((New-Object System.IO.DirectoryInfo($root)))
    while ($stack.Count -gt 0 -and $files.Count -lt $maxFiles) {
        $dir = $stack.Pop()
        try { $entries = $dir.GetFileSystemInfos() } catch { continue }
        foreach ($entry in $entries) {
            if (($entry.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) { continue }
            if ($entry -is [System.IO.DirectoryInfo]) {
                # The object keeps the folder's date as it was before anything is deleted.
                [void]$dirs.Add($entry)
                $stack.Push($entry)
            } elseif ($entry.Name -like $pattern -and $entry.LastWriteTime -lt $cutoff) {
                [void]$files.Add($entry)
            }
        }
    }
    return @{ files = $files; dirs = $dirs }
}

try {
    $in = [System.IO.File]::ReadAllText($InputFile) | ConvertFrom-Json
    $mode = [string]$in.mode
    $wanted = @($in.categories | ForEach-Object { [string]$_ })
    $results = @()

    foreach ($cat in Get-Categories) {
        if ($mode -eq 'clean' -and $wanted -notcontains $cat.id) { continue }
        $entry = @{ id = $cat.id; available = $false; files = 0; bytes = [long]0; samples = @(); deleted = 0; failed = 0; freed = [long]0 }
        if (-not (Test-SafeRoot $cat.root)) { $results += $entry; continue }
        $entry.available = $true
        $rootFull = (New-Object System.IO.DirectoryInfo($cat.root)).FullName.TrimEnd('\')
        $found = Get-JunkFiles $rootFull $cat.pattern $cat.minAgeHours

        if ($mode -eq 'scan') {
            $entry.files = $found.files.Count
            $sum = [long]0
            foreach ($f in $found.files) { $sum += [long]$f.Length }
            $entry.bytes = $sum
            $entry.samples = @($found.files | Sort-Object Length -Descending | Select-Object -First 8 | ForEach-Object { $_.FullName.Substring($rootFull.Length).TrimStart('\') })
        }
        elseif ($mode -eq 'clean') {
            foreach ($f in $found.files) {
                try {
                    $size = [long]$f.Length
                    $f.Attributes = [System.IO.FileAttributes]::Normal
                    $f.Delete()
                    $entry.deleted++
                    $entry.freed += $size
                } catch { $entry.failed++ }
            }
            if ($cat.dirs) {
                # Empty sub-folders are removed, deepest first; the category folder itself stays.
                $cutoff = (Get-Date).AddHours(-$cat.minAgeHours)
                foreach ($info in @($found.dirs | Sort-Object { $_.FullName.Length } -Descending)) {
                    try {
                        if ($info.LastWriteTime -lt $cutoff -and @($info.GetFileSystemInfos()).Count -eq 0) { $info.Delete() }
                    } catch { }
                }
            }
        }
        else { throw 'Unknown mode.' }
        $results += $entry
    }
    $out.categories = @($results)
    $out.ok = $true
} catch {
    $out.message = [string]$_.Exception.Message
}

[System.IO.File]::WriteAllText($OutputFile, ($out | ConvertTo-Json -Depth 5 -Compress))
