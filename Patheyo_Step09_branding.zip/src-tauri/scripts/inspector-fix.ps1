# Privacy inspector: changes ONE setting of the current user (HKEY_CURRENT_USER only, no
# administrator rights) or puts it back. The value that was there before is returned, so the
# app can undo the change exactly.
param([string]$InputFile, [string]$OutputFile)

$ErrorActionPreference = 'Stop'
$out = @{ ok = $false; message = ''; before = $null }

try {
    $in = [System.IO.File]::ReadAllText($InputFile) | ConvertFrom-Json
    $path = [string]$in.path
    $name = [string]$in.name
    if ([string]::IsNullOrWhiteSpace($path) -or $path.StartsWith('\') -or $path.Contains('..') -or $path.Contains(':') -or [string]::IsNullOrWhiteSpace($name)) {
        throw 'Invalid registry location.'
    }
    $key = 'HKCU:\' + $path

    function Write-Value([string]$kind, $value) {
        if (-not (Test-Path -LiteralPath $key)) { New-Item -Path $key -Force | Out-Null }
        if ($kind -eq 'dword') {
            New-ItemProperty -LiteralPath $key -Name $name -PropertyType DWord -Value ([int]$value) -Force | Out-Null
        } elseif ($kind -eq 'string') {
            New-ItemProperty -LiteralPath $key -Name $name -PropertyType String -Value ([string]$value) -Force | Out-Null
        } else {
            throw 'Unsupported value type.'
        }
    }

    if ($in.mode -eq 'apply') {
        $before = @{ exists = $false; kind = ''; value = $null }
        if (Test-Path -LiteralPath $key) {
            $item = Get-Item -LiteralPath $key
            if ($item.GetValueNames() -contains $name) {
                $kind = [string]$item.GetValueKind($name)
                if ($kind -eq 'DWord') {
                    $before = @{ exists = $true; kind = 'dword'; value = [int]$item.GetValue($name) }
                } elseif ($kind -eq 'String') {
                    $before = @{ exists = $true; kind = 'string'; value = [string]$item.GetValue($name) }
                } else {
                    throw 'The existing value has an unexpected type, so it was left alone.'
                }
            }
        }
        Write-Value ([string]$in.kind) $in.value
        $out.before = $before
        $out.ok = $true
    }
    elseif ($in.mode -eq 'undo') {
        if ($in.before.exists) {
            Write-Value ([string]$in.before.kind) $in.before.value
        } elseif (Test-Path -LiteralPath $key) {
            Remove-ItemProperty -LiteralPath $key -Name $name -ErrorAction SilentlyContinue
        }
        $out.ok = $true
    }
    else { throw 'Unknown mode.' }
} catch {
    $out.message = [string]$_.Exception.Message
}

[System.IO.File]::WriteAllText($OutputFile, ($out | ConvertTo-Json -Depth 4 -Compress))
