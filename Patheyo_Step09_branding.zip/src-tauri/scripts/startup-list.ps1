# Startup manager: lists the programs that start with Windows. ONLY READS.
# The on/off state is the same one Task Manager uses (the "StartupApproved" registry keys).
param([string]$InputFile, [string]$OutputFile)

$ErrorActionPreference = 'Stop'
$out = @{ ok = $false; message = ''; items = @() }
$approvedBase = 'Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\'

function Test-Enabled([string]$hive, [string]$approvedKey, [string]$name) {
    try {
        $key = $hive + ':\' + $approvedBase + $approvedKey
        if (-not (Test-Path -LiteralPath $key)) { return $true }
        $item = Get-Item -LiteralPath $key
        if ($item.GetValueNames() -notcontains $name) { return $true }
        $bytes = [byte[]]$item.GetValue($name)
        if (-not $bytes -or $bytes.Length -eq 0) { return $true }
        return (($bytes[0] -band 1) -eq 0)   # even first byte = enabled, odd = disabled
    } catch { return $true }
}

function Get-ExePath([string]$command) {
    $c = ([string]$command).Trim()
    if (-not $c) { return '' }
    if ($c.StartsWith('"')) {
        $end = $c.IndexOf('"', 1)
        if ($end -gt 1) { return [Environment]::ExpandEnvironmentVariables($c.Substring(1, $end - 1)) }
    }
    $i = $c.ToLower().IndexOf('.exe')
    if ($i -gt 0) { return [Environment]::ExpandEnvironmentVariables($c.Substring(0, $i + 4)) }
    return [Environment]::ExpandEnvironmentVariables(($c -split ' ')[0])
}

function Get-Publisher([string]$path) {
    try {
        if ($path -and (Test-Path -LiteralPath $path -PathType Leaf)) { return [string](Get-Item -LiteralPath $path).VersionInfo.CompanyName }
    } catch { }
    return ''
}

try {
    # Memory used right now by each running program (used for the estimated impact).
    $memory = @{}
    foreach ($p in @(Get-Process -ErrorAction SilentlyContinue)) {
        $path = ''
        try { $path = [string]$p.Path } catch { $path = '' }
        if (-not $path) { continue }
        $key = $path.ToLower()
        if ($memory.ContainsKey($key)) { $memory[$key] += [long]$p.WorkingSet64 } else { $memory[$key] = [long]$p.WorkingSet64 }
    }

    $list = New-Object System.Collections.ArrayList
    function Add-Item([string]$scope, [string]$approvedKey, [string]$source, [string]$name, [string]$command, [string]$path) {
        $mem = [long]0
        if ($path -and $memory.ContainsKey($path.ToLower())) { $mem = $memory[$path.ToLower()] }
        $impact = 'unknown'
        if ($mem -ge 200MB) { $impact = 'high' } elseif ($mem -ge 50MB) { $impact = 'medium' } elseif ($mem -gt 0) { $impact = 'low' }
        [void]$list.Add(@{
            scope = $scope; approvedKey = $approvedKey; source = $source; name = $name
            command = $command; path = $path; publisher = (Get-Publisher $path)
            exists = [bool]($path -and (Test-Path -LiteralPath $path -PathType Leaf))
            enabled = (Test-Enabled $scope $approvedKey $name)
            memory = $mem; impact = $impact
        })
    }

    $runKeys = @(
        @{ hive = 'HKCU'; path = 'Software\Microsoft\Windows\CurrentVersion\Run'; approved = 'Run'; source = 'user' },
        @{ hive = 'HKLM'; path = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Run'; approved = 'Run'; source = 'all' },
        @{ hive = 'HKLM'; path = 'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run'; approved = 'Run32'; source = 'all' }
    )
    foreach ($rk in $runKeys) {
        $key = $rk.hive + ':\' + $rk.path
        if (-not (Test-Path -LiteralPath $key)) { continue }
        $item = Get-Item -LiteralPath $key
        foreach ($name in @($item.GetValueNames())) {
            if (-not $name) { continue }
            $command = [string]$item.GetValue($name)
            Add-Item $rk.hive $rk.approved $rk.source $name $command (Get-ExePath $command)
        }
    }

    $shell = New-Object -ComObject WScript.Shell
    $folders = @(
        @{ hive = 'HKCU'; path = [Environment]::GetFolderPath('Startup'); source = 'userFolder' },
        @{ hive = 'HKLM'; path = [Environment]::GetFolderPath('CommonStartup'); source = 'allFolder' }
    )
    foreach ($f in $folders) {
        if (-not $f.path -or -not (Test-Path -LiteralPath $f.path)) { continue }
        foreach ($file in @(Get-ChildItem -LiteralPath $f.path -File -ErrorAction SilentlyContinue)) {
            if ($file.Name -eq 'desktop.ini') { continue }
            $command = $file.FullName
            $path = $file.FullName
            if ($file.Extension -eq '.lnk') {
                try {
                    $link = $shell.CreateShortcut($file.FullName)
                    $path = [string]$link.TargetPath
                    $command = ([string]$link.TargetPath + ' ' + [string]$link.Arguments).Trim()
                } catch { }
            }
            Add-Item $f.hive 'StartupFolder' $f.source $file.Name $command $path
        }
    }

    $out.items = @($list)
    $out.ok = $true
} catch {
    $out.message = [string]$_.Exception.Message
}

[System.IO.File]::WriteAllText($OutputFile, ($out | ConvertTo-Json -Depth 5 -Compress))
