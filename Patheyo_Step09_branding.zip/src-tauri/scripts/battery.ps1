# Battery report: charge level and battery health (laptops). ONLY READS.
# Health comes from the Windows battery report (powercfg), as XML, read in memory.
param([string]$InputFile, [string]$OutputFile)

$ErrorActionPreference = 'Stop'
$out = @{ ok = $false; message = ''; hasBattery = $false; charge = $null; status = $null; runtime = $null; batteries = @() }

try {
    $list = @(Get-CimInstance -ClassName Win32_Battery -ErrorAction SilentlyContinue)
    if ($list.Count -gt 0) {
        $out.hasBattery = $true
        $first = $list[0]
        $out.charge = [int]$first.EstimatedChargeRemaining
        $out.status = [int]$first.BatteryStatus
        $run = [long]$first.EstimatedRunTime
        if ($run -gt 0 -and $run -lt 71582788) { $out.runtime = $run }   # 71582788 = charging / unknown

        $xmlFile = Join-Path ([System.IO.Path]::GetTempPath()) ('nd-battery-' + [Guid]::NewGuid().ToString('N') + '.xml')
        try {
            & powercfg.exe /batteryreport /xml /output $xmlFile | Out-Null
            if (Test-Path -LiteralPath $xmlFile) {
                [xml]$doc = [System.IO.File]::ReadAllText($xmlFile)
                $found = @()
                foreach ($b in @($doc.BatteryReport.Batteries.Battery)) {
                    if (-not $b) { continue }
                    $found += @{
                        id = [string]$b.Id
                        manufacturer = [string]$b.Manufacturer
                        chemistry = [string]$b.Chemistry
                        design = [long]$b.DesignCapacity
                        full = [long]$b.FullChargeCapacity
                        cycles = [long]$b.CycleCount
                    }
                }
                $out.batteries = @($found)
            }
        } catch {
            $out.message = 'report: ' + [string]$_.Exception.Message
        } finally {
            Remove-Item -LiteralPath $xmlFile -Force -ErrorAction SilentlyContinue
        }
    }
    $out.ok = $true
} catch {
    $out.message = [string]$_.Exception.Message
}

[System.IO.File]::WriteAllText($OutputFile, ($out | ConvertTo-Json -Depth 5 -Compress))
