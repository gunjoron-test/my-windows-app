; Patheyo (PC) installer hooks (included by the Tauri NSIS installer).
;
; Before uninstalling, everything the app changed outside its own folder is put back:
;   * "Start with Windows" entry
;   * DNS setting changed by the ad blocker (adapters that point to this PC go back to automatic)
;   * firewall rules created by the app (group "Patheyo"; also "NoorDesk", the app's earlier name)
; The last two need administrator rights, so Windows asks for permission once, and only if the
; app actually changed something.
;
; Nothing is done for silent runs, so that a newer version installed over this one keeps the
; user's settings and the ad blocker keeps working.

!macro NSIS_HOOK_PREUNINSTALL
  Push $R0
  IfSilent patheyo_cleanup_done

  DetailPrint "Patheyo: removing the 'Start with Windows' entry"
  DeleteRegValue HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "Patheyo"
  DeleteRegValue HKCU "Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run" "Patheyo"

  StrCpy $R0 "0"
  IfFileExists "$APPDATA\com.gunjoron.patheyo.desktop\dns-backup.json" 0 +2
    StrCpy $R0 "1"
  IfFileExists "$APPDATA\com.gunjoron.patheyo.desktop\firewall-history.json" 0 +2
    StrCpy $R0 "1"
  StrCmp $R0 "1" 0 patheyo_cleanup_done

  MessageBox MB_OK|MB_ICONINFORMATION "Patheyo changed network settings (ad blocker DNS and/or firewall rules).$\r$\n$\r$\nWindows will now ask for permission once, so that these settings can be put back before the app is removed." /SD IDOK
  DetailPrint "Patheyo: restoring the DNS setting and removing Patheyo firewall rules"
  ExecShellWait "runas" "powershell.exe" `-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command "Get-DnsClientServerAddress | Where-Object { ($$_.ServerAddresses -contains '127.0.0.1') -or ($$_.ServerAddresses -contains '::1') } | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $$_.InterfaceIndex -ResetServerAddresses }; Clear-DnsClientCache; Remove-NetFirewallRule -Group 'Patheyo' -ErrorAction SilentlyContinue; Remove-NetFirewallRule -Group 'NoorDesk' -ErrorAction SilentlyContinue"` SW_HIDE

  patheyo_cleanup_done:
  Pop $R0
!macroend
