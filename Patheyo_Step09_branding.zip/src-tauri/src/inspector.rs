//! Module D: privacy and tracking inspector.
//!
//! * Scanning only READS facts about the PC (a PowerShell script, run without administrator
//!   rights). The interface turns the facts into a report using the JSON databases in src/data.
//! * A fix changes exactly one value of the current user (HKEY_CURRENT_USER). Which value and
//!   what it is set to comes from the app's own database, never from the interface, so the
//!   window can only ask for fixes that are on the list.
//! * Every fix is recorded with the value that was there before, so it can be undone.

use std::fs;
use std::path::PathBuf;
use std::process::Command;
use std::sync::Mutex;
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::{json, Value};
use tauri::AppHandle;

use crate::{blocker, logging, paths};

/// The same database the interface shows (single source of truth).
const CHECKS_JSON: &str = include_str!("../../src/data/privacy-checks.json");
const SCAN_SCRIPT: &str = include_str!("../scripts/inspector-scan.ps1");
const FIX_SCRIPT: &str = include_str!("../scripts/inspector-fix.ps1");

const MAX_HISTORY: usize = 200;

/// Only one scan or fix runs at a time.
static WORK_LOCK: Mutex<()> = Mutex::new(());

fn now_ms() -> i64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as i64)
        .unwrap_or(0)
}

fn checks() -> Vec<Value> {
    serde_json::from_str::<Vec<Value>>(CHECKS_JSON).unwrap_or_default()
}

fn text_of<'a>(value: &'a Value, key: &str) -> &'a str {
    value.get(key).and_then(|v| v.as_str()).unwrap_or("")
}

fn work_dir(app: &AppHandle) -> PathBuf {
    let dir = paths::data_dir(app).join("inspector");
    let _ = fs::create_dir_all(&dir);
    dir
}

fn history_file(app: &AppHandle) -> PathBuf {
    paths::data_dir(app).join("inspector-history.json")
}

fn read_history(app: &AppHandle) -> Vec<Value> {
    fs::read_to_string(history_file(app))
        .ok()
        .and_then(|text| serde_json::from_str::<Vec<Value>>(&text).ok())
        .unwrap_or_default()
}

fn write_history(app: &AppHandle, history: &[Value]) -> Result<(), String> {
    let path = history_file(app);
    let temp = path.with_extension("json.tmp");
    let text = serde_json::to_string_pretty(history).map_err(|e| e.to_string())?;
    fs::write(&temp, text.as_bytes()).map_err(|e| e.to_string())?;
    fs::rename(&temp, &path).map_err(|e| e.to_string())
}

/// Runs one of the bundled scripts: writes it and its input to the app's own folder, runs it
/// without administrator rights, and reads the JSON it produced.
fn run_script(app: &AppHandle, name: &str, script: &str, input: &Value) -> Result<Value, String> {
    let dir = work_dir(app);
    let script_file = dir.join(format!("{}.ps1", name));
    let input_file = dir.join(format!("{}-in.json", name));
    let output_file = dir.join(format!("{}-out.json", name));
    let _ = fs::remove_file(&output_file);

    // The byte-order mark makes Windows PowerShell read the script as UTF-8.
    fs::write(&script_file, format!("\u{feff}{}", script).as_bytes()).map_err(|e| e.to_string())?;
    fs::write(&input_file, input.to_string().as_bytes()).map_err(|e| e.to_string())?;

    let mut command = Command::new("powershell.exe");
    command
        .args(["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File"])
        .arg(&script_file)
        .arg("-InputFile")
        .arg(&input_file)
        .arg("-OutputFile")
        .arg(&output_file);
    blocker::hide_window(&mut command);
    let status = command
        .status()
        .map_err(|e| format!("PowerShell could not be started: {}", e));

    let text = fs::read_to_string(&output_file);
    let _ = fs::remove_file(&script_file);
    let _ = fs::remove_file(&input_file);
    let _ = fs::remove_file(&output_file);

    status?;
    let text = text.map_err(|_| "The script produced no result".to_string())?;
    serde_json::from_str::<Value>(text.trim_start_matches('\u{feff}'))
        .map_err(|_| "The script result could not be read".to_string())
}

fn do_scan(app: &AppHandle) -> Result<Value, String> {
    let _guard = WORK_LOCK.lock().unwrap_or_else(|e| e.into_inner());
    let list: Vec<Value> = checks()
        .iter()
        .map(|c| {
            json!({
                "id": text_of(c, "id"),
                "hive": text_of(c, "hive"),
                "path": text_of(c, "path"),
                "name": text_of(c, "name"),
            })
        })
        .collect();
    let mut result = run_script(app, "scan", SCAN_SCRIPT, &json!({ "checks": list }))?;
    if let Some(object) = result.as_object_mut() {
        object.insert("scannedAt".to_string(), json!(now_ms()));
    }
    logging::write("INFO", "Privacy scan finished");
    Ok(result)
}

fn do_fix(app: &AppHandle, id: &str) -> Result<Vec<Value>, String> {
    let _guard = WORK_LOCK.lock().unwrap_or_else(|e| e.into_inner());

    let all = checks();
    let check = all
        .iter()
        .find(|c| text_of(c, "id") == id)
        .ok_or("Unknown fix")?;
    let new_value = check
        .get("fix")
        .and_then(|f| f.get("value"))
        .cloned()
        .ok_or("This item has no automatic fix")?;
    if text_of(check, "hive") != "HKCU" {
        return Err("Only settings of the current user can be changed automatically".into());
    }
    let path = text_of(check, "path").to_string();
    let name = text_of(check, "name").to_string();
    let kind = text_of(check, "kind").to_string();

    let result = run_script(
        app,
        "fix",
        FIX_SCRIPT,
        &json!({ "mode": "apply", "path": path, "name": name, "kind": kind, "value": new_value }),
    )?;
    if result.get("ok").and_then(|v| v.as_bool()) != Some(true) {
        return Err(text_of(&result, "message").to_string());
    }

    let mut history = read_history(app);
    let at = now_ms();
    history.push(json!({
        "entryId": format!("{}-{}", id, at),
        "checkId": id,
        "at": at,
        "path": path,
        "name": name,
        "kind": kind,
        "before": result.get("before").cloned().unwrap_or(Value::Null),
        "after": new_value,
        "undone": false,
    }));
    if history.len() > MAX_HISTORY {
        let extra = history.len() - MAX_HISTORY;
        history.drain(0..extra);
    }
    write_history(app, &history)?;
    logging::write("INFO", &format!("Privacy fix applied: {}", id));
    Ok(history)
}

fn do_undo(app: &AppHandle, entry_id: &str) -> Result<Vec<Value>, String> {
    let _guard = WORK_LOCK.lock().unwrap_or_else(|e| e.into_inner());

    let mut history = read_history(app);
    let index = history
        .iter()
        .position(|e| text_of(e, "entryId") == entry_id)
        .ok_or("This change is not in the history")?;
    if history[index].get("undone").and_then(|v| v.as_bool()) == Some(true) {
        return Err("This change was already undone".into());
    }

    let entry = history[index].clone();
    let result = run_script(
        app,
        "fix",
        FIX_SCRIPT,
        &json!({
            "mode": "undo",
            "path": text_of(&entry, "path"),
            "name": text_of(&entry, "name"),
            "before": entry.get("before").cloned().unwrap_or(Value::Null),
        }),
    )?;
    if result.get("ok").and_then(|v| v.as_bool()) != Some(true) {
        return Err(text_of(&result, "message").to_string());
    }

    if let Some(object) = history[index].as_object_mut() {
        object.insert("undone".to_string(), json!(true));
        object.insert("undoneAt".to_string(), json!(now_ms()));
    }
    write_history(app, &history)?;
    logging::write("INFO", &format!("Privacy fix undone: {}", entry_id));
    Ok(history)
}

/// Collects the facts for the report. Read-only.
#[tauri::command]
pub async fn inspector_scan(app: AppHandle) -> Result<Value, String> {
    tauri::async_runtime::spawn_blocking(move || do_scan(&app))
        .await
        .map_err(|e| e.to_string())?
}

/// Applies the fix of one database item. The interface asks the user to confirm first.
#[tauri::command]
pub async fn inspector_fix(app: AppHandle, id: String) -> Result<Vec<Value>, String> {
    tauri::async_runtime::spawn_blocking(move || do_fix(&app, &id))
        .await
        .map_err(|e| e.to_string())?
}

/// Puts back the value that was there before a fix.
#[tauri::command]
pub async fn inspector_undo(app: AppHandle, entry_id: String) -> Result<Vec<Value>, String> {
    tauri::async_runtime::spawn_blocking(move || do_undo(&app, &entry_id))
        .await
        .map_err(|e| e.to_string())?
}

#[tauri::command]
pub fn inspector_history(app: AppHandle) -> Vec<Value> {
    read_history(&app)
}

/// Opens one page of the Windows Settings app (addresses starting with "ms-settings:").
#[tauri::command]
pub fn open_windows_settings(uri: String) -> Result<(), String> {
    let valid = uri.len() <= 80
        && uri.starts_with("ms-settings:")
        && uri["ms-settings:".len()..]
            .chars()
            .all(|c| c.is_ascii_lowercase() || c.is_ascii_digit() || c == '-');
    if !valid {
        return Err("Not a Windows Settings address".into());
    }
    Command::new("explorer.exe")
        .arg(&uri)
        .spawn()
        .map_err(|e| e.to_string())?;
    Ok(())
}

/// Opens the Patheyo website in the default browser (a fixed address, nothing from the page).
#[tauri::command]
pub fn open_website() -> Result<(), String> {
    Command::new("explorer.exe")
        .arg("https://patheyobygunjoron.github.io/")
        .spawn()
        .map_err(|e| e.to_string())?;
    Ok(())
}
