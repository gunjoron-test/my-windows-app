//! Small Windows helpers for processes and windows, used by focus mode and screen time.
//! Plain Windows API calls; no extra crates.

#[cfg(windows)]
mod sys {
    use std::ffi::c_void;

    #[repr(C)]
    pub struct LastInputInfo {
        pub size: u32,
        pub time: u32,
    }

    #[link(name = "kernel32")]
    extern "system" {
        pub fn K32EnumProcesses(ids: *mut u32, bytes: u32, needed: *mut u32) -> i32;
        pub fn OpenProcess(access: u32, inherit_handle: i32, process_id: u32) -> *mut c_void;
        pub fn QueryFullProcessImageNameW(
            process: *mut c_void,
            flags: u32,
            name: *mut u16,
            size: *mut u32,
        ) -> i32;
        pub fn TerminateProcess(process: *mut c_void, exit_code: u32) -> i32;
        pub fn CloseHandle(handle: *mut c_void) -> i32;
        pub fn GetTickCount() -> u32;
    }

    #[link(name = "user32")]
    extern "system" {
        pub fn GetForegroundWindow() -> *mut c_void;
        pub fn GetWindowThreadProcessId(window: *mut c_void, process_id: *mut u32) -> u32;
        pub fn GetLastInputInfo(info: *mut LastInputInfo) -> i32;
    }
}

#[cfg(windows)]
const PROCESS_TERMINATE: u32 = 0x0001;
#[cfg(windows)]
const PROCESS_QUERY_LIMITED_INFORMATION: u32 = 0x1000;

/// Ids of all running processes.
#[cfg(windows)]
pub fn process_ids() -> Vec<u32> {
    let mut ids = vec![0u32; 4096];
    let mut needed: u32 = 0;
    let ok = unsafe {
        sys::K32EnumProcesses(ids.as_mut_ptr(), (ids.len() * 4) as u32, &mut needed)
    };
    if ok == 0 {
        return Vec::new();
    }
    ids.truncate((needed as usize / 4).min(ids.len()));
    ids.retain(|id| *id > 4);
    ids
}

/// Full path of the program file of a process, or None for protected system processes.
#[cfg(windows)]
pub fn process_path(process_id: u32) -> Option<String> {
    if process_id <= 4 {
        return None;
    }
    unsafe {
        let handle = sys::OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, process_id);
        if handle.is_null() {
            return None;
        }
        let mut buffer = [0u16; 1024];
        let mut length: u32 = buffer.len() as u32;
        let ok = sys::QueryFullProcessImageNameW(handle, 0, buffer.as_mut_ptr(), &mut length);
        sys::CloseHandle(handle);
        if ok == 0 || length == 0 {
            return None;
        }
        Some(String::from_utf16_lossy(&buffer[..length as usize]))
    }
}

/// Closes a program immediately (like "End task" in Task Manager). Returns true on success.
#[cfg(windows)]
pub fn terminate(process_id: u32) -> bool {
    if process_id <= 4 || process_id == std::process::id() {
        return false;
    }
    unsafe {
        let handle = sys::OpenProcess(PROCESS_TERMINATE, 0, process_id);
        if handle.is_null() {
            return false;
        }
        let ok = sys::TerminateProcess(handle, 1);
        sys::CloseHandle(handle);
        ok != 0
    }
}

/// Id of the process that owns the window the user is working in right now.
#[cfg(windows)]
pub fn foreground_process_id() -> Option<u32> {
    unsafe {
        let window = sys::GetForegroundWindow();
        if window.is_null() {
            return None;
        }
        let mut process_id: u32 = 0;
        sys::GetWindowThreadProcessId(window, &mut process_id);
        if process_id == 0 {
            None
        } else {
            Some(process_id)
        }
    }
}

/// Milliseconds since the user last touched the keyboard or mouse.
#[cfg(windows)]
pub fn idle_ms() -> u64 {
    unsafe {
        let mut info = sys::LastInputInfo {
            size: std::mem::size_of::<sys::LastInputInfo>() as u32,
            time: 0,
        };
        if sys::GetLastInputInfo(&mut info) == 0 {
            return 0;
        }
        sys::GetTickCount().wrapping_sub(info.time) as u64
    }
}

#[cfg(not(windows))]
pub fn process_ids() -> Vec<u32> {
    Vec::new()
}
#[cfg(not(windows))]
pub fn process_path(_process_id: u32) -> Option<String> {
    None
}
#[cfg(not(windows))]
pub fn terminate(_process_id: u32) -> bool {
    false
}
#[cfg(not(windows))]
pub fn foreground_process_id() -> Option<u32> {
    None
}
#[cfg(not(windows))]
pub fn idle_ms() -> u64 {
    0
}

/// "C:\Program Files\App\App.exe" -> "app.exe"
pub fn file_name_lower(path: &str) -> String {
    path.rsplit(|c: char| c == '\\' || c == '/')
        .next()
        .unwrap_or(path)
        .to_lowercase()
}
