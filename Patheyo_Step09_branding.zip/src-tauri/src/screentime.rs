//! Screen time: how long each program was in the foreground, per day.
//!
//! Only the program's name and seconds are stored (no window titles, no content), in
//! screentime.json in the app's own folder. Nothing is sent anywhere. Time while the user is
//! away (no keyboard or mouse for 2 minutes) is not counted. Off until the user switches it on.

use std::collections::BTreeMap;
use std::fs;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex, MutexGuard};
use std::thread;
use std::time::Duration;

use serde::{Deserialize, Serialize};
use serde_json::Value;
use tauri::{AppHandle, Manager};

use crate::{paths, winproc};

const TICK_SECONDS: u64 = 5;
const IDLE_LIMIT_MS: u64 = 120_000;
const KEEP_DAYS: usize = 31;
/// Unsaved seconds are written to disk at least this often.
const SAVE_EVERY_TICKS: u64 = 12;

#[derive(Default, Serialize, Deserialize)]
#[serde(default)]
struct Data {
    /// "2026-11-15" -> program name -> seconds
    days: BTreeMap<String, BTreeMap<String, u64>>,
}

pub struct ScreenTime {
    enabled: AtomicBool,
    dirty: AtomicBool,
    data: Mutex<Data>,
}

fn lock(st: &ScreenTime) -> MutexGuard<'_, Data> {
    st.data.lock().unwrap_or_else(|e| e.into_inner())
}

fn state(app: &AppHandle) -> Arc<ScreenTime> {
    app.state::<Arc<ScreenTime>>().inner().clone()
}

fn save(app: &AppHandle, st: &ScreenTime) {
    let text = {
        let data = lock(st);
        serde_json::to_string(&*data).unwrap_or_default()
    };
    st.dirty.store(false, Ordering::Relaxed);
    if text.is_empty() {
        return;
    }
    let path = paths::screentime_file(app);
    let temp = path.with_extension("json.tmp");
    if fs::write(&temp, text.as_bytes()).is_ok() {
        let _ = fs::rename(&temp, &path);
    }
}

/// "C:\...\Chrome.exe" -> "chrome"
fn program_name(path: &str) -> String {
    let name = winproc::file_name_lower(path);
    name.strip_suffix(".exe").unwrap_or(&name).chars().take(60).collect()
}

fn count_one_tick(st: &ScreenTime) {
    if winproc::idle_ms() > IDLE_LIMIT_MS {
        return;
    }
    let process_id = match winproc::foreground_process_id() {
        Some(id) => id,
        None => return,
    };
    let path = match winproc::process_path(process_id) {
        Some(path) => path,
        None => return,
    };
    let name = program_name(&path);
    if name.is_empty() {
        return;
    }
    let today = chrono::Local::now().format("%Y-%m-%d").to_string();
    let mut data = lock(st);
    *data
        .days
        .entry(today)
        .or_default()
        .entry(name)
        .or_insert(0) += TICK_SECONDS;
    while data.days.len() > KEEP_DAYS {
        let oldest = match data.days.keys().next() {
            Some(key) => key.clone(),
            None => break,
        };
        data.days.remove(&oldest);
    }
    st.dirty.store(true, Ordering::Relaxed);
}

/// Called once when the app starts.
pub fn start(app: &AppHandle) {
    let data: Data = fs::read_to_string(paths::screentime_file(app))
        .ok()
        .and_then(|text| serde_json::from_str::<Data>(&text).ok())
        .unwrap_or_default();
    let st = Arc::new(ScreenTime {
        enabled: AtomicBool::new(false),
        dirty: AtomicBool::new(false),
        data: Mutex::new(data),
    });
    app.manage(st.clone());

    let handle = app.clone();
    thread::spawn(move || {
        let mut ticks: u64 = 0;
        loop {
            thread::sleep(Duration::from_secs(TICK_SECONDS));
            ticks += 1;
            if st.enabled.load(Ordering::Relaxed) {
                count_one_tick(&st);
            }
            if ticks % SAVE_EVERY_TICKS == 0 && st.dirty.load(Ordering::Relaxed) {
                save(&handle, &st);
            }
        }
    });
}

/// Called when the app exits: keeps the last seconds.
pub fn shutdown(app: &AppHandle) {
    if let Some(st) = app.try_state::<Arc<ScreenTime>>() {
        if st.dirty.load(Ordering::Relaxed) {
            save(app, st.inner());
        }
    }
}

#[tauri::command]
pub fn screentime_configure(app: AppHandle, enabled: bool) -> bool {
    let st = state(&app);
    st.enabled.store(enabled, Ordering::Relaxed);
    enabled
}

/// All stored days: { "2026-11-15": { "chrome": 3600, ... }, ... }
#[tauri::command]
pub fn screentime_get(app: AppHandle) -> Value {
    let st = state(&app);
    let data = lock(&st);
    serde_json::to_value(&data.days).unwrap_or(Value::Null)
}

/// Deletes all stored screen time.
#[tauri::command]
pub fn screentime_clear(app: AppHandle) -> bool {
    let st = state(&app);
    lock(&st).days.clear();
    save(&app, &st);
    true
}
