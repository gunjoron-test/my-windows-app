//! Module E: Windows Firewall rule manager and the clipboard / browser cleaner.
//!
//! Firewall: listing is read-only. Changes run with administrator rights (Windows asks each
//! time) and every change is written to a history so it can be undone. The app only ever
//! deletes firewall rules it created itself; rules of other programs can be switched off
//! and on, which is reversible by nature.
//!
//! Cleaner: "scan" only measures; "apply" deletes what the user ticked. Deleting browser data
//! cannot be undone, so the interface shows a preview and asks for confirmation first.

use std::fs;
use std::path::PathBuf;
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::{json, Value};
use tauri::AppHandle;

use crate::{logging, paths, psrun};

const FIREWALL_LIST: &str = include_str!("../scripts/firewall-list.ps1");
const FIREWALL_APPLY: &str = include_str!("../scripts/firewall-apply.ps1");
const CLEANER: &str = include_str!("../scripts/cleaner.ps1");

const MAX_HISTORY: usize = 200;
const MAX_ITEMS: usize = 100;

fn now_ms() -> i64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as i64)
        .unwrap_or(0)
}

fn text_of<'a>(value: &'a Value, key: &str) -> &'a str {
    value.get(key).and_then(|v| v.as_str()).unwrap_or("")
}

fn clip(text: &str, max_chars: usize) -> String {
    text.chars().take(max_chars).collect()
}

fn list_of(value: &Value, key: &str) -> Vec<Value> {
    value
        .get(key)
        .and_then(|v| v.as_array())
        .cloned()
        .unwrap_or_default()
}

fn history_file(app: &AppHandle) -> PathBuf {
    paths::data_dir(app).join("firewall-history.json")
}

fn read_history(app: &AppHandle) -> Vec<Value> {
    fs::read_to_string(history_file(app))
        .ok()
        .and_then(|text| serde_json::from_str::<Vec<Value>>(&text).ok())
        .unwrap_or_default()
}

fn write_history(app: &AppHandle, history: &[Value]) -> Result<(), String> {
    let path = history_file(app);
    let temp = path.with_extension("json.tmp");
    let text = serde_json::to_string_pretty(history).map_err(|e| e.to_string())?;
    fs::write(&temp, text.as_bytes()).map_err(|e| e.to_string())?;
    fs::rename(&temp, &path).map_err(|e| e.to_string())
}

/// Builds a clean request for the firewall script from what the interface sent.
/// Returns the request and a short description for the history.
fn firewall_request(request: &Value) -> Result<(Value, String), String> {
    match text_of(request, "action") {
        "add" => {
            let program = clip(text_of(request, "program"), 400);
            if program.is_empty() {
                return Err("No program was chosen".into());
            }
            let direction = match text_of(request, "direction") {
                "in" => "in",
                "both" => "both",
                _ => "out",
            };
            let label = clip(text_of(request, "label"), 80);
            let description = if label.is_empty() { program.clone() } else { label.clone() };
            Ok((
                json!({ "action": "add", "program": program, "label": label, "direction": direction, "ruleAction": "block" }),
                description,
            ))
        }
        "remove" => {
            let ids: Vec<String> = list_of(request, "ids")
                .iter()
                .filter_map(|v| v.as_str())
                .take(MAX_ITEMS)
                .map(|id| clip(id, 200))
                .collect();
            if ids.is_empty() {
                return Err("No rule was chosen".into());
            }
            Ok((
                json!({ "action": "remove", "ids": ids }),
                clip(text_of(request, "label"), 120),
            ))
        }
        "enable" => {
            let items: Vec<Value> = list_of(request, "items")
                .iter()
                .take(MAX_ITEMS)
                .filter_map(|item| {
                    let id = item.get("id").and_then(|v| v.as_str())?;
                    let enabled = item.get("enabled").and_then(|v| v.as_bool())?;
                    Some(json!({ "id": clip(id, 200), "enabled": enabled }))
                })
                .collect();
            if items.is_empty() {
                return Err("No rule was chosen".into());
            }
            Ok((
                json!({ "action": "enable", "items": items }),
                clip(text_of(request, "label"), 120),
            ))
        }
        _ => Err("Unknown firewall action".into()),
    }
}

fn do_firewall_apply(app: &AppHandle, request: &Value) -> Result<Value, String> {
    let (input, description) = firewall_request(request)?;
    let kind = text_of(&input, "action").to_string();
    let result = psrun::run_checked(app, "firewall", FIREWALL_APPLY, &input, true)?;

    let mut history = read_history(app);
    let at = now_ms();
    history.push(json!({
        "entryId": format!("{}-{}", kind, at),
        "at": at,
        "kind": kind,
        "label": description,
        "created": list_of(&result, "created"),
        "removed": list_of(&result, "removed"),
        "previous": list_of(&result, "previous"),
        "undone": false,
    }));
    if history.len() > MAX_HISTORY {
        let extra = history.len() - MAX_HISTORY;
        history.drain(0..extra);
    }
    write_history(app, &history)?;
    logging::write("INFO", &format!("Firewall change: {}", kind));
    Ok(json!({ "result": result, "history": history }))
}

fn do_firewall_undo(app: &AppHandle, entry_id: &str) -> Result<Value, String> {
    let mut history = read_history(app);
    let index = history
        .iter()
        .position(|e| text_of(e, "entryId") == entry_id)
        .ok_or("This change is not in the history")?;
    if history[index].get("undone").and_then(|v| v.as_bool()) == Some(true) {
        return Err("This change was already undone".into());
    }
    let entry = history[index].clone();

    // The opposite action for each kind of change.
    let input = match text_of(&entry, "kind") {
        "add" => json!({ "action": "remove", "ids": list_of(&entry, "created") }),
        "remove" => json!({ "action": "restore", "rules": list_of(&entry, "removed") }),
        "enable" => json!({ "action": "enable", "items": list_of(&entry, "previous") }),
        _ => return Err("This change cannot be undone".into()),
    };
    let result = psrun::run_checked(app, "firewall", FIREWALL_APPLY, &input, true)?;

    if let Some(object) = history[index].as_object_mut() {
        object.insert("undone".to_string(), json!(true));
        object.insert("undoneAt".to_string(), json!(now_ms()));
    }
    write_history(app, &history)?;
    logging::write("INFO", &format!("Firewall change undone: {}", entry_id));
    Ok(json!({ "result": result, "history": history }))
}

/// Lists firewall rules that belong to a program. Read-only, no administrator rights.
#[tauri::command]
pub async fn firewall_list(app: AppHandle) -> Result<Value, String> {
    tauri::async_runtime::spawn_blocking(move || {
        psrun::run_checked(&app, "firewall-list", FIREWALL_LIST, &json!({}), false)
    })
    .await
    .map_err(|e| e.to_string())?
}

/// Adds a block rule, removes rules made by this app, or switches rules on/off.
/// The interface asks the user to confirm first; Windows then asks for permission.
#[tauri::command]
pub async fn firewall_apply(app: AppHandle, request: Value) -> Result<Value, String> {
    tauri::async_runtime::spawn_blocking(move || do_firewall_apply(&app, &request))
        .await
        .map_err(|e| e.to_string())?
}

#[tauri::command]
pub async fn firewall_undo(app: AppHandle, entry_id: String) -> Result<Value, String> {
    tauri::async_runtime::spawn_blocking(move || do_firewall_undo(&app, &entry_id))
        .await
        .map_err(|e| e.to_string())?
}

#[tauri::command]
pub fn firewall_history(app: AppHandle) -> Vec<Value> {
    read_history(&app)
}

/// Measures what the cleaner could delete (the preview). Read-only.
#[tauri::command]
pub async fn cleaner_scan(app: AppHandle) -> Result<Value, String> {
    tauri::async_runtime::spawn_blocking(move || {
        psrun::run_checked(&app, "cleaner", CLEANER, &json!({ "mode": "scan" }), false)
    })
    .await
    .map_err(|e| e.to_string())?
}

/// Deletes the ticked browser data and/or clears the clipboard. Cannot be undone;
/// the interface shows the preview and asks for confirmation before calling this.
#[tauri::command]
pub async fn cleaner_apply(app: AppHandle, targets: Vec<Value>, clipboard: bool) -> Result<Value, String> {
    let clean_targets: Vec<Value> = targets
        .iter()
        .take(300)
        .map(|t| {
            json!({
                "browser": clip(text_of(t, "browser"), 30),
                "profile": clip(text_of(t, "profile"), 120),
                "kind": clip(text_of(t, "kind"), 20),
            })
        })
        .collect();
    tauri::async_runtime::spawn_blocking(move || {
        let count = clean_targets.len();
        let result = psrun::run_checked(
            &app,
            "cleaner",
            CLEANER,
            &json!({ "mode": "apply", "targets": clean_targets, "clipboard": clipboard }),
            false,
        );
        logging::write(
            "INFO",
            &format!("Cleaner ran: {} item(s), clipboard: {}", count, clipboard),
        );
        result
    })
    .await
    .map_err(|e| e.to_string())?
}
