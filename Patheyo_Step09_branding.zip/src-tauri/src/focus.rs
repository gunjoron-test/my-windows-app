//! Focus mode, the "distracting programs" part. (Distracting websites are blocked by the
//! ad blocker's DNS filter.)
//!
//! While focus mode is on, the running programs are checked every few seconds. A program on
//! the user's list either gets a warning notification, or (only if the user chose so) is
//! closed. Windows system programs and this app can never be closed this way.

use std::collections::HashSet;
use std::sync::{Arc, Mutex, MutexGuard};
use std::thread;
use std::time::Duration;

use serde::Serialize;
use tauri::{AppHandle, Emitter, Manager};

use crate::{alarm, logging, winproc};

const CHECK_SECONDS: u64 = 3;
const MAX_APPS: usize = 100;

/// Programs that must never be closed, even if the user lists them.
const PROTECTED: [&str; 29] = [
    "patheyo.exe",
    "system", "registry", "smss.exe", "csrss.exe", "wininit.exe", "winlogon.exe", "services.exe",
    "lsass.exe", "svchost.exe", "dwm.exe", "explorer.exe", "fontdrvhost.exe", "sihost.exe",
    "ctfmon.exe", "runtimebroker.exe", "searchhost.exe", "startmenuexperiencehost.exe",
    "shellexperiencehost.exe", "textinputhost.exe", "lockapp.exe", "logonui.exe", "audiodg.exe",
    "spoolsv.exe", "conhost.exe", "taskmgr.exe", "msedgewebview2.exe", "noordesk.exe",
    "securityhealthservice.exe",
];

#[derive(Default)]
struct State {
    active: bool,
    close: bool,
    apps: Vec<String>,
    title: String,
    warn_body: String,
    closed_body: String,
    /// Programs already reported during this focus session (so each is reported once).
    reported: HashSet<String>,
}

pub struct Focus {
    state: Mutex<State>,
}

fn lock(focus: &Focus) -> MutexGuard<'_, State> {
    focus.state.lock().unwrap_or_else(|e| e.into_inner())
}

#[derive(Clone, Serialize)]
#[serde(rename_all = "camelCase")]
struct Hit {
    name: String,
    closed: bool,
}

fn check(app: &AppHandle, focus: &Focus) {
    let (apps, close) = {
        let state = lock(focus);
        if !state.active || state.apps.is_empty() {
            return;
        }
        (state.apps.clone(), state.close)
    };

    let mut hits: Vec<Hit> = Vec::new();
    for process_id in winproc::process_ids() {
        let path = match winproc::process_path(process_id) {
            Some(path) => path,
            None => continue,
        };
        let name = winproc::file_name_lower(&path);
        if !apps.contains(&name) {
            continue;
        }
        let closed = close && winproc::terminate(process_id);
        if !hits.iter().any(|h| h.name == name) {
            hits.push(Hit { name, closed });
        } else if closed {
            if let Some(hit) = hits.iter_mut().find(|h| h.name == name) {
                hit.closed = true;
            }
        }
    }

    for hit in hits {
        let (first, title, body) = {
            let mut state = lock(focus);
            let first = state.reported.insert(hit.name.clone());
            let template = if hit.closed { &state.closed_body } else { &state.warn_body };
            (first, state.title.clone(), template.replace("{name}", &hit.name))
        };
        if hit.closed {
            logging::write("INFO", &format!("Focus mode closed {}", hit.name));
        }
        // A closed program that is started again is closed again, but reported only once.
        if first {
            if !title.is_empty() {
                alarm::toast(app, &title, &body);
            }
            let _ = app.emit("focus-app", hit);
        }
    }
}

/// Called once when the app starts.
pub fn start(app: &AppHandle) {
    let focus = Arc::new(Focus {
        state: Mutex::new(State::default()),
    });
    app.manage(focus.clone());

    let handle = app.clone();
    thread::spawn(move || loop {
        thread::sleep(Duration::from_secs(CHECK_SECONDS));
        check(&handle, &focus);
    });
}

/// Turns the program part of focus mode on or off. Returns how many programs are watched.
#[tauri::command]
pub fn focus_apply(
    app: AppHandle,
    active: bool,
    apps: Vec<String>,
    close: bool,
    title: String,
    warn_body: String,
    closed_body: String,
) -> usize {
    let mut clean: Vec<String> = Vec::new();
    for entry in apps.iter().take(MAX_APPS) {
        let name = winproc::file_name_lower(entry.trim());
        if name.len() < 5 || name.len() > 100 || !name.ends_with(".exe") {
            continue;
        }
        if PROTECTED.contains(&name.as_str()) || clean.contains(&name) {
            continue;
        }
        clean.push(name);
    }

    let focus = app.state::<Arc<Focus>>().inner().clone();
    let mut state = lock(&focus);
    if !active || state.apps != clean || state.close != close {
        state.reported.clear();
    }
    state.active = active;
    state.close = close;
    state.apps = clean;
    state.title = title.chars().take(120).collect();
    state.warn_body = warn_body.chars().take(300).collect();
    state.closed_body = closed_body.chars().take(300).collect();
    if active {
        state.apps.len()
    } else {
        0
    }
}
