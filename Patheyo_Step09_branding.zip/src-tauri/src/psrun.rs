//! Runs one of the app's bundled PowerShell scripts and returns the JSON it writes.
//!
//! The script and its input are written to the app's own folder, the script is run, and the
//! output file is read. With `elevated` the script runs with administrator rights: Windows
//! shows its permission question (UAC), and Err("cancelled") means the user answered No.

use std::fs;
use std::path::Path;
use std::process::Command;
use std::sync::Mutex;

use serde_json::Value;
use tauri::AppHandle;

use crate::{blocker, paths};

/// Exit code of the launcher when the user refuses the Windows permission question.
const EXIT_CANCELLED: i32 = 5;

/// Scripts share temporary file names, so only one runs at a time.
static RUN_LOCK: Mutex<()> = Mutex::new(());

/// Windows allows command lines of up to 32767 characters; stay well below that.
const MAX_ENCODED: usize = 30_000;

fn quoted(path: &Path) -> String {
    path.to_string_lossy().replace('\'', "''")
}

fn base64(bytes: &[u8]) -> String {
    const TABLE: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut out = String::with_capacity(bytes.len().div_ceil(3) * 4);
    for chunk in bytes.chunks(3) {
        let b0 = chunk[0] as u32;
        let b1 = chunk.get(1).copied().unwrap_or(0) as u32;
        let b2 = chunk.get(2).copied().unwrap_or(0) as u32;
        let n = (b0 << 16) | (b1 << 8) | b2;
        out.push(TABLE[(n >> 18) as usize & 63] as char);
        out.push(TABLE[(n >> 12) as usize & 63] as char);
        out.push(if chunk.len() > 1 { TABLE[(n >> 6) as usize & 63] as char } else { '=' });
        out.push(if chunk.len() > 2 { TABLE[n as usize & 63] as char } else { '=' });
    }
    out
}

/// Runs PowerShell code with administrator rights. Windows shows its permission question;
/// Err("cancelled") means the user answered No.
///
/// The code itself is handed over on the command line (encoded), never through a file:
/// a file in the user's folder could be swapped by another program between the user's "Yes"
/// and the moment it runs, which would let that program run its own code as administrator.
pub fn run_elevated_text(code: &str) -> Result<(), String> {
    let utf16: Vec<u8> = code.encode_utf16().flat_map(|unit| unit.to_le_bytes()).collect();
    let encoded = base64(&utf16);
    if encoded.len() > MAX_ENCODED {
        return Err("The script is too long to run".into());
    }
    let launcher = format!(
        "try {{ Start-Process -FilePath 'powershell.exe' -Verb RunAs -WindowStyle Hidden -Wait -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-EncodedCommand','{}' -ErrorAction Stop; exit 0 }} catch {{ exit {} }}",
        encoded, EXIT_CANCELLED
    );
    let mut command = Command::new("powershell.exe");
    command.args([
        "-NoProfile",
        "-NonInteractive",
        "-ExecutionPolicy",
        "Bypass",
        "-Command",
        launcher.as_str(),
    ]);
    blocker::hide_window(&mut command);
    let status = command
        .status()
        .map_err(|e| format!("PowerShell could not be started: {}", e))?;
    if status.code() == Some(EXIT_CANCELLED) {
        return Err("cancelled".into());
    }
    Ok(())
}

pub fn run(
    app: &AppHandle,
    name: &str,
    script: &str,
    input: &Value,
    elevated: bool,
) -> Result<Value, String> {
    let _guard = RUN_LOCK.lock().unwrap_or_else(|e| e.into_inner());

    let dir = paths::data_dir(app).join("scripts-tmp");
    fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    let script_file = dir.join(format!("{}.ps1", name));
    let input_file = dir.join(format!("{}-in.json", name));
    let output_file = dir.join(format!("{}-out.json", name));
    let _ = fs::remove_file(&output_file);

    if elevated {
        // Script and input travel inside the command line; only the result comes back in a file.
        let code = format!(
            "& {{\n{}\n}} -InputFile '' -OutputFile '{}' -InputJson '{}'",
            script,
            quoted(&output_file),
            input.to_string().replace('\'', "''")
        );
        let outcome = run_elevated_text(&code);
        let text = fs::read_to_string(&output_file);
        let _ = fs::remove_file(&output_file);
        outcome?;
        let text = text.map_err(|_| "no-result".to_string())?;
        return serde_json::from_str::<Value>(text.trim_start_matches('\u{feff}'))
            .map_err(|_| "no-result".to_string());
    }

    // The byte-order mark makes Windows PowerShell read the script as UTF-8.
    fs::write(&script_file, format!("\u{feff}{}", script).as_bytes()).map_err(|e| e.to_string())?;
    fs::write(&input_file, input.to_string().as_bytes()).map_err(|e| e.to_string())?;

    let mut command = Command::new("powershell.exe");
    command
        .args(["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File"])
        .arg(&script_file)
        .arg("-InputFile")
        .arg(&input_file)
        .arg("-OutputFile")
        .arg(&output_file);
    blocker::hide_window(&mut command);

    let status = command.status();
    let text = fs::read_to_string(&output_file);
    let _ = fs::remove_file(&script_file);
    let _ = fs::remove_file(&input_file);
    let _ = fs::remove_file(&output_file);

    status.map_err(|e| format!("PowerShell could not be started: {}", e))?;
    let text = text.map_err(|_| "no-result".to_string())?;
    serde_json::from_str::<Value>(text.trim_start_matches('\u{feff}')).map_err(|_| "no-result".to_string())
}

/// Like `run`, but also turns a script-level failure ({"ok": false, "message": ...}) into Err.
pub fn run_checked(
    app: &AppHandle,
    name: &str,
    script: &str,
    input: &Value,
    elevated: bool,
) -> Result<Value, String> {
    let value = run(app, name, script, input, elevated)?;
    if value.get("ok").and_then(|v| v.as_bool()) == Some(true) {
        Ok(value)
    } else {
        let message = value.get("message").and_then(|v| v.as_str()).unwrap_or("");
        Err(if message.is_empty() {
            "no-result".to_string()
        } else {
            message.to_string()
        })
    }
}
