//! Changing and restoring the Windows DNS setting.
//!
//! Safety rules this file follows:
//!  * The original setting of every adapter is saved to dns-backup.json BEFORE anything changes,
//!    and an adapter that is already saved is never saved again (so the backup can never be
//!    overwritten with the app's own values).
//!  * Each adapter is given this PC (127.0.0.1) first, then the servers it used before, then
//!    public safety servers. If the app is closed or crashes, Windows simply uses the next
//!    server in the list and the internet keeps working.
//!  * Changing the setting needs administrator rights; Windows asks the user (UAC) each time.
//!  * "Repair" puts every adapter back to automatic DNS, whatever state things are in.

use std::fs;
use std::net::{IpAddr, SocketAddr};
use std::path::Path;

use serde_json::Value;

const SCRIPT_TEMPLATE: &str = r#"$ErrorActionPreference = 'Stop'
$action = '__ACTION__'
$dataDir = '__DATADIR__'
$fallback = @(__FALLBACK__)
$useV6 = $__V6__
$backupFile = Join-Path $dataDir 'dns-backup.json'
$lastFile = Join-Path $dataDir 'dns-backup.last.json'
$resultFile = Join-Path $dataDir 'dns-result.json'
$result = @{ ok = $false; action = $action; message = ''; changed = 0; failed = @() }

function Get-StaticDns([string]$guid, [int]$family) {
    $root = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\'
    if ($family -eq 6) { $root = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters\Interfaces\' }
    $value = ''
    try { $value = (Get-ItemProperty -LiteralPath ($root + $guid) -Name 'NameServer' -ErrorAction Stop).NameServer } catch { $value = '' }
    if ([string]::IsNullOrWhiteSpace($value)) { return @() }
    return @($value -split '[,\s]+' | Where-Object { $_ -and $_ -ne '127.0.0.1' -and $_ -ne '::1' })
}

function Read-Backup {
    if (-not (Test-Path -LiteralPath $backupFile)) { return @() }
    try {
        $data = [System.IO.File]::ReadAllText($backupFile) | ConvertFrom-Json
        return @($data.adapters | Where-Object { $_ -and $_.guid })
    } catch { return @() }
}

function Reset-OurDns {
    foreach ($entry in @(Get-DnsClientServerAddress -ErrorAction SilentlyContinue)) {
        if (($entry.ServerAddresses -contains '127.0.0.1') -or ($entry.ServerAddresses -contains '::1')) {
            try { Set-DnsClientServerAddress -InterfaceIndex $entry.InterfaceIndex -ResetServerAddresses } catch { }
        }
    }
}

function Retire-Backup {
    if (Test-Path -LiteralPath $backupFile) { Move-Item -LiteralPath $backupFile -Destination $lastFile -Force }
}

try {
    if ($action -eq 'enable') {
        $saved = @(Read-Backup)
        $known = @{}
        foreach ($item in $saved) { $known[[string]$item.guid] = $true }

        $targets = @{}
        foreach ($ad in @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue)) {
            if ($ad.InterfaceGuid) { $targets[[string]$ad.InterfaceGuid] = $ad }
        }
        foreach ($cfg in @(Get-NetIPConfiguration -ErrorAction SilentlyContinue)) {
            if ($cfg.IPv4DefaultGateway -and $cfg.NetAdapter -and ($cfg.NetAdapter.Status -eq 'Up')) {
                $targets[[string]$cfg.NetAdapter.InterfaceGuid] = $cfg.NetAdapter
            }
        }
        if ($targets.Count -eq 0) { throw 'No network adapter was found.' }

        $list = New-Object System.Collections.ArrayList
        foreach ($item in $saved) { [void]$list.Add($item) }
        foreach ($guid in @($targets.Keys)) {
            if (-not $known.ContainsKey($guid)) {
                [void]$list.Add([pscustomobject]@{
                    guid = $guid
                    name = [string]$targets[$guid].Name
                    v4 = @(Get-StaticDns $guid 4)
                    v6 = @(Get-StaticDns $guid 6)
                })
            }
        }
        $json = @{ savedAt = (Get-Date).ToString('s'); adapters = @($list) } | ConvertTo-Json -Depth 6
        [System.IO.File]::WriteAllText($backupFile, $json)

        foreach ($guid in @($targets.Keys)) {
            $ad = $targets[$guid]
            try {
                $cur4 = @((Get-DnsClientServerAddress -InterfaceIndex $ad.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue).ServerAddresses | Where-Object { $_ -and $_ -ne '127.0.0.1' })
                $cur6 = @((Get-DnsClientServerAddress -InterfaceIndex $ad.ifIndex -AddressFamily IPv6 -ErrorAction SilentlyContinue).ServerAddresses | Where-Object { $_ -and $_ -ne '::1' -and $_ -notlike 'fec0:*' })
                $servers = @('127.0.0.1') + @($cur4 | Select-Object -First 2) + @($fallback)
                if ($useV6) { $servers += '::1'; $servers += @($cur6 | Select-Object -First 2) }
                $servers = @($servers | Where-Object { $_ } | Select-Object -Unique)
                Set-DnsClientServerAddress -InterfaceIndex $ad.ifIndex -ServerAddresses $servers
                $result.changed = $result.changed + 1
            } catch { $result.failed += [string]$ad.Name }
        }
        if ($result.changed -eq 0) { throw 'The DNS setting could not be changed on any network adapter.' }
    }
    elseif ($action -eq 'disable') {
        foreach ($item in @(Read-Backup)) {
            $ad = Get-NetAdapter -ErrorAction SilentlyContinue | Where-Object { $_.InterfaceGuid -eq $item.guid } | Select-Object -First 1
            if (-not $ad) { continue }
            try {
                Set-DnsClientServerAddress -InterfaceIndex $ad.ifIndex -ResetServerAddresses
                # Only real IP addresses from the backup are put back.
                $static = @(@($item.v4) + @($item.v6) | Where-Object { $_ -and ([string]$_ -as [ipaddress]) })
                if ($static.Count -gt 0) { Set-DnsClientServerAddress -InterfaceIndex $ad.ifIndex -ServerAddresses $static }
                $result.changed = $result.changed + 1
            } catch { $result.failed += [string]$item.name }
        }
        Reset-OurDns
        Retire-Backup
    }
    elseif ($action -eq 'repair') {
        foreach ($ad in @(Get-NetAdapter -ErrorAction SilentlyContinue)) {
            try {
                Set-DnsClientServerAddress -InterfaceIndex $ad.ifIndex -ResetServerAddresses
                $result.changed = $result.changed + 1
            } catch { }
        }
        Reset-OurDns
        Retire-Backup
    }
    else { throw 'Unknown action.' }

    try { Clear-DnsClientCache } catch { }
    $result.ok = $true
} catch {
    $result.message = [string]$_.Exception.Message
}

try { [System.IO.File]::WriteAllText($resultFile, ($result | ConvertTo-Json -Depth 4)) } catch { }
"#;

/// A stand-alone repair tool the user can run even when the app does not start.
const REPAIR_TOOL: &str = "@echo off\r\n\
rem Patheyo: puts the DNS setting of every network adapter back to automatic.\r\n\
net session >nul 2>&1\r\n\
if %errorlevel% neq 0 (\r\n\
  powershell -NoProfile -Command \"Start-Process -FilePath '%~f0' -Verb RunAs\"\r\n\
  exit /b\r\n\
)\r\n\
powershell -NoProfile -ExecutionPolicy Bypass -Command \"Get-NetAdapter | ForEach-Object { Set-DnsClientServerAddress -InterfaceIndex $_.ifIndex -ResetServerAddresses }; Clear-DnsClientCache\"\r\n\
echo.\r\n\
echo Done. The DNS setting of every network adapter is automatic again.\r\n\
pause\r\n";

fn is_plain_ip(text: &str) -> bool {
    text.parse::<IpAddr>().is_ok()
}

fn build_script(action: &str, data_dir: &Path, fallback: &[String], v6: bool) -> String {
    let fallback_list = fallback
        .iter()
        .filter(|ip| is_plain_ip(ip))
        .map(|ip| format!("'{}'", ip))
        .collect::<Vec<String>>()
        .join(",");
    SCRIPT_TEMPLATE
        .replace("__ACTION__", action)
        .replace("__DATADIR__", &data_dir.to_string_lossy().replace('\'', "''"))
        .replace("__FALLBACK__", &fallback_list)
        .replace("__V6__", if v6 { "true" } else { "false" })
}

/// Runs one network action ("enable", "disable" or "repair") with administrator rights.
/// Windows shows its permission question; Err("cancelled") means the user said No.
pub fn run_elevated(data_dir: &Path, action: &str, fallback: &[String], v6: bool) -> Result<Value, String> {
    if !matches!(action, "enable" | "disable" | "repair") {
        return Err("Unknown action".into());
    }
    let result_file = data_dir.join("dns-result.json");
    let _ = fs::remove_file(&result_file);

    // The script is passed on the command line, never through a file (see psrun.rs for why).
    crate::psrun::run_elevated_text(&build_script(action, data_dir, fallback, v6))?;

    let text = fs::read_to_string(&result_file).map_err(|_| "no-result".to_string())?;
    let _ = fs::remove_file(&result_file);
    let value: Value = serde_json::from_str(text.trim_start_matches('\u{feff}'))
        .map_err(|_| "no-result".to_string())?;

    if value.get("ok").and_then(|v| v.as_bool()) == Some(true) {
        Ok(value)
    } else {
        let message = value
            .get("message")
            .and_then(|v| v.as_str())
            .unwrap_or("")
            .to_string();
        Err(if message.is_empty() {
            "no-result".to_string()
        } else {
            message
        })
    }
}

/// Writes the stand-alone repair tool into the data folder. Returns its path.
pub fn write_repair_tool(data_dir: &Path) -> Option<std::path::PathBuf> {
    let path = data_dir.join("Repair-Internet.cmd");
    fs::write(&path, REPAIR_TOOL.as_bytes()).ok()?;
    Some(path)
}

/// True while a backup exists, i.e. the app has changed the Windows DNS setting.
pub fn backup_exists(data_dir: &Path) -> bool {
    data_dir.join("dns-backup.json").exists()
}

/// DNS servers the user had typed in by hand before the blocker was turned on.
fn saved_static_servers(data_dir: &Path) -> Vec<String> {
    let mut out = Vec::new();
    let text = match fs::read_to_string(data_dir.join("dns-backup.json")) {
        Ok(text) => text,
        Err(_) => return out,
    };
    let value: Value = match serde_json::from_str(text.trim_start_matches('\u{feff}')) {
        Ok(value) => value,
        Err(_) => return out,
    };
    // PowerShell writes a single adapter as an object and several as a list.
    let adapters: Vec<Value> = match value.get("adapters") {
        Some(Value::Array(list)) => list.clone(),
        Some(single @ Value::Object(_)) => vec![single.clone()],
        _ => Vec::new(),
    };
    for adapter in adapters {
        match adapter.get("v4") {
            Some(Value::Array(servers)) => {
                for server in servers {
                    if let Some(ip) = server.as_str() {
                        out.push(ip.to_string());
                    }
                }
            }
            Some(Value::String(ip)) => out.push(ip.clone()),
            _ => {}
        }
    }
    out
}

/// DNS servers handed out by the router (DHCP) for every network interface. Windows keeps
/// these up to date in the registry even while the adapter has a fixed DNS setting.
#[cfg(windows)]
fn dhcp_servers() -> Vec<String> {
    use winreg::enums::HKEY_LOCAL_MACHINE;
    use winreg::RegKey;

    let mut out = Vec::new();
    let root = RegKey::predef(HKEY_LOCAL_MACHINE);
    let interfaces = match root.open_subkey("SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters\\Interfaces") {
        Ok(key) => key,
        Err(_) => return out,
    };
    for name in interfaces.enum_keys().flatten() {
        if let Ok(key) = interfaces.open_subkey(&name) {
            let value: String = key.get_value("DhcpNameServer").unwrap_or_default();
            for part in value.split(|c: char| c == ' ' || c == ',') {
                if !part.is_empty() {
                    out.push(part.to_string());
                }
            }
        }
    }
    out
}

#[cfg(not(windows))]
fn dhcp_servers() -> Vec<String> {
    Vec::new()
}

/// The real DNS servers the filter passes questions on to, in order of preference:
/// servers the user had set by hand, then the router's servers, then the safety servers.
pub fn detect_upstreams(data_dir: &Path, fallback: &[String]) -> Vec<SocketAddr> {
    let mut candidates: Vec<String> = saved_static_servers(data_dir);
    candidates.extend(dhcp_servers());
    candidates.extend(fallback.iter().cloned());

    let mut out: Vec<SocketAddr> = Vec::new();
    for text in candidates {
        let ip: IpAddr = match text.trim().parse() {
            Ok(ip) => ip,
            Err(_) => continue,
        };
        // Only IPv4 servers are used, and never this PC itself (that would be a loop).
        if !ip.is_ipv4() || ip.is_loopback() || ip.is_unspecified() {
            continue;
        }
        let address = SocketAddr::new(ip, 53);
        if !out.contains(&address) {
            out.push(address);
        }
        if out.len() >= 6 {
            break;
        }
    }
    out
}
