//! Local DNS filter.
//!
//! Listens on 127.0.0.1:53 (and [::1]:53). Every question Windows asks is checked against the
//! block rules: blocked names are answered with the "nowhere" address 0.0.0.0, everything else
//! is passed unchanged to the real DNS server and its answer is passed back.
//!
//! Nothing is decrypted or inspected: only the DNS name is looked at. HTTPS traffic is never
//! touched and no certificates are installed.

use std::collections::VecDeque;
use std::io::{ErrorKind, Read};
use std::net::{SocketAddr, UdpSocket};
use std::sync::atomic::{AtomicBool, AtomicI64, AtomicU64, AtomicUsize, Ordering};
use std::sync::{Arc, Mutex, OnceLock, RwLock};
use std::thread;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use serde::Serialize;

use super::lists::Rules;

/// A name only the app itself asks for, to check that the filter is answering.
pub const SELF_TEST_NAME: &str = "patheyo-selftest.invalid";

const MAX_PACKET: usize = 4096;
const MAX_IN_FLIGHT: usize = 64;
const UPSTREAM_TIMEOUT_MS: u64 = 1800;
const RECENT_LIMIT: usize = 300;
const BLOCKED_TTL: u8 = 30;
/// After a failed encrypted (DoH) request, plain DNS is used for this long before trying again,
/// so a blocked or slow DoH server never makes browsing slow.
const DOH_RETRY_MS: i64 = 30_000;

/// One shared HTTPS client, so connections to the DoH server are reused.
static DOH_CLIENT: OnceLock<ureq::Agent> = OnceLock::new();

#[derive(Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct LogEntry {
    /// Unix time in milliseconds of the latest request.
    pub at: i64,
    pub domain: String,
    /// How many times in a row this name was blocked.
    pub count: u32,
}

#[derive(Default)]
pub struct Stats {
    pub total: u64,
    pub today: u64,
    /// The local date ("2026-11-14") that `today` belongs to.
    pub day: String,
    pub recent: VecDeque<LogEntry>,
    pub dirty: bool,
}

pub struct Shared {
    running: AtomicBool,
    v6: AtomicBool,
    pub paused: AtomicBool,
    pub rules: RwLock<Arc<Rules>>,
    pub upstreams: RwLock<Vec<SocketAddr>>,
    preferred: AtomicUsize,
    in_flight: AtomicUsize,
    pub forwarded: AtomicU64,
    pub stats: Mutex<Stats>,
    /// Address of the DNS-over-HTTPS server, or None to use plain DNS.
    pub doh: RwLock<Option<String>>,
    pub doh_ok: AtomicU64,
    pub doh_failed: AtomicU64,
    doh_retry_at: AtomicI64,
}

impl Shared {
    pub fn new() -> Self {
        Shared {
            running: AtomicBool::new(false),
            v6: AtomicBool::new(false),
            paused: AtomicBool::new(false),
            rules: RwLock::new(Arc::new(Rules::default())),
            upstreams: RwLock::new(Vec::new()),
            preferred: AtomicUsize::new(0),
            in_flight: AtomicUsize::new(0),
            forwarded: AtomicU64::new(0),
            stats: Mutex::new(Stats::default()),
            doh: RwLock::new(None),
            doh_ok: AtomicU64::new(0),
            doh_failed: AtomicU64::new(0),
            doh_retry_at: AtomicI64::new(0),
        }
    }

    pub fn is_running(&self) -> bool {
        self.running.load(Ordering::Relaxed)
    }

    pub fn has_v6(&self) -> bool {
        self.v6.load(Ordering::Relaxed)
    }

    fn record_block(&self, domain: &str) {
        let today = chrono::Local::now().format("%Y-%m-%d").to_string();
        let now = now_ms();
        let mut stats = self.stats.lock().unwrap_or_else(|e| e.into_inner());
        if stats.day != today {
            stats.day = today;
            stats.today = 0;
        }
        stats.total += 1;
        stats.today += 1;
        stats.dirty = true;

        let mut merged = false;
        if let Some(last) = stats.recent.back_mut() {
            if last.domain == domain {
                last.count = last.count.saturating_add(1);
                last.at = now;
                merged = true;
            }
        }
        if !merged {
            stats.recent.push_back(LogEntry {
                at: now,
                domain: domain.to_string(),
                count: 1,
            });
            while stats.recent.len() > RECENT_LIMIT {
                stats.recent.pop_front();
            }
        }
    }
}

fn now_ms() -> i64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as i64)
        .unwrap_or(0)
}

struct Question {
    name: String,
    qtype: u16,
    /// Index just after the question section.
    end: usize,
}

/// Reads the name being asked for. Returns None for anything that is not a plain, single question.
fn parse_question(packet: &[u8]) -> Option<Question> {
    if packet.len() < 17 {
        return None;
    }
    let is_response = packet[2] & 0x80 != 0;
    let opcode = (packet[2] >> 3) & 0x0f;
    let question_count = u16::from_be_bytes([packet[4], packet[5]]);
    if is_response || opcode != 0 || question_count != 1 {
        return None;
    }

    let mut name = String::new();
    let mut pos = 12usize;
    loop {
        let len = *packet.get(pos)? as usize;
        pos += 1;
        if len == 0 {
            break;
        }
        if len & 0xc0 != 0 {
            return None; // compressed names do not appear in questions
        }
        let label = packet.get(pos..pos + len)?;
        if !name.is_empty() {
            name.push('.');
        }
        for &byte in label {
            if !byte.is_ascii() || byte == b'.' {
                return None;
            }
            name.push(byte.to_ascii_lowercase() as char);
        }
        pos += len;
        if name.len() > 253 {
            return None;
        }
    }

    let tail = packet.get(pos..pos + 4)?;
    Some(Question {
        name,
        qtype: u16::from_be_bytes([tail[0], tail[1]]),
        end: pos + 4,
    })
}

/// Builds the answer for a blocked name: 0.0.0.0 for IPv4 questions, :: for IPv6 questions,
/// and "no data" for every other kind of question.
fn blocked_answer(query: &[u8], question: &Question) -> Vec<u8> {
    let mut reply = Vec::with_capacity(question.end + 32);
    reply.extend_from_slice(&query[..question.end]);

    let address_len: usize = match question.qtype {
        1 => 4,   // A
        28 => 16, // AAAA
        _ => 0,
    };

    reply[2] = 0x80 | (query[2] & 0x01); // response, keep "recursion desired"
    reply[3] = 0x80; // recursion available, no error
    reply[6] = 0;
    reply[7] = if address_len > 0 { 1 } else { 0 }; // answers
    reply[8] = 0;
    reply[9] = 0; // authority records
    reply[10] = 0;
    reply[11] = 0; // additional records

    if address_len > 0 {
        reply.extend_from_slice(&[0xc0, 0x0c]); // name: pointer to the question
        reply.extend_from_slice(&question.qtype.to_be_bytes());
        reply.extend_from_slice(&[0x00, 0x01]); // class IN
        reply.extend_from_slice(&[0, 0, 0, BLOCKED_TTL]);
        reply.extend_from_slice(&(address_len as u16).to_be_bytes());
        reply.extend(std::iter::repeat(0u8).take(address_len));
    }
    reply
}

/// "Server failure": tells Windows to ask its next DNS server right away.
fn failure_answer(query: &[u8]) -> Vec<u8> {
    let mut reply = query.to_vec();
    reply[2] = 0x80 | (query[2] & 0x01);
    reply[3] = 0x82;
    reply
}

/// Sends the question to one real DNS server and waits briefly for its answer.
fn ask(upstream: SocketAddr, query: &[u8]) -> Option<Vec<u8>> {
    let local = if upstream.is_ipv4() { "0.0.0.0:0" } else { "[::]:0" };
    let socket = UdpSocket::bind(local).ok()?;
    socket
        .set_read_timeout(Some(Duration::from_millis(UPSTREAM_TIMEOUT_MS)))
        .ok()?;
    socket.send_to(query, upstream).ok()?;

    let mut buffer = [0u8; MAX_PACKET];
    for _ in 0..3 {
        match socket.recv_from(&mut buffer) {
            Ok((len, from)) => {
                // Accept only the matching answer from the server that was asked.
                if from.ip() == upstream.ip()
                    && len >= 12
                    && buffer[0] == query[0]
                    && buffer[1] == query[1]
                {
                    return Some(buffer[..len].to_vec());
                }
            }
            Err(_) => return None,
        }
    }
    None
}

/// Sends the question to the DoH server over HTTPS (RFC 8484) and returns its answer.
fn ask_doh(url: &str, query: &[u8]) -> Option<Vec<u8>> {
    let client = DOH_CLIENT.get_or_init(|| {
        ureq::AgentBuilder::new()
            .timeout_connect(Duration::from_secs(3))
            .timeout(Duration::from_secs(5))
            .build()
    });
    let response = client
        .post(url)
        .set("content-type", "application/dns-message")
        .set("accept", "application/dns-message")
        .send_bytes(query)
        .ok()?;
    let mut answer = Vec::new();
    response
        .into_reader()
        .take(MAX_PACKET as u64)
        .read_to_end(&mut answer)
        .ok()?;
    if answer.len() < 12 {
        return None;
    }
    // The answer must carry the id of the question it belongs to.
    answer[0] = query[0];
    answer[1] = query[1];
    Some(answer)
}

fn forward(shared: &Shared, reply_socket: &UdpSocket, query: &[u8], client: SocketAddr) {
    // Encrypted DNS first, if switched on. On any failure plain DNS below is used instead,
    // so a problem with the DoH server never stops the internet.
    let doh_url: Option<String> = shared.doh.read().unwrap_or_else(|e| e.into_inner()).clone();
    if let Some(url) = doh_url {
        if now_ms() >= shared.doh_retry_at.load(Ordering::Relaxed) {
            match ask_doh(&url, query) {
                Some(answer) => {
                    let _ = reply_socket.send_to(&answer, client);
                    shared.forwarded.fetch_add(1, Ordering::Relaxed);
                    shared.doh_ok.fetch_add(1, Ordering::Relaxed);
                    return;
                }
                None => {
                    shared.doh_failed.fetch_add(1, Ordering::Relaxed);
                    shared
                        .doh_retry_at
                        .store(now_ms() + DOH_RETRY_MS, Ordering::Relaxed);
                }
            }
        }
    }

    let upstreams: Vec<SocketAddr> = shared
        .upstreams
        .read()
        .unwrap_or_else(|e| e.into_inner())
        .clone();
    let count = upstreams.len();
    if count > 0 {
        let start = shared.preferred.load(Ordering::Relaxed) % count;
        for step in 0..count {
            let index = (start + step) % count;
            if let Some(answer) = ask(upstreams[index], query) {
                if step != 0 {
                    // Remember the server that works, so the next question goes there first.
                    shared.preferred.store(index, Ordering::Relaxed);
                }
                let _ = reply_socket.send_to(&answer, client);
                shared.forwarded.fetch_add(1, Ordering::Relaxed);
                return;
            }
        }
    }
    let _ = reply_socket.send_to(&failure_answer(query), client);
}

fn serve(socket: UdpSocket, shared: Arc<Shared>) {
    let mut buffer = [0u8; MAX_PACKET];
    while shared.running.load(Ordering::Relaxed) {
        let (len, client) = match socket.recv_from(&mut buffer) {
            Ok(received) => received,
            Err(e) => {
                // Timeouts are how the loop notices a stop request. Other errors (Windows
                // reports "connection reset" on UDP after an unreachable reply) are ignored.
                if !matches!(e.kind(), ErrorKind::WouldBlock | ErrorKind::TimedOut) {
                    thread::sleep(Duration::from_millis(5));
                }
                continue;
            }
        };
        if len < 12 {
            continue;
        }
        let query = buffer[..len].to_vec();

        if let Some(question) = parse_question(&query) {
            if question.name == SELF_TEST_NAME {
                let _ = socket.send_to(&blocked_answer(&query, &question), client);
                continue;
            }
            if !shared.paused.load(Ordering::Relaxed) {
                let rules: Arc<Rules> = shared
                    .rules
                    .read()
                    .unwrap_or_else(|e| e.into_inner())
                    .clone();
                if rules.is_blocked(&question.name) {
                    let _ = socket.send_to(&blocked_answer(&query, &question), client);
                    shared.record_block(&question.name);
                    continue;
                }
            }
        }

        // Not blocked: pass it on in a short-lived worker so a slow server never stalls others.
        if shared.in_flight.load(Ordering::Relaxed) >= MAX_IN_FLIGHT {
            continue;
        }
        let reply_socket = match socket.try_clone() {
            Ok(clone) => clone,
            Err(_) => continue,
        };
        let worker_shared = shared.clone();
        shared.in_flight.fetch_add(1, Ordering::Relaxed);
        thread::spawn(move || {
            forward(&worker_shared, &reply_socket, &query, client);
            worker_shared.in_flight.fetch_sub(1, Ordering::Relaxed);
        });
    }
}

fn bind_with_retry(address: &str) -> std::io::Result<UdpSocket> {
    let mut last_error = None;
    for attempt in 0..4 {
        if attempt > 0 {
            thread::sleep(Duration::from_millis(400));
        }
        match UdpSocket::bind(address) {
            Ok(socket) => return Ok(socket),
            Err(e) => last_error = Some(e),
        }
    }
    Err(last_error.unwrap_or_else(|| std::io::Error::new(ErrorKind::Other, "bind failed")))
}

/// Starts listening. Returns an error if port 53 is taken by another program.
pub fn start(shared: &Arc<Shared>) -> Result<(), String> {
    if shared.is_running() {
        return Ok(());
    }
    let socket_v4 = bind_with_retry("127.0.0.1:53").map_err(|e| format!("port53: {}", e))?;
    socket_v4
        .set_read_timeout(Some(Duration::from_millis(500)))
        .map_err(|e| e.to_string())?;

    shared.running.store(true, Ordering::Relaxed);
    let shared_v4 = shared.clone();
    thread::spawn(move || serve(socket_v4, shared_v4));

    // IPv6 is optional: some PCs have it switched off.
    let mut v6 = false;
    if let Ok(socket_v6) = UdpSocket::bind("[::1]:53") {
        if socket_v6
            .set_read_timeout(Some(Duration::from_millis(500)))
            .is_ok()
        {
            let shared_v6 = shared.clone();
            thread::spawn(move || serve(socket_v6, shared_v6));
            v6 = true;
        }
    }
    shared.v6.store(v6, Ordering::Relaxed);
    Ok(())
}

pub fn stop(shared: &Arc<Shared>) {
    shared.running.store(false, Ordering::Relaxed);
}

/// Asks the filter a question itself to make sure it is really answering,
/// before any Windows network setting is changed.
pub fn self_test() -> bool {
    let socket = match UdpSocket::bind("127.0.0.1:0") {
        Ok(socket) => socket,
        Err(_) => return false,
    };
    if socket
        .set_read_timeout(Some(Duration::from_millis(1500)))
        .is_err()
    {
        return false;
    }

    // Header (id 0x4e44, one question, recursion desired) + the test name + type A, class IN.
    let mut query: Vec<u8> = vec![0x4e, 0x44, 0x01, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0];
    for label in SELF_TEST_NAME.split('.') {
        query.push(label.len() as u8);
        query.extend_from_slice(label.as_bytes());
    }
    query.extend_from_slice(&[0, 0x00, 0x01, 0x00, 0x01]);

    let mut buffer = [0u8; 512];
    for _ in 0..3 {
        if socket.send_to(&query, "127.0.0.1:53").is_err() {
            return false;
        }
        if let Ok((len, _)) = socket.recv_from(&mut buffer) {
            if len >= 12 && buffer[0] == 0x4e && buffer[1] == 0x44 && buffer[2] & 0x80 != 0 {
                return true;
            }
        }
    }
    false
}
