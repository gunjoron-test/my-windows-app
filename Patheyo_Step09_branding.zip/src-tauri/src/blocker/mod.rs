//! Module C: system-wide ad and tracker blocking.
//!
//! How it works: a small DNS filter runs inside the app (dns.rs). When the blocker is turned
//! on, Windows is told to ask this filter first (netcfg.rs). Names on the blocklists
//! (lists.rs) get the answer "nowhere"; everything else is passed to the normal DNS server.
//!
//! What it cannot do, by design: it never opens HTTPS traffic and installs no certificates,
//! so ads that come from the same server as the content (for example YouTube video ads)
//! cannot be blocked this way.

mod dns;
mod lists;
mod netcfg;

use std::collections::HashMap;
use std::fs;
use std::process::Command;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex, MutexGuard};
use std::thread;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use serde::{Deserialize, Serialize};
use tauri::{AppHandle, Manager};

use crate::{logging, paths};

/// Settings of the blocker, sent by the interface and remembered here so the filter can
/// start by itself when the app starts.
#[derive(Clone, Debug, Default, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct Config {
    /// Ids of the built-in lists that are switched on.
    pub sources: Vec<String>,
    /// Extra list addresses (https only).
    pub custom_sources: Vec<String>,
    /// Names that are always allowed.
    pub allow: Vec<String>,
    /// The user's own names to block.
    pub block: Vec<String>,
    /// Automatic update interval in days; 0 turns automatic updates off.
    pub update_days: u32,
    /// "cloudflare", "quad9" or "google": the public safety DNS servers.
    pub fallback: String,
    /// Encrypted DNS (DNS-over-HTTPS): "off", "cloudflare", "quad9" or "google".
    pub doh: String,
    /// Sites blocked only while focus mode is on (Step 6). Empty when focus mode is off.
    pub focus: Vec<String>,
}

/// Address of the chosen DNS-over-HTTPS server. Numeric addresses are used on purpose:
/// they need no DNS lookup themselves, so the filter can never end up asking itself.
fn doh_address(name: &str) -> Option<String> {
    match name {
        "cloudflare" => Some("https://1.1.1.1/dns-query".to_string()),
        "quad9" => Some("https://9.9.9.9/dns-query".to_string()),
        "google" => Some("https://8.8.8.8/dns-query".to_string()),
        _ => None,
    }
}

fn apply_doh(b: &Blocker) {
    let address = doh_address(&persist(b).config.doh);
    *b.dns.doh.write().unwrap_or_else(|e| e.into_inner()) = address;
}

#[derive(Default, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
struct Persist {
    /// True while Windows is set up to ask the filter.
    active: bool,
    paused: bool,
    config: Config,
    total: u64,
    today: u64,
    day: String,
    last_update: i64,
    rule_count: usize,
    list_counts: HashMap<String, usize>,
    last_error: String,
}

pub struct Blocker {
    persist: Mutex<Persist>,
    dns: Arc<dns::Shared>,
    /// True while a long action (turn on/off, repair, list update) is running.
    busy: AtomicBool,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Status {
    active: bool,
    paused: bool,
    running: bool,
    busy: bool,
    v6: bool,
    dns_changed: bool,
    total: u64,
    today: u64,
    forwarded: u64,
    rule_count: usize,
    list_counts: HashMap<String, usize>,
    last_update: i64,
    upstreams: Vec<String>,
    recent: Vec<dns::LogEntry>,
    last_error: String,
    doh: String,
    doh_ok: u64,
    doh_failed: u64,
}

/// Starts a helper program without flashing a console window.
pub(crate) fn hide_window(command: &mut Command) {
    #[cfg(windows)]
    {
        use std::os::windows::process::CommandExt;
        const CREATE_NO_WINDOW: u32 = 0x0800_0000;
        command.creation_flags(CREATE_NO_WINDOW);
    }
    #[cfg(not(windows))]
    {
        let _ = command;
    }
}

fn now_ms() -> i64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as i64)
        .unwrap_or(0)
}

fn blocker(app: &AppHandle) -> Arc<Blocker> {
    app.state::<Arc<Blocker>>().inner().clone()
}

fn persist(b: &Blocker) -> MutexGuard<'_, Persist> {
    b.persist.lock().unwrap_or_else(|e| e.into_inner())
}

fn fallback_servers(name: &str) -> Vec<String> {
    let pair: [&str; 2] = match name {
        "quad9" => ["9.9.9.9", "149.112.112.112"],
        "google" => ["8.8.8.8", "8.8.4.4"],
        _ => ["1.1.1.1", "1.0.0.1"],
    };
    pair.iter().map(|ip| ip.to_string()).collect()
}

fn load(app: &AppHandle) -> Persist {
    fs::read_to_string(paths::blocker_file(app))
        .ok()
        .and_then(|text| serde_json::from_str::<Persist>(&text).ok())
        .unwrap_or_default()
}

/// Copies the live counters into the saved state and writes it to disk.
fn save(app: &AppHandle, b: &Blocker) {
    let text = {
        let mut p = persist(b);
        {
            let mut stats = b.dns.stats.lock().unwrap_or_else(|e| e.into_inner());
            p.total = stats.total;
            p.today = stats.today;
            p.day = stats.day.clone();
            stats.dirty = false;
        }
        serde_json::to_string_pretty(&*p).unwrap_or_default()
    };
    if text.is_empty() {
        return;
    }
    let path = paths::blocker_file(app);
    let temp = path.with_extension("json.tmp");
    if fs::write(&temp, text.as_bytes()).is_ok() {
        let _ = fs::rename(&temp, &path);
    }
}

/// Reads the saved lists from disk and hands the fresh rules to the filter.
fn rebuild(app: &AppHandle, b: &Blocker) -> usize {
    let config = persist(b).config.clone();
    let (rules, counts) = lists::build(&paths::blocklist_dir(app), &config);
    let count = rules.block_count();
    *b.dns.rules.write().unwrap_or_else(|e| e.into_inner()) = Arc::new(rules);
    let mut p = persist(b);
    p.rule_count = count;
    p.list_counts = counts;
    count
}

fn refresh_upstreams(app: &AppHandle, b: &Blocker) -> usize {
    let fallback = fallback_servers(&persist(b).config.fallback);
    let servers = netcfg::detect_upstreams(&paths::data_dir(app), &fallback);
    let count = servers.len();
    *b.dns.upstreams.write().unwrap_or_else(|e| e.into_inner()) = servers;
    count
}

fn update_lists(app: &AppHandle, b: &Blocker) -> Result<usize, String> {
    let config = persist(b).config.clone();
    let (updated, error) = lists::update_all(&paths::blocklist_dir(app), &config);
    if updated == 0 {
        return Err(error.unwrap_or_else(|| "lists".to_string()));
    }
    persist(b).last_update = now_ms();
    let count = rebuild(app, b);
    logging::write(
        "INFO",
        &format!("Blocklists updated: {} list(s), {} rules", updated, count),
    );
    Ok(count)
}

fn status_of(app: &AppHandle, b: &Blocker) -> Status {
    let (total, today, recent) = {
        let stats = b.dns.stats.lock().unwrap_or_else(|e| e.into_inner());
        let recent: Vec<dns::LogEntry> = stats.recent.iter().rev().take(100).cloned().collect();
        (stats.total, stats.today, recent)
    };
    let upstreams: Vec<String> = b
        .dns
        .upstreams
        .read()
        .unwrap_or_else(|e| e.into_inner())
        .iter()
        .map(|address| address.ip().to_string())
        .collect();
    let p = persist(b);
    Status {
        active: p.active,
        paused: p.paused,
        running: b.dns.is_running(),
        busy: b.busy.load(Ordering::Relaxed),
        v6: b.dns.has_v6(),
        dns_changed: netcfg::backup_exists(&paths::data_dir(app)),
        total,
        today,
        forwarded: b.dns.forwarded.load(Ordering::Relaxed),
        rule_count: p.rule_count,
        list_counts: p.list_counts.clone(),
        last_update: p.last_update,
        upstreams,
        recent,
        last_error: p.last_error.clone(),
        doh: p.config.doh.clone(),
        doh_ok: b.dns.doh_ok.load(Ordering::Relaxed),
        doh_failed: b.dns.doh_failed.load(Ordering::Relaxed),
    }
}

/// Makes the filter ready and answering. Does not touch any Windows setting.
fn start_filter(app: &AppHandle, b: &Blocker) -> Result<(), String> {
    if rebuild(app, b) == 0 {
        // Nothing saved yet: the first start needs one download.
        update_lists(app, b).map_err(|e| format!("lists: {}", e))?;
        if persist(b).rule_count == 0 {
            return Err("lists".into());
        }
    }
    if refresh_upstreams(app, b) == 0 {
        return Err("no-upstream".into());
    }
    dns::start(&b.dns)?;
    if !dns::self_test() {
        dns::stop(&b.dns);
        return Err("selftest".into());
    }
    Ok(())
}

fn do_enable(app: &AppHandle, b: &Blocker) -> Result<(), String> {
    start_filter(app, b)?;

    let fallback = fallback_servers(&persist(b).config.fallback);
    match netcfg::run_elevated(&paths::data_dir(app), "enable", &fallback, b.dns.has_v6()) {
        Ok(_) => {
            // The backup now exists, so servers the user had set by hand are known too.
            refresh_upstreams(app, b);
            {
                let mut p = persist(b);
                p.active = true;
                p.paused = false;
                p.last_error.clear();
            }
            b.dns.paused.store(false, Ordering::Relaxed);
            save(app, b);
            logging::write("INFO", "Blocker turned on");
            Ok(())
        }
        Err(e) => {
            // Windows was not changed (or not completely): do not leave a half state behind.
            if !netcfg::backup_exists(&paths::data_dir(app)) {
                dns::stop(&b.dns);
            }
            logging::write("WARN", &format!("Blocker could not be turned on: {}", e));
            Err(e)
        }
    }
}

fn do_restore(app: &AppHandle, b: &Blocker, action: &str) -> Result<(), String> {
    netcfg::run_elevated(&paths::data_dir(app), action, &[], false)?;
    dns::stop(&b.dns);
    {
        let mut p = persist(b);
        p.active = false;
        p.paused = false;
        p.last_error.clear();
    }
    b.dns.paused.store(false, Ordering::Relaxed);
    save(app, b);
    logging::write("INFO", &format!("Blocker turned off ({})", action));
    Ok(())
}

/// Runs one long action on a background thread, making sure only one runs at a time.
async fn run_exclusive<F>(app: AppHandle, work: F) -> Result<Status, String>
where
    F: FnOnce(&AppHandle, &Blocker) -> Result<(), String> + Send + 'static,
{
    let b = blocker(&app);
    if b.busy.swap(true, Ordering::SeqCst) {
        return Err("busy".into());
    }
    let task_app = app.clone();
    let task_b = b.clone();
    let outcome =
        tauri::async_runtime::spawn_blocking(move || work(&task_app, task_b.as_ref())).await;
    b.busy.store(false, Ordering::SeqCst);

    match outcome {
        Ok(Ok(())) => Ok(status_of(&app, &b)),
        Ok(Err(e)) => {
            persist(&b).last_error = e.clone();
            Err(e)
        }
        Err(e) => Err(e.to_string()),
    }
}

// ---------------------------------------------------------------- startup and background work

fn background_tick(app: &AppHandle, b: &Blocker, ticks: u64) {
    if b.dns.is_running() && ticks % 2 == 0 {
        refresh_upstreams(app, b);
    }
    let dirty = b.dns.stats.lock().unwrap_or_else(|e| e.into_inner()).dirty;
    if dirty {
        save(app, b);
    }

    // Automatic list update: checked two minutes after start, then once an hour.
    if ticks == 4 || ticks % 120 == 0 {
        let (active, days, last) = {
            let p = persist(b);
            (p.active, p.config.update_days, p.last_update)
        };
        let due = days > 0 && now_ms() - last > (days as i64) * 24 * 3600 * 1000;
        if active && due && !b.busy.swap(true, Ordering::SeqCst) {
            if let Err(e) = update_lists(app, b) {
                logging::write("WARN", &format!("Automatic blocklist update failed: {}", e));
            }
            save(app, b);
            b.busy.store(false, Ordering::SeqCst);
        }
    }
}

/// Called once when the app starts.
pub fn start(app: &AppHandle) {
    let saved = load(app);
    let shared = Arc::new(dns::Shared::new());
    {
        let mut stats = shared.stats.lock().unwrap_or_else(|e| e.into_inner());
        stats.total = saved.total;
        stats.today = saved.today;
        stats.day = saved.day.clone();
    }
    shared.paused.store(saved.paused, Ordering::Relaxed);
    let was_active = saved.active;

    let b = Arc::new(Blocker {
        persist: Mutex::new(saved),
        dns: shared,
        busy: AtomicBool::new(false),
    });
    app.manage(b.clone());
    apply_doh(&b);

    let _ = netcfg::write_repair_tool(&paths::data_dir(app));

    let handle = app.clone();
    thread::spawn(move || {
        // If the blocker was on when the app last ran (or crashed), Windows is still asking
        // this PC, so the filter is started again right away.
        if was_active {
            match start_filter(&handle, &b) {
                Ok(()) => logging::write("INFO", "Blocker filter restarted"),
                Err(e) => {
                    logging::write("WARN", &format!("Blocker filter could not restart: {}", e));
                    persist(&b).last_error = e;
                }
            }
        }
        let mut ticks: u64 = 0;
        loop {
            thread::sleep(Duration::from_secs(30));
            ticks += 1;
            background_tick(&handle, &b, ticks);
        }
    });
}

/// Called when the app exits: keeps the counters.
pub fn shutdown(app: &AppHandle) {
    if let Some(state) = app.try_state::<Arc<Blocker>>() {
        save(app, state.inner());
    }
}

// ---------------------------------------------------------------- commands for the interface

#[tauri::command]
pub fn blocker_status(app: AppHandle) -> Status {
    let b = blocker(&app);
    status_of(&app, &b)
}

/// Stores new settings and rebuilds the rules (allow list, own block list, chosen lists).
#[tauri::command]
pub async fn blocker_configure(app: AppHandle, config: Config) -> Result<Status, String> {
    let b = blocker(&app);
    let mut config = config;
    config.sources.truncate(20);
    config.custom_sources.truncate(10);
    config.allow.truncate(5000);
    config.block.truncate(5000);
    config.focus.truncate(500);
    config.update_days = config.update_days.min(30);
    persist(&b).config = config;
    apply_doh(&b);

    let task_app = app.clone();
    let task_b = b.clone();
    tauri::async_runtime::spawn_blocking(move || {
        rebuild(&task_app, &task_b);
        if task_b.dns.is_running() {
            refresh_upstreams(&task_app, &task_b);
        }
        save(&task_app, &task_b);
    })
    .await
    .map_err(|e| e.to_string())?;
    Ok(status_of(&app, &b))
}

/// Turns the blocker on. Windows asks for administrator permission.
#[tauri::command]
pub async fn blocker_enable(app: AppHandle) -> Result<Status, String> {
    run_exclusive(app, do_enable).await
}

/// Turns the blocker off and puts the original network settings back.
#[tauri::command]
pub async fn blocker_disable(app: AppHandle) -> Result<Status, String> {
    run_exclusive(app, |app, b| do_restore(app, b, "disable")).await
}

/// Emergency button: every adapter goes back to automatic DNS.
#[tauri::command]
pub async fn blocker_repair(app: AppHandle) -> Result<Status, String> {
    run_exclusive(app, |app, b| do_restore(app, b, "repair")).await
}

/// Downloads the lists now.
#[tauri::command]
pub async fn blocker_update(app: AppHandle) -> Result<Status, String> {
    run_exclusive(app, |app, b| {
        let result = update_lists(app, b).map(|_| ());
        save(app, b);
        result
    })
    .await
}

/// Pauses or resumes blocking without touching Windows settings (no permission question).
#[tauri::command]
pub fn blocker_pause(app: AppHandle, paused: bool) -> Status {
    let b = blocker(&app);
    b.dns.paused.store(paused, Ordering::Relaxed);
    persist(&b).paused = paused;
    save(&app, &b);
    status_of(&app, &b)
}

#[tauri::command]
pub fn blocker_clear_log(app: AppHandle) -> Status {
    let b = blocker(&app);
    b.dns
        .stats
        .lock()
        .unwrap_or_else(|e| e.into_inner())
        .recent
        .clear();
    status_of(&app, &b)
}

/// Tells, for each name, whether the current block rules would block it.
/// Used by the privacy inspector to recognise ad and tracker addresses.
#[tauri::command]
pub fn blocker_check(app: AppHandle, names: Vec<String>) -> Vec<bool> {
    let b = blocker(&app);
    let rules: Arc<lists::Rules> = b
        .dns
        .rules
        .read()
        .unwrap_or_else(|e| e.into_inner())
        .clone();
    names
        .iter()
        .take(2000)
        .map(|name| rules.is_blocked(&name.to_ascii_lowercase()))
        .collect()
}

/// Opens the folder that holds the stand-alone "Repair-Internet.cmd" tool.
#[tauri::command]
pub fn blocker_open_folder(app: AppHandle) -> Result<(), String> {
    let dir = paths::data_dir(&app);
    let _ = netcfg::write_repair_tool(&dir);
    Command::new("explorer.exe")
        .arg(&dir)
        .spawn()
        .map_err(|e| e.to_string())?;
    Ok(())
}
