//! Locations of the files the app stores on disk (all inside the per-user app data folder).

use std::fs;
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, Ordering};

use tauri::{AppHandle, Manager};

/// True when the previous session ended without a clean exit (crash, power loss, kill).
static UNCLEAN_PREVIOUS_EXIT: AtomicBool = AtomicBool::new(false);

/// Per-user data folder, created on demand.
pub fn data_dir(app: &AppHandle) -> PathBuf {
    let dir = app
        .path()
        .app_data_dir()
        .unwrap_or_else(|_| std::env::temp_dir().join("patheyo"));
    let _ = fs::create_dir_all(&dir);
    dir
}

/// The app was first published as "NoorDesk" (data folder "com.noordesk.desktop"). On the first
/// start of Patheyo, the user's settings, widget positions, screen time and histories are copied
/// over once. The ad blocker's state is NOT copied: the network setting belongs to the old app,
/// which puts it back when it is turned off or uninstalled.
pub fn migrate_from_noordesk(app: &AppHandle) {
    let new_dir = data_dir(app);
    if new_dir.join("settings.json").exists() {
        return;
    }
    let old_dir = match app.path().data_dir() {
        Ok(base) => base.join("com.noordesk.desktop"),
        Err(_) => return,
    };
    if !old_dir.join("settings.json").exists() {
        return;
    }
    for name in [
        "settings.json",
        "widgets.json",
        "screentime.json",
        "inspector-history.json",
        "netwatch.json",
    ] {
        let from = old_dir.join(name);
        if from.exists() {
            let _ = fs::copy(&from, new_dir.join(name));
        }
    }
}

pub fn settings_file(app: &AppHandle) -> PathBuf {
    data_dir(app).join("settings.json")
}

pub fn settings_backup_file(app: &AppHandle) -> PathBuf {
    data_dir(app).join("settings.backup.json")
}

pub fn schedule_file(app: &AppHandle) -> PathBuf {
    data_dir(app).join("schedule.json")
}

pub fn widgets_file(app: &AppHandle) -> PathBuf {
    data_dir(app).join("widgets.json")
}

pub fn blocker_file(app: &AppHandle) -> PathBuf {
    data_dir(app).join("blocker.json")
}

pub fn blocklist_dir(app: &AppHandle) -> PathBuf {
    let dir = data_dir(app).join("blocklists");
    let _ = fs::create_dir_all(&dir);
    dir
}

pub fn netwatch_file(app: &AppHandle) -> PathBuf {
    data_dir(app).join("netwatch.json")
}

pub fn screentime_file(app: &AppHandle) -> PathBuf {
    data_dir(app).join("screentime.json")
}

pub fn log_dir(app: &AppHandle) -> PathBuf {
    let dir = data_dir(app).join("logs");
    let _ = fs::create_dir_all(&dir);
    dir
}

fn running_flag(app: &AppHandle) -> PathBuf {
    data_dir(app).join("running.flag")
}

/// Creates the "running" flag. Returns true if it already existed, which means the
/// previous session did not exit cleanly.
pub fn mark_running(app: &AppHandle) -> bool {
    let flag = running_flag(app);
    let unclean = flag.exists();
    UNCLEAN_PREVIOUS_EXIT.store(unclean, Ordering::Relaxed);
    let _ = fs::write(&flag, b"running");
    unclean
}

pub fn clear_running(app: &AppHandle) {
    let _ = fs::remove_file(running_flag(app));
}

pub fn previous_exit_was_unclean() -> bool {
    UNCLEAN_PREVIOUS_EXIT.load(Ordering::Relaxed)
}
