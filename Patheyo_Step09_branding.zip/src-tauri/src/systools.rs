//! Module G: system tools.
//!
//! * Live monitor (CPU, memory, disks, network speed): plain Windows API calls, measured only
//!   when a page or widget asks (about every 2 seconds), so it costs nothing otherwise.
//! * Startup manager, junk cleaner and battery report: bundled PowerShell scripts (see
//!   src-tauri/scripts). Listing is read-only; changes happen only after the user confirms.

use std::collections::HashMap;
use std::process::Command;
use std::sync::Mutex;
use std::time::Instant;

use serde_json::{json, Value};
use tauri::AppHandle;

use crate::{blocker, logging, paths, psrun};

const STARTUP_LIST: &str = include_str!("../scripts/startup-list.ps1");
const STARTUP_SET: &str = include_str!("../scripts/startup-set.ps1");
const JUNK: &str = include_str!("../scripts/junk.ps1");
const BATTERY: &str = include_str!("../scripts/battery.ps1");

const JUNK_CATEGORIES: [&str; 6] = ["temp", "inetcache", "thumbs", "wer", "dumps", "shader"];

// ================================================================ live monitor

#[cfg(windows)]
mod sys {
    use std::ffi::c_void;

    #[repr(C)]
    pub struct MemoryStatusEx {
        pub length: u32,
        pub memory_load: u32,
        pub total_phys: u64,
        pub avail_phys: u64,
        pub total_page_file: u64,
        pub avail_page_file: u64,
        pub total_virtual: u64,
        pub avail_virtual: u64,
        pub avail_extended_virtual: u64,
    }

    #[repr(C)]
    #[derive(Default, Clone, Copy)]
    pub struct FileTime {
        pub low: u32,
        pub high: u32,
    }

    #[link(name = "kernel32")]
    extern "system" {
        pub fn GlobalMemoryStatusEx(status: *mut MemoryStatusEx) -> i32;
        pub fn GetSystemTimes(idle: *mut FileTime, kernel: *mut FileTime, user: *mut FileTime) -> i32;
        pub fn GetLogicalDrives() -> u32;
        pub fn GetDriveTypeW(root: *const u16) -> u32;
        pub fn GetDiskFreeSpaceExW(
            directory: *const u16,
            free_to_caller: *mut u64,
            total: *mut u64,
            total_free: *mut u64,
        ) -> i32;
    }

    #[link(name = "iphlpapi")]
    extern "system" {
        pub fn GetIfTable(table: *mut c_void, size: *mut u32, order: i32) -> u32;
    }
}

/// Values kept from the previous measurement, to turn counters into "per second" numbers.
struct Previous {
    at: Instant,
    idle: u64,
    total: u64,
    /// Network adapter (by hardware address) -> (bytes received, bytes sent), 32-bit counters.
    net: HashMap<String, (u32, u32)>,
}

static PREVIOUS: Mutex<Option<Previous>> = Mutex::new(None);

#[cfg(windows)]
fn cpu_times() -> Option<(u64, u64)> {
    let (mut idle, mut kernel, mut user) = (
        sys::FileTime::default(),
        sys::FileTime::default(),
        sys::FileTime::default(),
    );
    if unsafe { sys::GetSystemTimes(&mut idle, &mut kernel, &mut user) } == 0 {
        return None;
    }
    let value = |t: sys::FileTime| ((t.high as u64) << 32) | t.low as u64;
    // Kernel time already includes idle time.
    Some((value(idle), value(kernel) + value(user)))
}

#[cfg(windows)]
fn memory() -> Value {
    let mut status = sys::MemoryStatusEx {
        length: std::mem::size_of::<sys::MemoryStatusEx>() as u32,
        memory_load: 0,
        total_phys: 0,
        avail_phys: 0,
        total_page_file: 0,
        avail_page_file: 0,
        total_virtual: 0,
        avail_virtual: 0,
        avail_extended_virtual: 0,
    };
    if unsafe { sys::GlobalMemoryStatusEx(&mut status) } == 0 {
        return Value::Null;
    }
    json!({
        "total": status.total_phys,
        "used": status.total_phys.saturating_sub(status.avail_phys),
        "percent": status.memory_load,
    })
}

#[cfg(windows)]
fn disks() -> Vec<Value> {
    const DRIVE_FIXED: u32 = 3;
    let mask = unsafe { sys::GetLogicalDrives() };
    let mut out = Vec::new();
    for index in 0..26u32 {
        if mask & (1 << index) == 0 {
            continue;
        }
        let letter = (b'A' + index as u8) as char;
        let root: Vec<u16> = format!("{}:\\", letter).encode_utf16().chain(Some(0)).collect();
        if unsafe { sys::GetDriveTypeW(root.as_ptr()) } != DRIVE_FIXED {
            continue;
        }
        let (mut free_to_caller, mut total, mut total_free) = (0u64, 0u64, 0u64);
        let ok = unsafe {
            sys::GetDiskFreeSpaceExW(root.as_ptr(), &mut free_to_caller, &mut total, &mut total_free)
        };
        if ok != 0 && total > 0 {
            out.push(json!({ "drive": format!("{}:", letter), "total": total, "free": total_free }));
        }
    }
    out
}

/// Byte counters of each network adapter. The same adapter can appear several times (once
/// per filter driver), so rows are grouped by hardware address and the largest value is used.
#[cfg(windows)]
fn net_counters() -> HashMap<String, (u32, u32)> {
    const ROW: usize = 860; // size of MIB_IFROW
    const TYPE_LOOPBACK: u32 = 24;
    const TYPE_TUNNEL: u32 = 131;
    let mut out: HashMap<String, (u32, u32)> = HashMap::new();

    let mut size: u32 = 0;
    unsafe {
        sys::GetIfTable(std::ptr::null_mut(), &mut size, 0);
    }
    if size == 0 {
        return out;
    }
    let mut buffer = vec![0u8; size as usize + ROW * 4];
    let mut length = buffer.len() as u32;
    if unsafe { sys::GetIfTable(buffer.as_mut_ptr() as *mut std::ffi::c_void, &mut length, 0) } != 0 {
        return out;
    }
    let read_u32 = |offset: usize| -> u32 {
        buffer
            .get(offset..offset + 4)
            .map(|b| u32::from_ne_bytes([b[0], b[1], b[2], b[3]]))
            .unwrap_or(0)
    };
    let count = read_u32(0) as usize;
    for index in 0..count {
        let row = 4 + index * ROW;
        if row + ROW > buffer.len() {
            break;
        }
        let kind = read_u32(row + 516);
        if kind == TYPE_LOOPBACK || kind == TYPE_TUNNEL {
            continue;
        }
        let address_length = (read_u32(row + 528) as usize).min(8);
        if address_length == 0 {
            continue;
        }
        let address: String = buffer[row + 532..row + 532 + address_length]
            .iter()
            .map(|b| format!("{:02x}", b))
            .collect();
        if address.chars().all(|c| c == '0') {
            continue;
        }
        let received = read_u32(row + 552);
        let sent = read_u32(row + 576);
        let entry = out.entry(address).or_insert((0, 0));
        entry.0 = entry.0.max(received);
        entry.1 = entry.1.max(sent);
    }
    out
}

#[cfg(windows)]
fn sample() -> Value {
    let now = Instant::now();
    let times = cpu_times();
    let net = net_counters();

    let mut previous = PREVIOUS.lock().unwrap_or_else(|e| e.into_inner());
    let mut cpu: Option<f64> = None;
    let mut down: Option<f64> = None;
    let mut up: Option<f64> = None;

    if let (Some(prev), Some((idle, total))) = (previous.as_ref(), times) {
        let total_delta = total.saturating_sub(prev.total);
        let idle_delta = idle.saturating_sub(prev.idle);
        if total_delta > 0 {
            let busy = 1.0 - (idle_delta as f64 / total_delta as f64);
            cpu = Some((busy * 100.0).clamp(0.0, 100.0));
        }
        let seconds = now.duration_since(prev.at).as_secs_f64();
        if seconds > 0.2 {
            let (mut received, mut sent) = (0u64, 0u64);
            for (address, (r, s)) in &net {
                if let Some((pr, ps)) = prev.net.get(address) {
                    // 32-bit counters wrap around; wrapping subtraction handles that.
                    received += r.wrapping_sub(*pr) as u64;
                    sent += s.wrapping_sub(*ps) as u64;
                }
            }
            down = Some(received as f64 / seconds);
            up = Some(sent as f64 / seconds);
        }
    }
    if let Some((idle, total)) = times {
        *previous = Some(Previous { at: now, idle, total, net });
    }

    json!({
        "cpu": cpu,
        "memory": memory(),
        "disks": disks(),
        "net": { "down": down, "up": up },
    })
}

#[cfg(not(windows))]
fn sample() -> Value {
    let _ = (&PREVIOUS, Instant::now());
    json!({ "cpu": null, "memory": null, "disks": [], "net": { "down": null, "up": null } })
}

/// One measurement of CPU, memory, disks and network speed.
#[tauri::command]
pub fn sysmon_sample() -> Value {
    sample()
}

// ================================================================ startup manager

#[tauri::command]
pub async fn startup_list(app: AppHandle) -> Result<Value, String> {
    tauri::async_runtime::spawn_blocking(move || {
        psrun::run_checked(&app, "startup-list", STARTUP_LIST, &json!({}), false)
    })
    .await
    .map_err(|e| e.to_string())?
}

/// Switches one startup entry on or off. Entries for all users ("HKLM") need administrator
/// rights, so Windows asks for permission for those.
#[tauri::command]
pub async fn startup_set(
    app: AppHandle,
    scope: String,
    approved_key: String,
    name: String,
    enable: bool,
) -> Result<Value, String> {
    if scope != "HKCU" && scope != "HKLM" {
        return Err("Invalid scope".into());
    }
    if !matches!(approved_key.as_str(), "Run" | "Run32" | "StartupFolder") {
        return Err("Invalid key".into());
    }
    let name: String = name.chars().take(260).collect();
    if name.trim().is_empty() {
        return Err("Invalid name".into());
    }
    let elevated = scope == "HKLM";
    tauri::async_runtime::spawn_blocking(move || {
        let input = json!({ "scope": scope, "approvedKey": approved_key, "name": name, "enable": enable });
        let result = psrun::run_checked(&app, "startup-set", STARTUP_SET, &input, elevated);
        if result.is_ok() {
            logging::write(
                "INFO",
                &format!("Startup entry {}: {}", if enable { "enabled" } else { "disabled" }, name),
            );
        }
        result
    })
    .await
    .map_err(|e| e.to_string())?
}

// ================================================================ junk cleaner

/// Measures what could be deleted. Read-only.
#[tauri::command]
pub async fn junk_scan(app: AppHandle) -> Result<Value, String> {
    tauri::async_runtime::spawn_blocking(move || {
        psrun::run_checked(&app, "junk", JUNK, &json!({ "mode": "scan", "categories": [] }), false)
    })
    .await
    .map_err(|e| e.to_string())?
}

/// Deletes the files of the chosen categories. The interface shows the preview and asks for
/// confirmation before calling this.
#[tauri::command]
pub async fn junk_clean(app: AppHandle, categories: Vec<String>) -> Result<Value, String> {
    let chosen: Vec<String> = categories
        .into_iter()
        .filter(|c| JUNK_CATEGORIES.contains(&c.as_str()))
        .collect();
    if chosen.is_empty() {
        return Err("Nothing was chosen".into());
    }
    tauri::async_runtime::spawn_blocking(move || {
        let result = psrun::run_checked(&app, "junk", JUNK, &json!({ "mode": "clean", "categories": chosen }), false);
        logging::write("INFO", &format!("Junk cleaner ran: {}", chosen.join(", ")));
        result
    })
    .await
    .map_err(|e| e.to_string())?
}

// ================================================================ battery

#[tauri::command]
pub async fn battery_info(app: AppHandle) -> Result<Value, String> {
    tauri::async_runtime::spawn_blocking(move || {
        psrun::run_checked(&app, "battery", BATTERY, &json!({}), false)
    })
    .await
    .map_err(|e| e.to_string())?
}

/// Creates the full Windows battery report (HTML) and opens it in the browser.
#[tauri::command]
pub async fn battery_report_open(app: AppHandle) -> Result<(), String> {
    tauri::async_runtime::spawn_blocking(move || {
        let path = paths::data_dir(&app).join("battery-report.html");
        let _ = std::fs::remove_file(&path);
        let mut command = Command::new("powercfg.exe");
        command.arg("/batteryreport").arg("/output").arg(&path);
        blocker::hide_window(&mut command);
        command
            .status()
            .map_err(|e| format!("powercfg could not be started: {}", e))?;
        if !path.exists() {
            return Err("The battery report was not created".to_string());
        }
        Command::new("explorer.exe")
            .arg(&path)
            .spawn()
            .map_err(|e| e.to_string())?;
        Ok(())
    })
    .await
    .map_err(|e| e.to_string())?
}
