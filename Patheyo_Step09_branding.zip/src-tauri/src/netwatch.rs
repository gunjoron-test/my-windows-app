//! Module E: "new program on the network" alert.
//!
//! While switched on, the list of open TCP connections is read every few seconds (a cheap
//! Windows call, no extra program is started). The first time a program that was never seen
//! before has a connection, the user is told and can allow it or block it with a firewall rule.
//! Only the program's file path is remembered; no traffic is inspected.

use std::collections::HashSet;
use std::fs;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex, MutexGuard};
use std::thread;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use serde::{Deserialize, Serialize};
use tauri::{AppHandle, Emitter, Manager};

use crate::{alarm, logging, paths};

const POLL_SECONDS: u64 = 5;
/// After switching the alert on, programs seen during this time are learned silently,
/// so the user is not flooded with alerts for programs that are already in use.
const LEARNING_MS: i64 = 120_000;
const MAX_PENDING: usize = 50;
const MAX_KNOWN: usize = 5000;

#[derive(Clone, Debug, Default, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct Pending {
    /// Full path of the program file (lower-case).
    pub path: String,
    /// File name, for display.
    pub name: String,
    pub first_seen: i64,
}

#[derive(Default, Serialize, Deserialize)]
#[serde(default)]
struct Saved {
    known: Vec<String>,
    pending: Vec<Pending>,
}

#[derive(Default)]
struct State {
    known: HashSet<String>,
    pending: Vec<Pending>,
    learning_until: i64,
    /// Notification text, translated by the interface. "{name}" is replaced by the program name.
    title: String,
    body: String,
    dirty: bool,
}

pub struct Watch {
    enabled: AtomicBool,
    state: Mutex<State>,
}

fn now_ms() -> i64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as i64)
        .unwrap_or(0)
}

fn lock(watch: &Watch) -> MutexGuard<'_, State> {
    watch.state.lock().unwrap_or_else(|e| e.into_inner())
}

fn watch_of(app: &AppHandle) -> Arc<Watch> {
    app.state::<Arc<Watch>>().inner().clone()
}

fn file_name(path: &str) -> String {
    path.rsplit('\\').next().unwrap_or(path).to_string()
}

fn save(app: &AppHandle, watch: &Watch) {
    let text = {
        let mut state = lock(watch);
        state.dirty = false;
        let mut known: Vec<String> = state.known.iter().cloned().collect();
        known.sort();
        serde_json::to_string(&Saved {
            known,
            pending: state.pending.clone(),
        })
        .unwrap_or_default()
    };
    if text.is_empty() {
        return;
    }
    let path = paths::netwatch_file(app);
    let temp = path.with_extension("json.tmp");
    if fs::write(&temp, text.as_bytes()).is_ok() {
        let _ = fs::rename(&temp, &path);
    }
}

// ---------------------------------------------------------------- Windows calls

#[cfg(windows)]
mod sys {
    use std::ffi::c_void;

    #[link(name = "iphlpapi")]
    extern "system" {
        pub fn GetExtendedTcpTable(
            table: *mut c_void,
            size: *mut u32,
            order: i32,
            address_family: u32,
            table_class: u32,
            reserved: u32,
        ) -> u32;
    }

    #[link(name = "kernel32")]
    extern "system" {
        pub fn OpenProcess(access: u32, inherit_handle: i32, process_id: u32) -> *mut c_void;
        pub fn QueryFullProcessImageNameW(
            process: *mut c_void,
            flags: u32,
            name: *mut u16,
            size: *mut u32,
        ) -> i32;
        pub fn CloseHandle(handle: *mut c_void) -> i32;
    }

    const AF_INET: u32 = 2;
    const AF_INET6: u32 = 23;
    /// TCP_TABLE_OWNER_PID_CONNECTIONS: open connections with the id of the owning process.
    const OWNER_PID_CONNECTIONS: u32 = 4;
    const PROCESS_QUERY_LIMITED_INFORMATION: u32 = 0x1000;

    fn read_table(address_family: u32) -> Vec<u8> {
        let mut size: u32 = 0;
        unsafe {
            GetExtendedTcpTable(
                std::ptr::null_mut(),
                &mut size,
                0,
                address_family,
                OWNER_PID_CONNECTIONS,
                0,
            );
        }
        for _ in 0..3 {
            if size == 0 {
                return Vec::new();
            }
            let mut buffer = vec![0u8; size as usize + 2048];
            let mut length = buffer.len() as u32;
            let code = unsafe {
                GetExtendedTcpTable(
                    buffer.as_mut_ptr() as *mut c_void,
                    &mut length,
                    0,
                    address_family,
                    OWNER_PID_CONNECTIONS,
                    0,
                )
            };
            if code == 0 {
                return buffer;
            }
            size = length; // the table grew in the meantime: try again with the new size
        }
        Vec::new()
    }

    fn u32_at(buffer: &[u8], offset: usize) -> u32 {
        match buffer.get(offset..offset + 4) {
            Some(bytes) => u32::from_ne_bytes([bytes[0], bytes[1], bytes[2], bytes[3]]),
            None => 0,
        }
    }

    /// Ids of the processes that have a TCP connection to another computer right now.
    pub fn connected_process_ids() -> Vec<u32> {
        let mut ids: Vec<u32> = Vec::new();

        // IPv4 rows are 24 bytes: state, local address, local port, remote address, remote port, pid.
        let table = read_table(AF_INET);
        let count = u32_at(&table, 0) as usize;
        for index in 0..count {
            let row = 4 + index * 24;
            let remote = match table.get(row + 12..row + 16) {
                Some(bytes) => bytes,
                None => break,
            };
            if remote[0] == 127 || remote.iter().all(|b| *b == 0) {
                continue; // connection to this PC itself
            }
            ids.push(u32_at(&table, row + 20));
        }

        // IPv6 rows are 56 bytes: local address (16), scope, port, remote address (16), scope,
        // port, state, pid.
        let table = read_table(AF_INET6);
        let count = u32_at(&table, 0) as usize;
        for index in 0..count {
            let row = 4 + index * 56;
            let remote = match table.get(row + 24..row + 40) {
                Some(bytes) => bytes,
                None => break,
            };
            let is_zero = remote.iter().all(|b| *b == 0);
            let is_loopback = remote[..15].iter().all(|b| *b == 0) && remote[15] == 1;
            if is_zero || is_loopback {
                continue;
            }
            ids.push(u32_at(&table, row + 52));
        }

        ids.sort_unstable();
        ids.dedup();
        ids
    }

    /// Full path of the program file of a process, or None for protected system processes.
    pub fn process_path(process_id: u32) -> Option<String> {
        if process_id == 0 || process_id == 4 {
            return None;
        }
        unsafe {
            let handle = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, process_id);
            if handle.is_null() {
                return None;
            }
            let mut buffer = [0u16; 1024];
            let mut length: u32 = buffer.len() as u32;
            let ok = QueryFullProcessImageNameW(handle, 0, buffer.as_mut_ptr(), &mut length);
            CloseHandle(handle);
            if ok == 0 || length == 0 {
                return None;
            }
            Some(String::from_utf16_lossy(&buffer[..length as usize]))
        }
    }
}

#[cfg(not(windows))]
mod sys {
    pub fn connected_process_ids() -> Vec<u32> {
        Vec::new()
    }
    pub fn process_path(_process_id: u32) -> Option<String> {
        None
    }
}

// ---------------------------------------------------------------- watching

fn check(app: &AppHandle, watch: &Watch, own_path: &str) {
    let now = now_ms();
    let mut fresh: Vec<Pending> = Vec::new();
    {
        let mut state = lock(watch);
        for process_id in sys::connected_process_ids() {
            let path = match sys::process_path(process_id) {
                Some(path) => path.to_lowercase(),
                None => continue,
            };
            if path == own_path || state.known.contains(&path) {
                continue;
            }
            if state.pending.iter().any(|p| p.path == path) {
                continue;
            }
            if now < state.learning_until || state.known.len() >= MAX_KNOWN {
                state.known.insert(path);
                state.dirty = true;
                continue;
            }
            let entry = Pending {
                name: file_name(&path),
                path,
                first_seen: now,
            };
            state.pending.push(entry.clone());
            let extra = state.pending.len().saturating_sub(MAX_PENDING);
            if extra > 0 {
                state.pending.drain(0..extra);
            }
            state.dirty = true;
            fresh.push(entry);
        }
    }

    for entry in fresh {
        logging::write("INFO", &format!("New program on the network: {}", entry.path));
        let (title, body) = {
            let state = lock(watch);
            (state.title.clone(), state.body.replace("{name}", &entry.name))
        };
        if !title.is_empty() {
            alarm::toast(app, &title, &body);
        }
        let _ = app.emit("netwatch-new", entry.clone());
    }
}

/// Called once when the app starts.
pub fn start(app: &AppHandle) {
    let saved: Saved = fs::read_to_string(paths::netwatch_file(app))
        .ok()
        .and_then(|text| serde_json::from_str::<Saved>(&text).ok())
        .unwrap_or_default();

    let watch = Arc::new(Watch {
        enabled: AtomicBool::new(false),
        state: Mutex::new(State {
            known: saved.known.into_iter().collect(),
            pending: saved.pending,
            ..Default::default()
        }),
    });
    app.manage(watch.clone());

    let own_path = std::env::current_exe()
        .map(|p| p.to_string_lossy().to_lowercase())
        .unwrap_or_default();
    let handle = app.clone();
    thread::spawn(move || loop {
        thread::sleep(Duration::from_secs(POLL_SECONDS));
        if !watch.enabled.load(Ordering::Relaxed) {
            continue;
        }
        check(&handle, &watch, &own_path);
        let dirty = lock(&watch).dirty;
        if dirty {
            save(&handle, &watch);
        }
    });
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct WatchStatus {
    enabled: bool,
    learning: bool,
    known: usize,
    pending: Vec<Pending>,
}

fn status_of(watch: &Watch) -> WatchStatus {
    let state = lock(watch);
    WatchStatus {
        enabled: watch.enabled.load(Ordering::Relaxed),
        learning: now_ms() < state.learning_until,
        known: state.known.len(),
        pending: state.pending.clone(),
    }
}

/// Switches the alert on or off and sets the translated notification text.
#[tauri::command]
pub fn netwatch_configure(app: AppHandle, enabled: bool, title: String, body: String) -> WatchStatus {
    let watch = watch_of(&app);
    let was_enabled = watch.enabled.swap(enabled, Ordering::Relaxed);
    {
        let mut state = lock(&watch);
        state.title = title.chars().take(120).collect();
        state.body = body.chars().take(300).collect();
        if enabled && !was_enabled {
            state.learning_until = now_ms() + LEARNING_MS;
        }
    }
    status_of(&watch)
}

#[tauri::command]
pub fn netwatch_status(app: AppHandle) -> WatchStatus {
    status_of(&watch_of(&app))
}

/// The user decided about a new program: it is remembered and leaves the waiting list.
/// (Blocking is done separately through the firewall manager.)
#[tauri::command]
pub fn netwatch_decide(app: AppHandle, path: String) -> WatchStatus {
    let watch = watch_of(&app);
    {
        let mut state = lock(&watch);
        let path = path.to_lowercase();
        state.pending.retain(|p| p.path != path);
        if state.known.len() < MAX_KNOWN {
            state.known.insert(path);
        }
        state.dirty = true;
    }
    save(&app, &watch);
    status_of(&watch)
}
