# Patheyo User Guide (version 1.0.0)

Patheyo is a lightweight app for Windows 10/11. It includes prayer times and alarms, desktop widgets, a system-wide ad blocker, a privacy check, a firewall manager and cleaner, focus and productivity tools, and system tools.

The app sends none of your data anywhere (no analytics, no telemetry). It uses the internet only for features you switch on yourself.

---

## 1. Installing and first start

1. Double-click the `Patheyo_..._x64-setup.exe` file you downloaded from GitHub.
2. If Windows shows "Windows protected your PC", press **More info → Run anyway**. This appears because the app is not signed with a paid certificate.
3. After installing, the first-run setup appears: language and theme, your city, the calculation method, alarms, and "Start with Windows".
4. **The window ✕ button does not quit the app**; it moves to the tray (bottom-right corner of the screen). Click the tray icon to open it again. To quit completely, right-click the tray icon and choose "Quit".

Installing does not need administrator rights; the app is installed for your account only.

---

## 2. Prayer times and alarms

- **"Prayer times" page:** today's five prayers and sunrise, the current prayer, a countdown to the next one, and the Gregorian and Hijri dates.
- **Location and calculation (Settings):** a city or latitude/longitude, the calculation method (Karachi, Muslim World League, Umm al-Qura, ISNA, Egyptian, Islamic Foundation Bangladesh), and the Asr school. To match your mosque timetable, each prayer can be adjusted by up to ±60 minutes.
- **"Alarms" page:**
  - Switch the alarm of each prayer on or off, and add a reminder 5–30 minutes before.
  - Sound: one of the three built-in sounds, or your own audio file (for example an adhan MP3). Volume and snooze length can be changed.
  - Ramadan mode: alarms for the end of Sehri and for Iftar.
  - Wake from sleep (optional, not guaranteed on every PC).
- **When an alarm rings,** a large popup and sound appear: "Stop" or "Snooze 5 min".

> **Remember:** alarms ring only while the PC is on and the app runs in the tray. They do not ring when the PC is fully shut down. If an alarm is missed while the PC sleeps, a "missed alarm" notice appears after it wakes.

---

## 3. Desktop widgets

Switch them on from the "Widgets" page:

| Widget | Shows |
|---|---|
| Prayer times | the five prayers, the current one, a countdown |
| Clock and date | the clock with Gregorian, Hijri and Bengali dates |
| Next prayer | only the countdown to the next prayer |
| Notes | notes you can write right on the desktop |
| Tasks | open tasks; tick to finish, press Enter to add one |
| Calendar | this month, today and task due dates |
| Weather | the current weather (switch it on in Settings first) |
| System monitor | CPU, RAM, disk and network speed |

- **Using them:** drag a widget with the mouse; drag its bottom-right corner to resize. Hover over a widget to see the lock, settings and hide buttons.
- **Settings for each widget:** design (green, white, dark, clear glass), opacity, and where it stays (normal / always on top / pinned to the desktop).

---

## 4. Ad and tracker blocker

1. On the "Ad blocker" page press **"Turn blocker on"** and answer **Yes** when Windows asks. The first time, downloading the lists can take up to half a minute.
2. While it is on, ad and tracker addresses are blocked for every program on the PC. You can see how many were blocked today and in total.
3. **"Pause"** stops blocking for a while without any permission question.
4. **If a site is blocked by mistake,** press "Allow" in the list, or type the address into the allow list.
5. **Extra filters (optional):** malware, phishing, adult content, gambling.
6. **Encrypted DNS (optional):** Cloudflare, Quad9 or Google.

**If the internet stops working,** press "Repair internet connection". If the app does not open, double-click `Repair-Internet.cmd` in the app data folder (its location is shown on the About page).

**To be honest:**
- Ads that come from the same address as the content, such as ads inside YouTube videos, cannot be blocked this way.
- A browser with "Secure DNS" switched on bypasses the blocker.
- While the app is closed nothing is blocked, but the internet keeps working.

---

## 5. Privacy check

- **"Start scan"** checks the Windows privacy settings, camera/microphone/location permissions, startup programs, known telemetry programs and internet connections.
- **Every item shows** its severity (High/Medium/Low), an explanation, and a "Turn off" button or steps to do it yourself.
- **Privacy score (0–100):** how it is calculated is shown under "How the score is calculated".
- **Undo:** every changed setting can be put back from "Change history".

No tool can detect every kind of tracking; the report shows only known things that can be checked.

---

## 6. Firewall and cleaner

- **"Firewall" page:**
  - Block a program's internet, remove rules made by this app, and switch rules of other programs on or off.
  - Every change can be undone from the history, and Windows asks for permission each time.
  - **New program alert:** tells you when a never-seen program uses the internet.
- **"Cleaner" page:**
  - Deletes cookies, history and cache of Chrome, Edge, Brave and Firefox, and clears the clipboard.
  - It scans first and shows the sizes, then asks for confirmation before deleting.
  - Bookmarks and saved passwords are never deleted. Data of a running browser cannot be deleted.

---

## 7. Focus, tasks and screen time

- **"Focus" page:**
  - **Pomodoro timer:** 25 minutes of work, then a break.
  - **Focus mode:** blocks chosen sites (needs the ad blocker on) and warns about or closes chosen programs. Start it by hand (25 min / 1 h / 2 h) or set days and times for a schedule.
  - **Reminders:** eye rest (20-20-20) and drinking water.
- **"Tasks and notes" page:** a to-do list with due dates, and quick notes.
- **"Screen time" page:** how much time each program was used. Off by default; when on, only program names and times are saved on your PC.
- **Weather (Settings):** when on, the weather comes from Open-Meteo; only your approximate position is sent.

---

## 8. System tools

- **"System monitor" page:** live CPU, RAM, disk space and network speed. On laptops: battery charge and health, and the full Windows battery report.
- **"Startup programs" page:** switch programs that start with Windows on or off (like Task Manager; always reversible).
- **"Junk files" page:** deletes temporary and cache files. Scan first, tick what to delete, then confirm. Personal folders, system files and the Recycle Bin are never touched.

---

## 9. Settings, logs and uninstalling

- **Settings:** language (বাংলা/English), theme, time format, start with Windows, location and calculation, weather, module on/off, export logs, run the first-run setup again, reset all settings.
- **If something goes wrong:** use Settings > "Export logs", save the log file and send it.
- **Uninstalling:**
  1. First turn the ad blocker completely off.
  2. Open Windows Settings > Apps > Installed apps, find Patheyo and press Uninstall.
  3. The uninstaller removes the "Start with Windows" entry by itself. If DNS or firewall settings were changed, it asks for permission once and puts them back.
  4. To also delete your settings and data, tick "Delete the application data".
