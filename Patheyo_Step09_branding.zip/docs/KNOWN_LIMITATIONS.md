# সীমাবদ্ধতা / Known limitations (version 1.0.0)

প্রতিটি বিষয় প্রথমে বাংলায়, তারপর ইংরেজিতে।
Each item is given in Bengali first, then in English.

---

## সাধারণ / General

1. **কোড সাইনিং নেই।** ইনস্টলারটি সার্টিফিকেট দিয়ে সই করা নয়, তাই Windows SmartScreen "Run anyway" চাইতে পারে। সার্টিফিকেট কিনে GitHub-এর বিল্ডে যোগ করা যায়।
   *No code signing. The installer is unsigned, so Windows SmartScreen may ask for "Run anyway". A certificate can be bought and added to the GitHub build.*
2. **মেমোরি।** অ্যাপের পর্দা Microsoft WebView2 দিয়ে চলে। প্রতিটি জানালা (মূল জানালা ও প্রতিটি উইজেট) কিছু মেমোরি নেয়, তাই কয়েকটি উইজেট চালু থাকলে মোট মেমোরি ~১০০ MB লক্ষ্যের বেশি হতে পারে। আসল সংখ্যা পরীক্ষার তালিকার "ঝ১" ধাপে মাপতে হবে।
   *Memory. The interface runs on Microsoft WebView2. Every window (the main window and each widget) uses some memory, so with several widgets on, the total can exceed the ~100 MB target. The real number has to be measured (checklist step ঝ১).*
3. **শুধু Windows 10 (1903+) ও 11, x64।** ARM পিসির জন্য আলাদা বিল্ড নেই।
   *Windows 10 (1903+) and 11, x64 only. There is no separate build for ARM PCs.*
4. **আপডেট নিজে থেকে আসে না।** নতুন সংস্করণ নতুন ইনস্টলার দিয়ে পুরোনোটির ওপর ইনস্টল করতে হয়; সেটিংস থেকে যায়।
   *No automatic updates. A new version is installed over the old one with a new installer; settings are kept.*
5. **বাংলা ফন্ট।** আলাদা ফন্ট ফাইল যোগ করা হয়নি; Windows-এর নিজস্ব বাংলা ফন্ট (Nirmala UI) ব্যবহার হয়।
   *Bengali font. No font file is bundled; the Windows Bengali font (Nirmala UI) is used.*

## নামাজ ও অ্যালার্ম / Prayer and alarms

6. **পিসি পুরোপুরি বন্ধ থাকলে অ্যালার্ম বাজে না।** স্লিপ থেকে জাগানো সব পিসিতে কাজ করে না।
   *Alarms do not ring when the PC is fully shut down. Waking from sleep does not work on every PC.*
7. **হিসাব করা সময় ছাপানো সময়সূচি থেকে কয়েক মিনিট ভিন্ন হতে পারে।** "ইসলামিক ফাউন্ডেশন বাংলাদেশ" পদ্ধতিতে ১৮°/১৮° কোণ ব্যবহার হয়। মিনিট সমন্বয় দিয়ে মেলাতে হয়।
   *Calculated times can differ from a printed timetable by a few minutes. The "Islamic Foundation Bangladesh" method uses 18°/18°. Use the minute adjustment to match.*
8. **আযানের রেকর্ডিং অ্যাপে নেই;** নিজের অডিও ফাইল বেছে নিতে হয়। শব্দ ও ভলিউম সব ওয়াক্তের জন্য একটাই।
   *No adhan recording is bundled; choose your own audio file. One sound and volume for all prayers.*
9. **হিজরি তারিখ হিসাব করা (উম্মুল কুরা ক্যালেন্ডার);** চাঁদ দেখার সাথে এক দিন পার্থক্য হতে পারে। বাংলা তারিখ বাংলাদেশের সংশোধিত পঞ্জিকা অনুযায়ী।
   *The Hijri date is calculated (Umm al-Qura); it can differ from moon sighting by a day. The Bengali date follows the revised Bangladesh calendar.*

## অ্যাড ব্লকার / Ad blocker

10. **একই ঠিকানা থেকে আসা বিজ্ঞাপন** (যেমন YouTube ভিডিওর বিজ্ঞাপন) ব্লক হয় না। HTTPS খোলা হয় না, কোনো সার্টিফিকেট বসানো হয় না।
    *Ads from the same address as the content (such as YouTube video ads) are not blocked. HTTPS is never opened and no certificate is installed.*
11. **ব্রাউজারের "Secure DNS"** চালু থাকলে সেই ব্রাউজার ব্লকার, পারিবারিক ফিল্টার ও ফোকাস-সাইট ব্লক এড়িয়ে যায়।
    *A browser with "Secure DNS" on bypasses the blocker, the family filter and focus-mode site blocking.*
12. **অ্যাপ বন্ধ থাকলে ব্লকিং হয় না** (ইন্টারনেট চলে)। কোন প্রোগ্রাম কোন ঠিকানা চেয়েছিল তা ব্লকারের তালিকায় দেখানো যায় না।
    *Nothing is blocked while the app is closed (the internet keeps working). The blocker log cannot show which program asked for an address.*
13. **চালু ও পুরোপুরি বন্ধ করতে প্রতিবার Windows অনুমতি চায়।** পোর্ট ৫৩ অন্য কোনো DNS টুল ব্যবহার করলে ব্লকার চালু হয় না।
    *Turning it on and fully off asks for Windows permission each time. It cannot start if another DNS tool uses port 53.*
14. **আনইনস্টলের সময়** DNS "স্বয়ংক্রিয়" করে দেওয়া হয়। আগে হাতে বসানো DNS থাকলে সেটি ফেরাতে আনইনস্টলের আগে ব্লকার "পুরোপুরি বন্ধ" করুন।
    *On uninstall the DNS setting is set to automatic. If you had a DNS server set by hand, turn the blocker fully off before uninstalling to get it back exactly.*

## প্রাইভেসি, ফায়ারওয়াল, ক্লিনার / Privacy, firewall, cleaner

15. **কোনো স্ক্যানই সব ট্র্যাকিং ধরতে পারে না।** স্বয়ংক্রিয় "বন্ধ করুন" শুধু আপনার নিজের অ্যাকাউন্টের সেটিংসে কাজ করে; পুরো পিসির সেটিংসের জন্য নিজে করার ধাপ দেওয়া থাকে। প্রোগ্রামের তালিকা ছোট (১৩টি), JSON ফাইল দিয়ে বাড়ানো যায়।
    *No scan finds all tracking. Automatic fixes only change settings of your own account; for machine-wide settings, steps to do it yourself are shown. The program list is small (13) and can be extended in a JSON file.*
16. **ইন্টারনেট সংযোগের অংশ শুধু স্ক্যানের মুহূর্তের ছবি।** ঠিকানার নাম জানা যায় কেবল Windows নিজে নামটি খুঁজে থাকলে।
    *The connections part is a snapshot; address names are known only if Windows itself looked them up.*
17. **ফায়ারওয়ালে অন্য প্রোগ্রামের নিয়ম মোছা যায় না**, শুধু চালু/বন্ধ করা যায়। নতুন নিয়ম শুধু "ব্লক" ধরনের। নতুন প্রোগ্রামের নোটিফিকেশনে সরাসরি Allow/Block বোতাম নেই।
    *Rules of other programs cannot be deleted, only switched on/off. New rules are block rules only. The new-program notification has no Allow/Block buttons.*
18. **ক্লিনারে মোছা ডেটা ফেরানো যায় না।** Firefox-এর হিস্ট্রি মোছা হয় না (বুকমার্কের সাথে একই ফাইলে থাকে)। চালু থাকা ব্রাউজার (Edge প্রায়ই পেছনে চলে) বাদ যায়।
    *Cleaned data cannot be restored. Firefox history is not deleted (it shares a file with bookmarks). Running browsers (Edge often runs in the background) are skipped.*

## প্রোডাক্টিভিটি ও সিস্টেম / Productivity and system

19. **ফোকাস মোডে "বন্ধ করে দিন"** বাছলে সেভ না করা কাজ হারাতে পারে। Pomodoro অ্যাপ বন্ধ করলে বাতিল হয়। স্লিপের সময়ের রিমাইন্ডার পরে আসে না।
    *"Close it" in focus mode can lose unsaved work. The Pomodoro timer is cancelled when the app quits. Reminders due during sleep are not shown later.*
20. **স্ক্রিন টাইম শুধু প্রোগ্রাম ধরে হিসাব রাখে** (ওয়েবসাইট ধরে নয়), ৩১ দিন পর্যন্ত।
    *Screen time is per program (not per website) and is kept for 31 days.*
21. **স্টার্টআপের "প্রভাব" আনুমানিক** (এখনকার মেমোরি দেখে)। Task Scheduler ও সার্ভিস হিসেবে চালু হওয়া প্রোগ্রাম তালিকায় আসে না।
    *Startup "impact" is an estimate (from current memory use). Programs started by Task Scheduler or as services are not listed.*
22. **ডিস্কের পড়া/লেখার গতি দেখানো হয় না**, শুধু জায়গা। সিস্টেমের Temp ও Windows Update-এর ফাইল মোছা হয় না; এর জন্য Storage Sense খোলার বোতাম আছে।
    *Disk read/write speed is not shown, only space. System Temp and Windows Update files are not cleaned; a button opens Storage Sense instead.*

## ভবিষ্যতের জন্য রাখা (এখন বানানো হয়নি) / Planned for later (not built)

কুরআন পাঠ ও অডিও, দোয়া/হাদিস উইজেট, কিবলা, তাসবিহ, রোজার ক্যালেন্ডার, নামাজের ট্র্যাকার, জুমার রিমাইন্ডার, নামাজের সময়ে স্ক্রিন লক, মোবাইল অ্যাপের সাথে সিঙ্ক, থিম স্টোর, ব্যাকআপ/রিস্টোর, আরও ভাষা।

*Quran reader and audio, dua/hadith widget, qibla, tasbih, fasting calendar, prayer tracker, Friday reminders, prayer-time screen lock, sync with the mobile app, theme store, backup/restore, more languages.*

The module system (`src/js/core/modules.js`), the settings schema with migrations (`src/js/core/store.js`), the widget registry (`src/js/modules/widgets/types.js`) and the generic reminder scheduler (`src-tauri/src/alarm.rs`, kind `"x-..."`) are in place for these.
