# Final review (Step 8)

A review of the whole project after all modules were added. Findings that needed a code change were fixed in Step 8; the rest are recorded here and in KNOWN_LIMITATIONS.md.

## 1. Integration

| Area | How the modules work together | Status |
|---|---|---|
| Settings | One JSON file; each module owns one section; defaults merged with saved values; schema version kept for future migrations | OK |
| Module registry | Pages, actions, settings sections, first-run steps and tray tooltip come from modules; each module (except core) can be switched off | OK |
| Alarm scheduler | Prayer alarms plus reminders of other modules (`x-pomo`, `x-eye`, `x-water`); reminders never wake the PC and never count as "missed prayers" | OK |
| Ad blocker ↔ focus mode | Focus sites are passed to the DNS filter as a separate list, removed when focus ends | OK |
| Ad blocker ↔ privacy check | The scan asks the blocker's lists which contacted names are ad/tracker addresses; "Block this address" adds to the blocker's own list | OK |
| Firewall ↔ new-program alert | "Block its internet" creates a firewall rule with undo history | OK |
| Widgets ↔ main window | Widgets only read settings; edits (notes, tasks, lock, hide) are sent to the main window, which is the only writer | OK |
| Language | All visible text comes from `bn.js` / `en.js`; both files have the same keys (checked automatically during testing) | OK |

## 2. Security

| Check | Result |
|---|---|
| Elevation | Only DNS changes, firewall changes and startup entries "for all users" ask for administrator rights, each time, after an in-app confirmation |
| **Elevated scripts (fixed in Step 8)** | Before: elevated PowerShell read its script from a file in the user's folder, so another program could swap the file between the user's "Yes" and the moment it ran. Now the script and its input are passed inside an encoded command line (`psrun::run_elevated_text`); no file is read with administrator rights |
| DNS backup | Values read back from the backup are checked to be real IP addresses before they are applied (added in Step 8) |
| Input validation | Every command checks its inputs (ids, paths, list sizes, allowed values); fixes come from the app's own database by id, not from the window |
| File deletion | Cleaner and junk cleaner build paths themselves, never from the request; links/junctions are not followed; personal folders, system folders and the Recycle Bin are never touched |
| Network | No HTTPS interception, no certificates; network use only for features the user switches on |
| Web content | Strict content security policy (`script-src 'self'`); all text is escaped before it is shown; no remote code |
| Secrets | None in the code; no accounts or keys are used |
| Uninstall | Puts back DNS, removes the app's firewall rules and the autostart entry (installer hook) |

Remaining: commands defined by the app are available to all of the app's own windows (main window and widgets). The widgets show only the app's own pages, so this is acceptable; it can be narrowed with a Tauri app manifest later.

## 3. Performance

| Background work | When it runs | Cost |
|---|---|---|
| Alarm clock thread | every second | compares a few numbers |
| Ad blocker | only while on; list rebuild only on change | lists stored as 64-bit fingerprints (a few MB for ~350,000 entries) |
| New-program alert | every 5 s, only if switched on | one Windows call |
| Focus mode | every 3 s, only while focus is on and programs are listed | one process list |
| Screen time | every 5 s, only if switched on | one Windows call; file written once a minute |
| System monitor | every 2 s, only while its page or widget is open | a few Windows calls |
| Widget windows | only while switched on | one WebView2 window each (the largest cost) |

Not measured: real memory and start-up time of the installed app (see checklist section ঝ). WebView2 is the main memory cost; if the idle total is too high, the main window can be destroyed while hidden in a later version (the alarm, blocker and reminder logic already run in Rust).

## 4. Build

- All Rust code up to Step 5 was built on GitHub Actions successfully (2026-11-15).
- Code added in Steps 6–8 has not been built yet at the time of writing; the Step 8 zip is the first build that contains it.
- PowerShell scripts were run and tested on a real Windows 11 PC (read-only scans on real data; changes only on throw-away registry values and fake folders).
