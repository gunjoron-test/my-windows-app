# Builds the app icon files from the Patheyo brand logo (tools/brand/logo-source.png, the
# 512 px Play Store icon of the mobile app). The round logo is cut out of its white square
# with a smooth (anti-aliased) edge, so the icon has a transparent background.
# Writes: src-tauri/icons/{32x32,128x128,128x128@2x,icon}.png, icon.ico, and src/img/logo.png.
# The files are already in the project; run this again only if the logo changes:
#   powershell -ExecutionPolicy Bypass -File tools\make-icons.ps1

Add-Type -AssemblyName System.Drawing
Add-Type -ReferencedAssemblies System.Drawing -TypeDefinition @"
using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
public static class RoundCut {
    // Copies the square [x0, x0+size) of src into a new 32-bit bitmap and makes everything
    // outside the circle of the given radius transparent (soft 1.5 px edge).
    public static Bitmap Cut(Bitmap src, int x0, int y0, int size, double radius) {
        var dst = new Bitmap(size, size, PixelFormat.Format32bppArgb);
        using (var g = Graphics.FromImage(dst)) { g.DrawImage(src, new Rectangle(0, 0, size, size), new Rectangle(x0, y0, size, size), GraphicsUnit.Pixel); }
        var data = dst.LockBits(new Rectangle(0, 0, size, size), ImageLockMode.ReadWrite, PixelFormat.Format32bppArgb);
        var buf = new byte[data.Stride * size];
        Marshal.Copy(data.Scan0, buf, 0, buf.Length);
        double c = (size - 1) / 2.0;
        for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) {
                double d = Math.Sqrt((x - c) * (x - c) + (y - c) * (y - c));
                double a = Math.Max(0.0, Math.Min(1.0, (radius - d) / 1.5 + 0.5));
                int i = y * data.Stride + x * 4 + 3;
                buf[i] = (byte)Math.Round(buf[i] * a);
            }
        }
        Marshal.Copy(buf, 0, data.Scan0, buf.Length);
        dst.UnlockBits(data);
        return dst;
    }
}
"@

$root = Split-Path $PSScriptRoot -Parent
$source = Join-Path $PSScriptRoot 'brand\logo-source.png'
$iconDir = Join-Path $root 'src-tauri\icons'
$imgDir = Join-Path $root 'src\img'
New-Item -ItemType Directory -Force -Path $iconDir, $imgDir | Out-Null

$src = New-Object System.Drawing.Bitmap $source
# The blue disc of the source spans pixels 21..490 (measured); keep a hair inside the edge.
$cut = [RoundCut]::Cut($src, 21, 21, 470, 233.6)
$src.Dispose()

function Get-Scaled([int]$size) {
    $bmp = New-Object System.Drawing.Bitmap($size, $size, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
    $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $g.Clear([System.Drawing.Color]::Transparent)
    $g.DrawImage($cut, 0, 0, $size, $size)
    $g.Dispose()
    return $bmp
}
function Get-PngBytes([int]$size) {
    $bmp = Get-Scaled $size
    $ms = New-Object System.IO.MemoryStream
    $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
    return ,$ms.ToArray()
}

$pngFiles = @{ '32x32.png' = 32; '128x128.png' = 128; '128x128@2x.png' = 256; 'icon.png' = 512 }
foreach ($name in $pngFiles.Keys) { [System.IO.File]::WriteAllBytes((Join-Path $iconDir $name), (Get-PngBytes $pngFiles[$name])) }
[System.IO.File]::WriteAllBytes((Join-Path $imgDir 'logo.png'), (Get-PngBytes 256))

# icon.ico with several sizes (each stored as PNG)
$sizes = 16, 20, 24, 32, 40, 48, 64, 256
$images = @(); foreach ($size in $sizes) { $images += ,(Get-PngBytes $size) }
$ms = New-Object System.IO.MemoryStream
$bw = New-Object System.IO.BinaryWriter($ms)
$bw.Write([uint16]0); $bw.Write([uint16]1); $bw.Write([uint16]$sizes.Count)
$offset = 6 + 16 * $sizes.Count
for ($i = 0; $i -lt $sizes.Count; $i++) {
    $dim = if ($sizes[$i] -ge 256) { 0 } else { $sizes[$i] }
    $bw.Write([byte]$dim); $bw.Write([byte]$dim); $bw.Write([byte]0); $bw.Write([byte]0)
    $bw.Write([uint16]1); $bw.Write([uint16]32)
    $bw.Write([uint32]$images[$i].Length); $bw.Write([uint32]$offset)
    $offset += $images[$i].Length
}
foreach ($img in $images) { $bw.Write([byte[]]$img) }
$bw.Flush()
[System.IO.File]::WriteAllBytes((Join-Path $iconDir 'icon.ico'), $ms.ToArray())
$cut.Dispose()

Get-ChildItem $iconDir | Select-Object Name, Length
