// Number formats shared by the system pages and the system monitor widget.

import { num } from '../../core/i18n.js';

export function fmtBytes(bytes) {
  const value = Number(bytes) || 0;
  if (value >= 1024 ** 4) return `${num((value / 1024 ** 4).toFixed(1))} TB`;
  if (value >= 1024 ** 3) return `${num((value / 1024 ** 3).toFixed(1))} GB`;
  if (value >= 1024 ** 2) return `${num((value / 1024 ** 2).toFixed(value >= 100 * 1024 ** 2 ? 0 : 1))} MB`;
  if (value >= 1024) return `${num(Math.round(value / 1024))} KB`;
  return `${num(Math.round(value))} B`;
}

/** Network speed in bits per second, the way internet speeds are usually written. */
export function fmtRate(bytesPerSecond) {
  if (bytesPerSecond === null || bytesPerSecond === undefined) return '—';
  const bits = (Number(bytesPerSecond) || 0) * 8;
  if (bits >= 1e9) return `${num((bits / 1e9).toFixed(1))} Gbps`;
  if (bits >= 1e6) return `${num((bits / 1e6).toFixed(1))} Mbps`;
  if (bits >= 1e3) return `${num(Math.round(bits / 1e3))} Kbps`;
  return `${num(Math.round(bits))} bps`;
}

export const fmtPercent = (value) => (value === null || value === undefined ? '—' : `${num(Math.round(Number(value)))}%`);
