// Module G: system tools.
//   * "System monitor" page: live CPU, memory, disks and network speed, plus the battery.
//   * "Startup programs" page: switch programs that start with Windows on or off.
//   * "Junk files" page: preview and delete temporary and cache files.

import { invoke, log } from '../../core/bridge.js';
import { num, t } from '../../core/i18n.js';
import { ask, button, card, flash, notice } from '../../core/ui.js';
import { esc } from '../../core/util.js';
import { fmtBytes, fmtPercent, fmtRate } from './format.js';

const HISTORY = 60; // samples kept for the small CPU graph (about 2 minutes)

let app = null;

// ---- monitor state
let sampleData = null;
let lastSample = 0;
const cpuHistory = [];
let battery = null;
let batteryLoading = false;

// ---- startup state
let startupItems = null;
let startupLoading = false;
let startupError = '';
let startupWorking = '';

// ---- junk state
let junk = null;
let junkLoading = false;
let junkWorking = false;
let junkError = '';
let junkResult = null;
const junkSelected = new Set();

const JUNK_IDS = ['temp', 'inetcache', 'thumbs', 'wer', 'dumps', 'shader'];

function errorText(error) {
  const raw = String(error && error.message ? error.message : error);
  if (raw === 'cancelled') return t('sys.cancelled');
  if (raw === 'no-result') return t('sys.noResult');
  return `${t('sys.failed')} ${raw.slice(0, 200)}`;
}

// ================================================================ monitor

async function takeSample() {
  lastSample = Date.now();
  try {
    sampleData = await invoke('sysmon_sample');
  } catch (e) {
    log('warn', e);
    return;
  }
  if (sampleData && sampleData.cpu !== null && sampleData.cpu !== undefined) {
    cpuHistory.push(Number(sampleData.cpu));
    while (cpuHistory.length > HISTORY) cpuHistory.shift();
  }
}

async function loadBattery() {
  if (batteryLoading) return;
  batteryLoading = true;
  try {
    battery = await invoke('battery_info');
  } catch (e) {
    log('warn', e);
    battery = { hasBattery: false, error: true };
  }
  batteryLoading = false;
  app.render();
}

const barHtml = (id, percent, level) =>
  `<span class="bar big ${level || ''}"><span id="${id}" style="width:${Math.max(0, Math.min(100, Number(percent) || 0))}%"></span></span>`;

const levelOf = (percent) => (percent >= 90 ? 'danger' : percent >= 75 ? 'warn' : '');

function sparkline() {
  if (cpuHistory.length < 2) return '';
  const w = 300;
  const h = 48;
  const step = w / (HISTORY - 1);
  const start = HISTORY - cpuHistory.length;
  const points = cpuHistory.map((v, i) => `${((start + i) * step).toFixed(1)},${(h - (v / 100) * h).toFixed(1)}`).join(' ');
  return `<svg class="spark" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-hidden="true"><polyline points="${points}" /></svg>`;
}

function monitorBody() {
  const s = sampleData || {};
  const mem = s.memory || null;
  const disks = s.disks || [];
  const net = s.net || {};

  const cpu = card(
    t('sys.cpu'),
    `<div class="mon-head"><span class="mon-value" id="mon-cpu">${esc(fmtPercent(s.cpu))}</span></div>
     ${barHtml('mon-cpu-bar', s.cpu, levelOf(s.cpu))}
     <div id="mon-spark">${sparkline()}</div>`,
  );
  const memory = card(
    t('sys.memory'),
    mem
      ? `<div class="mon-head"><span class="mon-value" id="mon-mem">${esc(fmtPercent(mem.percent))}</span>
         <span class="fine" id="mon-mem-text">${esc(t('sys.usedOf', { used: fmtBytes(mem.used), total: fmtBytes(mem.total) }))}</span></div>
         ${barHtml('mon-mem-bar', mem.percent, levelOf(mem.percent))}`
      : `<p class="fine">—</p>`,
  );
  const diskRows = disks.length
    ? disks
        .map((d) => {
          const used = d.total - d.free;
          const percent = d.total ? (used / d.total) * 100 : 0;
          return `<div class="disk-row">
            <div class="mon-head"><b>${esc(d.drive)}</b><span class="fine">${esc(t('sys.freeOf', { free: fmtBytes(d.free), total: fmtBytes(d.total) }))}</span></div>
            ${barHtml(`mon-disk-${esc(d.drive[0])}`, percent, levelOf(percent))}
          </div>`;
        })
        .join('')
    : `<p class="fine">—</p>`;
  const network = card(
    t('sys.network'),
    `<div class="two-col">
       <div><div class="small-label">⬇ ${esc(t('sys.download'))}</div><div class="big-value" id="mon-down">${esc(fmtRate(net.down))}</div></div>
       <div><div class="small-label">⬆ ${esc(t('sys.upload'))}</div><div class="big-value" id="mon-up">${esc(fmtRate(net.up))}</div></div>
     </div>
     <p class="fine">${esc(t('sys.networkHint'))}</p>`,
  );
  return `<div class="mon-grid">${cpu}${memory}</div>${card(t('sys.disks'), `${diskRows}<p class="fine">${esc(t('sys.disksHint'))}</p>`)}${network}`;
}

function batteryCard() {
  if (!battery) return card(`🔋 ${t('bat.title')}`, `<p class="fine">${esc(t('bat.loading'))}</p>`);
  if (!battery.hasBattery) {
    return card(`🔋 ${t('bat.title')}`, `<p class="fine">${esc(t(battery.error ? 'bat.failed' : 'bat.none'))}</p>`);
  }
  const statusKey = [2, 6, 7, 8, 9].includes(Number(battery.status)) ? 'bat.charging' : 'bat.onBattery';
  const runtime = battery.runtime
    ? t('bat.runtime', { h: num(Math.floor(battery.runtime / 60)), m: num(battery.runtime % 60) })
    : '';
  const packs = (battery.batteries || [])
    .map((b) => {
      const health = b.design > 0 ? Math.round((b.full / b.design) * 100) : null;
      const level = health === null ? '' : health >= 80 ? 'good' : health >= 60 ? 'fair' : 'poor';
      return `<div class="bat-pack">
        <div class="mon-head"><b>${esc([b.manufacturer, b.id].filter(Boolean).join(' '))}</b>${b.chemistry ? `<span class="fine">${esc(b.chemistry)}</span>` : ''}</div>
        <table class="times log-table"><tbody>
          <tr><th scope="row">${esc(t('bat.health'))}</th><td class="bat-${level}">${esc(health === null ? '—' : `${num(health)}%`)}${level ? ` · ${esc(t(`bat.level.${level}`))}` : ''}</td></tr>
          <tr><th scope="row">${esc(t('bat.design'))}</th><td>${esc(`${num(b.design)} mWh`)}</td></tr>
          <tr><th scope="row">${esc(t('bat.full'))}</th><td>${esc(`${num(b.full)} mWh`)}</td></tr>
          <tr><th scope="row">${esc(t('bat.cycles'))}</th><td>${esc(b.cycles > 0 ? num(b.cycles) : t('bat.unknown'))}</td></tr>
        </tbody></table>
      </div>`;
    })
    .join('');
  return card(
    `🔋 ${t('bat.title')}`,
    `<div class="mon-head"><span class="mon-value">${esc(fmtPercent(battery.charge))}</span><span class="fine">${esc(t(statusKey))}${runtime ? ` · ${esc(runtime)}` : ''}</span></div>
     ${barHtml('bat-bar', battery.charge, Number(battery.charge) <= 20 ? 'danger' : '')}
     ${packs}
     <p class="fine">${esc(t('bat.healthHint'))}</p>
     ${button('batteryReport', t('bat.reportBtn'))}`,
  );
}

function renderMonitor() {
  if (!sampleData) takeSample().then(() => app.render());
  if (!battery && !batteryLoading) loadBattery();
  return `${notice(t('sys.monitorIntro'))}<div id="mon-body">${monitorBody()}</div>${batteryCard()}`;
}

function setText(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}

function setBar(id, percent) {
  const el = document.getElementById(id);
  if (!el) return;
  const p = Math.max(0, Math.min(100, Number(percent) || 0));
  el.style.width = `${p}%`;
  const bar = el.parentElement;
  if (bar) bar.className = `bar big ${levelOf(p)}`;
}

function tickMonitor(now) {
  if (now - lastSample < 2000) return;
  takeSample().then(() => {
    const s = sampleData || {};
    if (!document.getElementById('mon-cpu')) return;
    setText('mon-cpu', fmtPercent(s.cpu));
    setBar('mon-cpu-bar', s.cpu);
    const spark = document.getElementById('mon-spark');
    if (spark) spark.innerHTML = sparkline();
    if (s.memory) {
      setText('mon-mem', fmtPercent(s.memory.percent));
      setText('mon-mem-text', t('sys.usedOf', { used: fmtBytes(s.memory.used), total: fmtBytes(s.memory.total) }));
      setBar('mon-mem-bar', s.memory.percent);
    }
    const net = s.net || {};
    setText('mon-down', fmtRate(net.down));
    setText('mon-up', fmtRate(net.up));
  });
}

// ================================================================ startup programs

async function loadStartup() {
  if (startupLoading) return;
  startupLoading = true;
  startupError = '';
  app.render();
  try {
    const result = await invoke('startup_list');
    startupItems = (result && result.items) || [];
  } catch (e) {
    log('error', e);
    startupItems = [];
    startupError = errorText(e);
  }
  startupLoading = false;
  app.render();
}

const itemKey = (item) => `${item.scope}|${item.approvedKey}|${item.name}`;

function displayName(item) {
  const fromPath = String(item.path || '').split(/[\\/]/).pop();
  const name = String(item.name || '').replace(/\.lnk$/i, '');
  // Long generated names (for example "...AutoLaunch_894324F1...") read better as the file name.
  return /_[0-9A-F]{16,}$/i.test(name) && fromPath ? fromPath : name;
}

function startupRow(item) {
  const key = itemKey(item);
  const busy = startupWorking === key;
  const impact = item.enabled ? item.impact : 'off';
  const button_ = `<button type="button" class="btn small ${item.enabled ? '' : 'primary'}" data-action="startupToggle" data-key="${esc(key)}" ${startupWorking ? 'disabled' : ''}>${esc(t(busy ? 'sys.working' : item.enabled ? 'su.disable' : 'su.enable'))}</button>`;
  return `<tr class="${item.enabled ? '' : 'muted-row'}">
    <td><b>${esc(displayName(item))}</b><div class="fine">${esc(item.publisher || t('su.noPublisher'))}${item.exists ? '' : ` · ${esc(t('su.missing'))}`}</div></td>
    <td>${esc(t(`su.source.${item.source}`))}</td>
    <td><span class="impact impact-${impact}">${esc(t(`su.impact.${impact}`))}</span></td>
    <td>${esc(t(item.enabled ? 'su.on' : 'su.off'))}</td>
    <td>${button_}</td>
  </tr>`;
}

function renderStartup() {
  if (startupItems === null && !startupLoading) loadStartup();
  const items = [...(startupItems || [])].sort((a, b) => Number(b.enabled) - Number(a.enabled) || displayName(a).localeCompare(displayName(b)));
  const on = items.filter((i) => i.enabled).length;
  const table = items.length
    ? `<table class="times log-table startup-table">
        <thead><tr><th scope="col">${esc(t('su.colName'))}</th><th scope="col">${esc(t('su.colFor'))}</th><th scope="col">${esc(t('su.colImpact'))}</th><th scope="col">${esc(t('su.colState'))}</th><th scope="col"></th></tr></thead>
        <tbody>${items.map(startupRow).join('')}</tbody>
      </table>`
    : `<p class="fine">${esc(t(startupLoading ? 'su.loading' : 'su.empty'))}</p>`;
  return `
    ${notice(t('su.intro'))}
    ${startupError ? notice(startupError, 'warn') : ''}
    ${card(
      t('su.title', { on: num(on), total: num(items.length) }),
      `${table}
       <div class="finding-actions">${button('startupRefresh', t('su.refresh'))}</div>
       <p class="fine">${esc(t('su.impactHint'))}</p>`,
    )}`;
}

// ================================================================ junk files

async function scanJunk() {
  if (junkLoading) return;
  junkLoading = true;
  junkError = '';
  app.render();
  try {
    junk = await invoke('junk_scan');
    junkSelected.clear();
    for (const c of junk.categories || []) if (c.available && c.files > 0 && c.id !== 'thumbs') junkSelected.add(c.id);
  } catch (e) {
    log('error', e);
    junkError = errorText(e);
  }
  junkLoading = false;
  app.render();
}

function selectedJunkBytes() {
  return ((junk && junk.categories) || []).filter((c) => junkSelected.has(c.id)).reduce((sum, c) => sum + (Number(c.bytes) || 0), 0);
}

function junkRow(c) {
  const disabled = !c.available || !c.files;
  const samples = (c.samples || []).length
    ? `<details><summary>${esc(t('junk.examples'))}</summary><ul class="plain-list detail-list">${c.samples.map((s) => `<li class="mono">${esc(s)}</li>`).join('')}</ul></details>`
    : '';
  return `<div class="junk-row">
    <label class="check"><input type="checkbox" data-action="junkToggle" data-id="${esc(c.id)}" ${junkSelected.has(c.id) ? 'checked' : ''} ${disabled ? 'disabled' : ''}>
      <span><b>${esc(t(`junk.cat.${c.id}`))}</b><span class="fine"> · ${esc(c.available ? t('junk.size', { n: num(c.files), size: fmtBytes(c.bytes) }) : t('junk.notFound'))}</span></span></label>
    <p class="fine">${esc(t(`junk.cat.${c.id}.desc`))}</p>
    ${samples}
  </div>`;
}

function junkResultCard() {
  if (!junkResult) return '';
  const rows = (junkResult.categories || [])
    .map((c) => `<tr><td>${esc(t(`junk.cat.${c.id}`))}</td><td>${esc(t('junk.resultLine', { deleted: num(c.deleted), size: fmtBytes(c.freed), failed: num(c.failed) }))}</td></tr>`)
    .join('');
  return card(t('junk.resultTitle'), `<table class="times log-table"><tbody>${rows}</tbody></table><p class="fine">${esc(t('junk.inUse'))}</p>`);
}

function renderJunk() {
  const categories = (junk && junk.categories) || [];
  const busy = junkLoading || junkWorking;
  return `
    ${notice(t('junk.safety'), 'warn')}
    <section class="card">
      <div class="blocker-head">
        <div>
          <div class="blocker-state">${esc(t('junk.title'))}</div>
          <div class="row-hint">${esc(t(junk ? 'junk.scanned' : 'junk.notScanned'))}</div>
        </div>
        <div class="blocker-controls"><button type="button" class="btn primary big" data-action="junkScan" ${busy ? 'disabled' : ''}>${esc(t(junkLoading ? 'junk.scanning' : junk ? 'junk.scanAgain' : 'junk.scanBtn'))}</button></div>
      </div>
    </section>
    ${junkError ? notice(junkError, 'warn') : ''}
    ${junkResultCard()}
    ${categories.length ? card(t('junk.found'), categories.map(junkRow).join('')) : ''}
    ${
      categories.length
        ? `<section class="card"><div class="blocker-head">
            <div><div class="row-label">${esc(t('junk.selected', { n: num(junkSelected.size), size: fmtBytes(selectedJunkBytes()) }))}</div><div class="row-hint">${esc(t('junk.selectedHint'))}</div></div>
            <div class="blocker-controls"><button type="button" class="btn danger big" data-action="junkClean" ${busy || !junkSelected.size ? 'disabled' : ''}>${esc(t(junkWorking ? 'junk.cleaning' : 'junk.cleanBtn'))}</button></div>
          </div></section>`
        : ''
    }
    ${card(
      t('junk.moreTitle'),
      `<p class="fine">${esc(t('junk.moreText'))}</p>
       <div class="finding-actions">${button('junkStorageSense', t('junk.storageSense'))} ${button('junkBrowsers', t('junk.browsers'))}</div>`,
    )}`;
}

// ================================================================ module

const systemModule = {
  id: 'system',
  titleKey: 'module.system',
  canDisable: true,

  pages: [
    { id: 'monitor', icon: 'chart', titleKey: 'nav.monitor', subKey: 'sub.monitor', render: renderMonitor, tick: tickMonitor },
    { id: 'startup', icon: 'play', titleKey: 'nav.startup', subKey: 'sub.startup', render: renderStartup },
    { id: 'junk', icon: 'trash', titleKey: 'nav.junk', subKey: 'sub.junk', render: renderJunk },
  ],

  actions: {
    // ---- battery
    async batteryReport() {
      flash(t('bat.reportMaking'));
      try {
        await invoke('battery_report_open');
      } catch (e) {
        flash(errorText(e), 'warn');
      }
    },

    // ---- startup
    startupRefresh() {
      return loadStartup();
    },
    async startupToggle(el) {
      const item = (startupItems || []).find((i) => itemKey(i) === el.dataset.key);
      if (!item || startupWorking) return;
      const enable = !item.enabled;
      const name = displayName(item);
      const question = t(enable ? 'su.confirmEnable' : 'su.confirmDisable', { name }) + (item.scope === 'HKLM' ? `\n\n${t('su.needsAdmin')}` : '');
      if (!await ask(question)) return;
      startupWorking = itemKey(item);
      app.render();
      try {
        await invoke('startup_set', { scope: item.scope, approvedKey: item.approvedKey, name: item.name, enable });
        flash(t(enable ? 'su.enabled' : 'su.disabled', { name }));
      } catch (e) {
        flash(errorText(e), 'warn');
      }
      startupWorking = '';
      await loadStartup();
    },

    // ---- junk
    junkScan() {
      junkResult = null;
      return scanJunk();
    },
    junkToggle(el) {
      if (el.checked) junkSelected.add(el.dataset.id);
      else junkSelected.delete(el.dataset.id);
      app.render();
    },
    async junkClean() {
      if (!junkSelected.size || junkWorking) return;
      if (!await ask(t('junk.confirm', { n: num(junkSelected.size), size: fmtBytes(selectedJunkBytes()) }))) return;
      junkWorking = true;
      app.render();
      try {
        junkResult = await invoke('junk_clean', { categories: [...junkSelected].filter((id) => JUNK_IDS.includes(id)) });
        flash(t('junk.done'));
      } catch (e) {
        flash(errorText(e), 'warn');
      }
      junkWorking = false;
      await scanJunk();
    },
    async junkStorageSense() {
      await invoke('open_windows_settings', { uri: 'ms-settings:storagesense' }).catch((e) => log('warn', e));
    },
    junkBrowsers() {
      app.navigate('cleaner');
    },
  },

  init(appContext) {
    app = appContext;
  },
};

export default systemModule;
