// Privacy score (0-100), calculated from the findings of a scan.
//
// How it is calculated (shown to the user as well):
//   * Start at 100.
//   * Every finding takes points away: high = 12, medium = 6, low = 2.
//   * One part of the report can take away at most 30 points, so a single long list
//     (for example many apps with camera permission) cannot decide the whole score.
//   * The result never goes below 0.
// The score only reflects what the scan can check; it is a guide, not a guarantee.

export const POINTS = { high: 12, medium: 6, low: 2 };
export const GROUP_CAP = 30;

/**
 * @param findings  findings of evaluate()
 * @param groups    group ids in display order
 * @returns {{ score: number, parts: {group: string, count: number, raw: number, lost: number}[] }}
 */
export function privacyScore(findings, groups) {
  const parts = groups.map((group) => {
    const own = findings.filter((f) => f.group === group);
    const raw = own.reduce((sum, f) => sum + (POINTS[f.severity] || 0), 0);
    return { group, count: own.length, raw, lost: Math.min(GROUP_CAP, raw) };
  });
  const lost = parts.reduce((sum, p) => sum + p.lost, 0);
  return { score: Math.max(0, 100 - lost), parts };
}

/** 'good' (80+), 'fair' (50-79) or 'poor' (below 50). */
export const scoreLevel = (score) => (score >= 80 ? 'good' : score >= 50 ? 'fair' : 'poor');
