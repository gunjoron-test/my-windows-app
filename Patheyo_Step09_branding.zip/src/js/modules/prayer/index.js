// Module B: five-time prayer times and alarms. The home page is the mobile app's home screen
// (hero card with the salam calligraphy, clock, three dates and skyline; the five prayer pills;
// the mihrab "current prayer" card; forbidden times and nafal prayers from the namaz page).

import { invoke, listen, log, pickFile } from '../../core/bridge.js';
import { banglaDate, banglaMonthName } from '../../core/bangla-date.js';
import { fmtCountdown, fmtTime, lang, num, t } from '../../core/i18n.js';
import { isEnabled } from '../../core/modules.js';
import * as store from '../../core/store.js';
import { button, card, flash, icon, notice, number, row, section, select, toggle } from '../../core/ui.js';
import { esc, pad2, ymd } from '../../core/util.js';
import * as alarmUi from './alarm-ui.js';
import { ARCH, SKYLINE, salamSvg } from './art.js';
import { detectLocation, locationFields } from './location.js';
import { METHOD_IDS, PRAYERS, TIMETABLE } from './methods.js';
import { FORBID, buildAlarmItems, computeState, hijriMonthName, locationName, waqtName } from './service.js';
import * as sound from './sound.js';

/** The schedule is rebuilt at least this often even when nothing changes. */
const REFRESH_EVERY_MS = 3 * 60 * 60 * 1000;
const MIN = 60000;

/** Icons of the prayers (mobile namaz page). */
export const WAQT_ICON = { fajr: 'fajr', sunrise: 'sunrise', dhuhr: 'sun', asr: 'sun-moon', maghrib: 'sunset', isha: 'moon' };

let app = null;
let missed = [];
let dashboardKey = '';
let lastRefresh = 0;
let lastDay = '';
let refreshTimer = null;

// ---------------------------------------------------------------- schedule

async function refreshSchedule() {
  const s = store.get();
  const on = isEnabled(prayerModule);
  lastRefresh = Date.now();
  lastDay = ymd(new Date());
  try {
    await invoke('set_schedule', {
      items: on ? buildAlarmItems(s) : [],
      wake: on && s.alarms.enabled && s.alarms.wakeFromSleep,
    });
  } catch (e) {
    log('error', e);
  }
}

function refreshScheduleSoon() {
  clearTimeout(refreshTimer);
  refreshTimer = setTimeout(refreshSchedule, 300);
}

async function loadAlarmState() {
  try {
    const st = await invoke('get_alarm_state');
    missed = (st && st.missed) || [];
    return st;
  } catch (e) {
    log('error', e);
    return null;
  }
}

// ---------------------------------------------------------------- small formatters

/** "05:12" + "AM" (or "17:12" + "" in 24-hour mode), digits in the page language. */
function split(ms, tf) {
  const d = new Date(ms);
  const h = d.getHours();
  if (tf === '24h') return { t: num(`${pad2(h)}:${pad2(d.getMinutes())}`), p: '' };
  return { t: num(`${pad2(h % 12 || 12)}:${pad2(d.getMinutes())}`), p: h < 12 ? 'AM' : 'PM' };
}

/** "২ ঘণ্টা ১০ মিনিট" — the mobile mihrab card's remaining-time text. */
function leftText(ms) {
  const sec = ms / 1000;
  if (sec < 60) return t('dur.lessMin');
  const total = Math.ceil(sec / 60);
  const h = Math.floor(total / 60);
  const m = total % 60;
  if (h && m) return t('dur.hm', { h: num(h), m: num(m) });
  if (h) return t('dur.h', { h: num(h) });
  return t('dur.m', { m: num(m) });
}

/** Greeting by the hour (mobile hero: ভোর 4–6, সকাল 6–12, দুপুর 12–16, বিকাল 16–18, সন্ধ্যা 18–20, রাত). */
function greeting(h) {
  const key = h >= 4 && h < 6 ? 'dawn' : h >= 6 && h < 12 ? 'morning' : h >= 12 && h < 16 ? 'noon' : h >= 16 && h < 18 ? 'afternoon' : h >= 18 && h < 20 ? 'evening' : 'night';
  return t(`greet.${key}`);
}

function weekday(date) {
  try {
    return new Intl.DateTimeFormat(lang() === 'bn' ? 'bn-BD' : 'en-GB', { weekday: 'long' }).format(date);
  } catch {
    return '';
  }
}

function gregMonth(date) {
  try {
    return new Intl.DateTimeFormat(lang() === 'bn' ? 'bn-BD' : 'en-GB', { month: 'long' }).format(date);
  } catch {
    return String(date.getMonth() + 1);
  }
}

const chip = (label, day, month, year) =>
  `<div class="chip" role="group" aria-label="${esc(label)}"><div class="chip-value"><span class="cv-day">${esc(num(pad2(day)))}</span><span class="cv-month">${esc(month)}</span><span class="cv-year">${esc(num(year))}</span></div></div>`;

// ---------------------------------------------------------------- nafal + forbidden (mobile namaz page)

function nafalItems(st, now) {
  const tm = st.today;
  const zawal = tm.dhuhr - FORBID.noon * MIN;
  return [
    { id: 'ishraq', ic: 'sunrise', start: tm.sunrise + FORBID.sunrise * MIN, end: zawal - 5 * MIN },
    { id: 'chasht', ic: 'sun', start: tm.sunrise + (zawal - tm.sunrise) / 2, end: zawal - 15 * MIN },
    { id: 'awwabin', ic: 'sunset', start: tm.maghrib + 15 * MIN, end: tm.isha - 5 * MIN },
    { id: 'tahajjud', ic: 'moon', start: null, end: (now < tm.fajr ? tm.fajr : st.tomorrow.fajr) - 10 * MIN },
  ].map((it) => {
    const from = it.start ?? (now < tm.fajr ? new Date(new Date(now).setHours(0, 0, 0, 0)).getTime() : tm.isha);
    return { ...it, from, on: now >= from && now < it.end };
  });
}

function forbiddenItems(st) {
  const tm = st.today;
  return [
    { id: 'sunrise', ic: 'sunrise', start: tm.sunrise, end: tm.sunrise + FORBID.sunrise * MIN },
    { id: 'noon', ic: 'sun', start: tm.dhuhr - FORBID.noon * MIN, end: tm.dhuhr },
    { id: 'sunset', ic: 'sunset', start: tm.sunset - FORBID.sunset * MIN, end: tm.sunset },
  ];
}

// ---------------------------------------------------------------- dashboard page

function missedBanner() {
  if (!missed.length) return '';
  const lines = missed
    .slice(-5)
    .map((m) => `<li>${esc(m.missedBody || m.title)}</li>`)
    .join('');
  return `<div class="pt-notice pt-notice--warning" role="status">${icon('bell')}
    <div style="flex:1"><b>${esc(t('dash.missedTitle'))}</b><ul class="plain-list">${lines}</ul>${button('dismissMissed', t('dash.missedDismiss'), 'small')}</div>
  </div>`;
}

const dashKey = (s, st, now) =>
  [
    ymd(st.date),
    st.phase.kind,
    st.phase.cur,
    st.phase.win && st.phase.win.key,
    st.ramadan,
    st.hijri && st.hijri.day,
    nafalItems(st, now).map((x) => x.on).join(''),
    s.general.timeFormat,
  ].join('|');

function renderDashboard() {
  const s = store.get();
  const now = Date.now();
  const st = computeState(s, now);
  const tf = s.general.timeFormat;
  dashboardKey = dashKey(s, st, now);

  // ---- hero (left column)
  const b = banglaDate(st.date);
  const salam = salamSvg(() => {
    const host = document.querySelector('.salam-wrap');
    if (host && !host.firstChild) host.innerHTML = salamSvg();
  });
  const hero = `<div class="hero-card">
      <i class="hero-glow" aria-hidden="true"></i><i class="hero-arch2" aria-hidden="true"></i>
      <span class="hero-src" title="${esc(t('loc.title'))}">${icon('location', 'pt-ic--sm')}<span>${esc(locationName(s))}</span></span>
      <div class="salam-wrap" role="img" aria-label="${esc(t('home.salam'))}">${salam}</div>
      <div class="hero-meta"><span id="hero-day">${esc(weekday(st.date))}</span><i aria-hidden="true"></i><span id="hero-greet">${esc(greeting(st.date.getHours()))}</span></div>
      <div class="hero-clock" id="hero-clock" aria-live="off">${clockHtml(now, tf)}</div>
      <div class="chip-row hero-dates">
        ${st.hijri ? chip(t('home.hijri'), st.hijri.day, hijriMonthName(st.hijri), st.hijri.year) : ''}
        ${chip(t('home.greg'), st.date.getDate(), gregMonth(st.date), st.date.getFullYear())}
        ${chip(t('home.bangla'), b.day, banglaMonthName(b), b.year)}
      </div>
      ${SKYLINE}
    </div>`;

  let ramadan = '';
  if (st.ramadan) {
    const sehri = now < st.today.fajr ? st.today.fajr : st.tomorrow.fajr;
    const iftar = now < st.today.maghrib ? st.today.maghrib : st.tomorrow.maghrib;
    const target = Math.min(sehri, iftar);
    ramadan = `<div class="home-ramadan" role="group" aria-label="${esc(t('ramadan.title'))}">
      <span class="home-ramadan__moon">${icon('crescent')}</span>
      <span class="home-ramadan__cd"><span>${esc(t(target === iftar ? 'home.iftarLeft' : 'home.sehriLeft'))}</span><b id="hr-cd" data-at="${target}">${esc(fmtCountdown(target - now))}</b></span>
      <span class="home-ramadan__times"><span>${esc(t('home.sehriEnds'))} <b>${esc(fmtTime(sehri, tf))}</b></span><span>${esc(t('home.iftar'))} <b>${esc(fmtTime(iftar, tf))}</b></span></span>
    </div>`;
  }

  // ---- today's prayers (right column)
  const cur = st.phase.kind === 'prayer' ? PRAYERS.indexOf(st.phase.cur) : -1;
  let last = -1;
  PRAYERS.forEach((k, i) => {
    if (now >= st.today[k]) last = i;
  });
  const night = !!st.phase.night;
  const pills = PRAYERS.map((key, idx) => {
    const x = split(st.today[key], tf);
    const past = night ? false : cur >= 0 ? idx < cur : idx <= last;
    const cls = idx === cur ? 'is-current' : past ? 'is-past' : night && idx === 4 ? '' : 'is-future';
    const on = s.alarms.enabled && s.alarms.waqt[key] && s.alarms.waqt[key].enabled;
    const name = waqtName(key, st.date);
    return `<button class="waqt-pill ${cls}" type="button" role="listitem" data-action="toggleWaqtAlarm" data-waqt="${key}" ${idx === cur ? 'aria-current="true"' : ''}
        title="${esc(t(on ? 'home.alarmOnFor' : 'home.alarmOffFor', { waqt: name }))}">
      <span class="waqt-pill-name">${esc(name)}</span>
      <span class="waqt-pill-time"><span>${esc(x.t)}</span><span class="waqt-pill-ampm">${esc(x.p)}</span></span>
      <span class="wq-check ${on ? 'on' : ''}" aria-hidden="true">${icon(on ? 'bell' : 'bell-off')}</span>
    </button>`;
  }).join('');

  const progress = `<div class="waqt-progress pt-card" id="waqt-progress" data-state="wait">
      <div class="wp-arch" id="wp-track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0" aria-label="${esc(t('home.progress'))}">
        ${ARCH}
        <span class="wp-arch-label"><b id="wp-name"></b><span class="wp-state"><i class="wp-dot"></i><span class="wp-tag" id="wp-tag"></span></span></span>
      </div>
      <div class="wp-info">
        <div class="wp-fbhead" id="wp-fbhead" hidden>${icon('alert', 'pt-ic--sm')}<span id="wp-fbtxt"></span></div>
        <div class="wp-cap">${esc(t('home.left'))}</div>
        <div class="wp-rest"><b id="wp-left">--</b></div>
        <div class="wp-ends">
          <span><em id="wp-l1"></em><b id="wp-t1">--:--</b></span>
          <span><em id="wp-l2"></em><b id="wp-t2">--:--</b></span>
          <span id="wp-el" hidden><em>${esc(t('home.elapsed'))}</em><b id="wp-elt"></b></span>
        </div>
      </div>
    </div>`;

  // ---- forbidden times
  const mk = forbiddenItems(st)
    .map((it) => {
      const on = now >= it.start && now < it.end;
      const a = split(it.start, tf);
      const e = split(it.end, tf);
      const mins = Math.max(1, Math.round((it.end - it.start) / MIN));
      return `<div class="mk ${on ? 'on' : ''}">
        <span class="mk-ic">${icon(it.ic)}</span>
        <b class="mk-name">${esc(t(`forbid.${it.id}`))}</b>
        <span class="mk-time">${esc(a.t)}<small>${esc(a.p)}</small></span>
        <span class="mk-to">${esc(t('home.until', { t: `${e.t} ${e.p}`.trim() }))}</span>
        <span class="mk-dur">${on ? `<b data-live="mk" data-end="${it.end}">${esc(t('home.leftShort', { t: fmtCountdown(it.end - now) }))}</b>` : esc(t('home.minutes', { n: num(mins) }))}</span>
      </div>`;
    })
    .join('');

  // ---- nafal prayers
  const nf = nafalItems(st, now)
    .map((it) => {
      const e = split(it.end, tf);
      const a = it.start != null ? split(it.start, tf) : null;
      const range = `${a ? `<b>${esc(a.t)}</b><small>${esc(a.p)}</small>` : `<span class="nf-from">${esc(t('nafal.lastPart'))}</span>`}<i>–</i><b>${esc(e.t)}</b><small>${esc(e.p)}</small>`;
      return `<div class="nf ${it.on ? 'on' : ''}">
        <span class="nf-ic">${icon(it.ic)}</span>
        <div class="nf-main">
          <div class="nf-top"><b>${esc(t(`nafal.${it.id}`))}</b><span class="nf-rk">${esc(t(`nafal.${it.id}Rk`))}</span>${it.on ? `<span class="fz-chip live"><i></i>${esc(t('home.running'))}</span>` : ''}</div>
          <div class="nf-tr">${range}</div>
          ${it.on ? `<div class="fz-bar"><span data-live="nfbar" data-from="${it.from}" data-end="${it.end}"></span></div><div class="fz-cd"><span data-live="nflbl"></span><b data-live="nfcd"></b></div>` : ''}
        </div>
      </div>`;
    })
    .join('');

  const methodName = t(`method.${s.prayer.method}`);
  return `
    ${missedBanner()}
    <div class="home-grid">
      <div>${hero}${ramadan}</div>
      <div>
        ${section(t('home.todayPrayers'), `<button class="pt-section__action" type="button" data-nav="alarms">${esc(t('nav.alarms'))}${icon('forward', 'pt-ic--sm')}</button>`)}
        <div class="hub-waqt-strip" role="list">${pills}</div>
        ${progress}
        ${section(t('home.forbiddenTitle'))}
        <div class="nz-card"><div class="mk-grid">${mk}</div></div>
        ${section(t('home.nafalTitle'))}
        <div class="nz-card">${nf}</div>
        <p class="fine">${esc(methodName)} · ${esc(t(`asr.${s.prayer.asr}`))} · ${esc(t('home.sunriseAt', { t: fmtTime(st.today.sunrise, tf) }))}</p>
        ${s.alarms.enabled ? '' : notice(t('dash.alarmsOffNote'), 'warn')}
      </div>
    </div>`;
}

function clockHtml(now, tf) {
  const d = new Date(now);
  const h = d.getHours();
  const hh = tf === '24h' ? h : h % 12 || 12;
  return `<span class="digit-pair">${pad2(hh)}</span><span class="colon">:</span><span class="digit-pair">${pad2(d.getMinutes())}</span><span class="colon colon-s">:</span><span class="digit-pair dp-s">${pad2(d.getSeconds())}</span><span class="meridiem">${tf === '24h' ? '' : h >= 12 ? 'PM' : 'AM'}</span>`;
}

// ---- the mihrab card (mobile shell/js/03-waqt-progress.js)

let sweepAnim = null;
let sweepPct = -1;
let sweepFirst = true;

function sweepTo(card, arch, len, pct) {
  const sweep = card.querySelector('#wp-shine');
  const maskPath = card.querySelector('#wp-mask-path');
  if (!sweep || !sweep.animate) return;
  if (Math.abs(pct - sweepPct) < 0.25 && sweepAnim) return;
  sweepPct = pct;
  if (sweepAnim) {
    try {
      sweepAnim.cancel();
    } catch {
      /* ignore */
    }
    sweepAnim = null;
  }
  if (maskPath) maskPath.style.strokeDasharray = `${pct.toFixed(2)} 100`;
  const calm = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (pct < 1.5 || calm) {
    sweep.style.opacity = 0;
    return;
  }
  const N = 22;
  const frames = [];
  const travel = 1000 + pct * 10;
  const total = Math.max(3600, travel / 0.45);
  const tEnd = travel / total;
  const startAt = 1 - tEnd;
  for (let k = 0; k <= N; k++) {
    const f = k / N;
    const d = ((len * pct) / 100) * f;
    const p0 = arch.getPointAtLength(d);
    const p1 = arch.getPointAtLength(Math.min(len, d + 0.6));
    const p2 = arch.getPointAtLength(Math.max(0, d - 0.6));
    const ang = (Math.atan2(p1.y - p2.y, p1.x - p2.x) * 180) / Math.PI;
    frames.push({
      transform: `translate(${p0.x.toFixed(2)}px,${p0.y.toFixed(2)}px) rotate(${ang.toFixed(1)}deg)`,
      opacity: f < 0.1 ? f / 0.1 : f > 0.88 ? Math.max(0, (1 - f) / 0.12) : 1,
      offset: startAt + tEnd * f,
    });
  }
  frames[0].offset = startAt;
  frames[N].offset = 1;
  frames.unshift({ transform: frames[0].transform, opacity: 0, offset: 0 });
  sweepAnim = sweep.animate(frames, { duration: total, iterations: Infinity, delay: sweepFirst ? 1300 : 0, easing: 'linear' });
  sweepFirst = false;
}

function updateProgress(st, now, tf) {
  const card = document.getElementById('waqt-progress');
  if (!card) return;
  const $ = (id) => card.querySelector(`#${id}`);
  const show = (el, on) => el && (on ? el.removeAttribute('hidden') : el.setAttribute('hidden', ''));
  const arch = $('wp-fill');
  const star = $('wp-star');
  const len = arch.getTotalLength();
  const ph = st.phase;
  let start = ph.start;
  let end = ph.end;
  let pct = 0;
  let state = 'running';
  let tag = t('home.running');
  let l1 = t('home.start');
  let l2 = t('home.end');

  if (ph.kind === 'forbidden') {
    state = 'forbidden';
    $('wp-fbtxt').textContent = t('home.forbiddenNow', { name: t(`forbid.${ph.win.key}`) });
    show($('wp-fbhead'), true);
    show($('wp-el'), true);
    $('wp-elt').textContent = leftText(now - start);
    $('wp-name').textContent = '';
    $('wp-tag').textContent = '';
  } else {
    show($('wp-fbhead'), false);
    show($('wp-el'), false);
    if (ph.kind === 'gap') {
      state = 'gap';
      tag = t('home.coming');
      l1 = t('waqt.sunrise');
      l2 = t('home.start');
    } else {
      pct = Math.max(0, Math.min(100, ((now - start) / (end - start)) * 100));
    }
    $('wp-name').textContent = waqtName(ph.cur, st.date);
    $('wp-tag').textContent = tag;
  }

  const pt = arch.getPointAtLength((len * pct) / 100);
  card.dataset.state = state;
  $('wp-left').textContent = leftText(end - now);
  arch.style.strokeDasharray = `${pct.toFixed(2)} 100`;
  arch.style.opacity = pct < 0.4 ? 0 : 1;
  sweepTo(card, arch, len, pct);
  star.style.transform = `translate(${pt.x.toFixed(2)}px,${pt.y.toFixed(2)}px)`;
  $('wp-track').setAttribute('aria-valuenow', Math.round(pct));
  $('wp-l1').textContent = l1;
  $('wp-t1').textContent = fmtTime(start, tf);
  $('wp-l2').textContent = l2;
  $('wp-t2').textContent = fmtTime(end, tf);
}

function setText(el, text) {
  if (el && el.__v !== text) {
    el.__v = text;
    el.textContent = text;
  }
}

function tickDashboard() {
  const s = store.get();
  const now = Date.now();
  const st = computeState(s, now);
  if (dashKey(s, st, now) !== dashboardKey) {
    sweepPct = -1;
    app.render();
    return;
  }
  const tf = s.general.timeFormat;
  const clock = document.getElementById('hero-clock');
  if (clock) {
    const d = new Date(now);
    const parts = clock.querySelectorAll('.digit-pair');
    const h = d.getHours();
    setText(parts[0], pad2(tf === '24h' ? h : h % 12 || 12));
    setText(parts[1], pad2(d.getMinutes()));
    setText(parts[2], pad2(d.getSeconds()));
    setText(clock.querySelector('.meridiem'), tf === '24h' ? '' : h >= 12 ? 'PM' : 'AM');
    setText(document.getElementById('hero-greet'), greeting(h));
  }
  updateProgress(st, now, tf);

  const hr = document.getElementById('hr-cd');
  if (hr) setText(hr, fmtCountdown(Number(hr.dataset.at) - now));
  for (const el of document.querySelectorAll('[data-live="mk"]')) setText(el, t('home.leftShort', { t: fmtCountdown(Number(el.dataset.end) - now) }));
  for (const bar of document.querySelectorAll('[data-live="nfbar"]')) {
    const from = Number(bar.dataset.from);
    const end = Number(bar.dataset.end);
    const pct = Math.max(0, Math.min(100, ((now - from) / (end - from)) * 100));
    bar.style.width = `${pct.toFixed(1)}%`;
    const box = bar.closest('.nf-main');
    const firstHalf = now - from < end - now;
    setText(box.querySelector('[data-live="nflbl"]'), t(firstHalf ? 'nafal.passed' : 'nafal.endsIn'));
    setText(box.querySelector('[data-live="nfcd"]'), fmtCountdown(firstHalf ? now - from : end - now));
  }
}

// ---------------------------------------------------------------- alarms page

const minutesOptions = (values, offLabel) =>
  values.map((v) => [v, v === 0 && offLabel ? offLabel : t('common.minutes', { n: num(v) })]);

function renderAlarms() {
  const s = store.get();
  const a = s.alarms;
  const tf = s.general.timeFormat;
  const st = computeState(s);

  const waqtRows = PRAYERS.map((key) => {
    const name = waqtName(key, st.date);
    const x = split(st.today[key], tf);
    const on = a.waqt[key].enabled;
    return `<div class="fz ${key === st.current ? 'cur' : ''}">
      <span class="pt-medal fz-ic">${icon(WAQT_ICON[key])}</span>
      <div class="fz-main">
        <div class="fz-name"><b>${esc(name)}</b>${on && a.enabled ? `<span class="fz-chip gold">${icon('bell', 'pt-ic--sm')}${esc(t('dash.alarmOn'))}</span>` : ''}</div>
        <div class="fz-time"><b>${esc(x.t)}</b><small>${esc(x.p)}</small></div>
      </div>
      <div class="fz-ctl">
        ${select(`alarms.waqt.${key}.pre`, minutesOptions([0, 5, 10, 15, 20, 30], t('alarms.preOff')), a.waqt[key].pre, 'int').replace('<select', `<select aria-label="${esc(t('alarms.colPre'))}: ${esc(name)}" title="${esc(t('alarms.colPre'))}"`)}
        ${toggle(`alarms.waqt.${key}.enabled`, on).replace('<input', `<input aria-label="${esc(t('alarms.colAlarm'))}: ${esc(name)}"`)}
      </div>
    </div>`;
  }).join('');

  const soundOptions = [
    ['azan', t('sound.azan')],
    ['chime', t('sound.chime')],
    ['bell', t('sound.bell')],
    ['beep', t('sound.beep')],
    ['custom', t('sound.custom')],
  ];
  const fileName = a.customPath ? a.customPath.split(/[\\/]/).pop() : t('sound.noFile');

  return `
    ${notice(t('alarms.runningNote'), 'warn')}
    ${card(t('alarms.title'), row(t('alarms.master'), toggle('alarms.enabled', a.enabled), t('alarms.masterHint')))}
    ${section(t('alarms.perWaqt'))}
    <div class="nz-card">${waqtRows}</div>
    <p class="fine">${esc(t('alarms.preHint'))}</p>
    ${card(
      t('sound.title'),
      `${row(t('sound.choose'), select('alarms.sound', soundOptions, a.sound), t('sound.builtinHint'))}
       ${a.sound === 'custom' ? row(t('sound.file'), `<span class="file-name" title="${esc(a.customPath)}">${esc(fileName)}</span> ${button('chooseSound', t('sound.pick'))}`, t('sound.fileHint')) : ''}
       ${row(t('sound.volume'), `<input type="range" class="range" min="0" max="100" step="5" data-bind="alarms.volume" data-type="int" value="${esc(a.volume)}"> <span class="range-value">${esc(num(a.volume))}%</span>`)}
       ${row(t('sound.test'), `${button('testSound', t('sound.testBtn'))} ${button('stopSound', t('sound.stopBtn'))}`)}
       ${row(t('alarms.snooze'), select('alarms.snoozeMinutes', minutesOptions([5, 10, 15]), a.snoozeMinutes, 'int'), t('alarms.snoozeHint'))}
       ${row(t('alarms.testNotif'), button('testNotification', t('alarms.testNotifBtn')), t('alarms.testNotifHint'))}`,
    )}
    ${card(
      t('ramadan.title'),
      `${row(t('ramadan.mode'), select('ramadan.mode', [['auto', t('ramadan.modeAuto')], ['on', t('ramadan.modeOn')], ['off', t('ramadan.modeOff')]], s.ramadan.mode), t('ramadan.modeHint'))}
       ${row(t('ramadan.sehriAlarm'), toggle('ramadan.sehriAlarm', s.ramadan.sehriAlarm))}
       ${row(t('ramadan.sehriBefore'), select('ramadan.sehriBefore', minutesOptions([10, 15, 20, 30, 45, 60]), s.ramadan.sehriBefore, 'int'), t('ramadan.sehriBeforeHint'))}
       ${row(t('ramadan.iftarAlarm'), toggle('ramadan.iftarAlarm', s.ramadan.iftarAlarm), t('ramadan.iftarHint'))}`,
    )}
    ${card(t('wake.title'), `${row(t('wake.toggle'), toggle('alarms.wakeFromSleep', a.wakeFromSleep))}${notice(t('wake.warning'), 'warn')}`)}`;
}

// ---------------------------------------------------------------- settings + wizard parts

function calculationFields(s, withAdjust) {
  const methodOptions = METHOD_IDS.map((id) => [id, t(`method.${id}`)]);
  let html =
    row(t('calc.method'), select('prayer.method', methodOptions, s.prayer.method), `${t(`methodSub.${s.prayer.method}`)} ${t('calc.methodHint')}`) +
    row(t('calc.asr'), select('prayer.asr', [['hanafi', t('asr.hanafi')], ['shafi', t('asr.shafi')]], s.prayer.asr), t('calc.asrHint'));
  if (withAdjust) {
    const cells = TIMETABLE.map(
      (key) => `<label class="adjust-cell"><span>${esc(t(`waqt.${key}`))}</span>${number(`prayer.adjust.${key}`, s.prayer.adjust[key], -60, 60)}</label>`,
    ).join('');
    html += `<div class="row-label block">${esc(t('calc.adjust'))}</div>
      <div class="row-hint">${esc(t('calc.adjustHint'))}</div>
      <div class="adjust-grid">${cells}</div>
      ${row(t('calc.hijriAdjust'), select('prayer.hijriAdjust', [-2, -1, 0, 1, 2].map((v) => [v, num(v > 0 ? `+${v}` : v)]), s.prayer.hijriAdjust, 'int'), t('calc.hijriAdjustHint'))}
      ${notice(t('calc.bdNote'))}`;
  }
  return html;
}

// ---------------------------------------------------------------- module definition

const prayerModule = {
  id: 'prayer',
  titleKey: 'module.prayer',
  canDisable: true,

  pages: [
    { id: 'dashboard', icon: 'mosque', titleKey: 'nav.dashboard', subKey: 'sub.dashboard', render: renderDashboard, tick: tickDashboard, afterRender: () => tickDashboard() },
    { id: 'alarms', icon: 'alarm', titleKey: 'nav.alarms', subKey: 'sub.alarms', render: renderAlarms },
  ],

  settingsSections() {
    const s = store.get();
    return card(t('loc.title'), locationFields(s)) + card(t('calc.title'), calculationFields(s, true));
  },

  onboarding: [
    { titleKey: 'ob.locTitle', render: (s) => `<p>${esc(t('ob.locText'))}</p>${locationFields(s)}` },
    { titleKey: 'ob.calcTitle', render: (s) => `<p>${esc(t('ob.calcText'))}</p>${calculationFields(s, false)}` },
    {
      titleKey: 'ob.alarmTitle',
      render: (s) =>
        `<p>${esc(t('ob.alarmText'))}</p>${row(t('alarms.master'), toggle('alarms.enabled', s.alarms.enabled))}${notice(t('alarms.runningNote'), 'warn')}`,
    },
  ],

  actions: {
    async dismissMissed() {
      missed = [];
      await invoke('clear_missed').catch((e) => log('warn', e));
      app.render();
    },
    toggleWaqtAlarm(el) {
      const key = el.dataset.waqt;
      const s = store.get();
      if (!s.alarms.waqt[key]) return;
      const on = !s.alarms.waqt[key].enabled;
      store.set(`alarms.waqt.${key}.enabled`, on);
      if (on && !s.alarms.enabled) store.set('alarms.enabled', true);
      flash(t(on ? 'home.alarmOnFor' : 'home.alarmOffFor', { waqt: waqtName(key, new Date()) }));
    },
    async testSound() {
      const result = await sound.startAlarm(store.get().alarms);
      if (result.fallback) flash(t('alarm.customFailed'), 'warn');
    },
    stopSound() {
      sound.stop();
    },
    async chooseSound() {
      const path = await pickFile(t('sound.audioFiles'), sound.AUDIO_EXTENSIONS);
      if (!path) return;
      store.set('alarms.customPath', path);
      store.set('alarms.sound', 'custom');
    },
    async testNotification() {
      await invoke('test_notification', { title: t('alarms.testNotifTitle'), body: t('alarms.testNotifBody') }).catch((e) => log('warn', e));
      flash(t('alarms.testNotifSent'));
    },
    async detectLocation() {
      flash(t('loc.detecting'));
      const ok = await detectLocation();
      flash(ok ? t('loc.detectOk') : t('loc.detectFail'), ok ? 'info' : 'warn');
    },
    alarmStop() {
      alarmUi.close();
    },
    alarmSnooze() {
      alarmUi.snooze();
    },
  },

  trayTooltip() {
    const s = store.get();
    const st = computeState(s);
    return `${t('app.name')} — ${t('dash.next')}: ${waqtName(st.next.key, new Date(st.next.at))} ${fmtTime(st.next.at, s.general.timeFormat)}`;
  },

  async init(appContext) {
    app = appContext;

    await listen('alarm-fire', (item) => {
      // Reminders of other modules ("x-pomo", "x-eye", ...) are handled by those modules.
      if (String((item && item.kind) || '').startsWith('x-')) return;
      if (!isEnabled(prayerModule)) return;
      if (item.silent) {
        sound.playOnce(store.get().alarms);
        flash(item.title);
      } else {
        alarmUi.open(item).catch((e) => log('error', e));
      }
      refreshScheduleSoon();
      app.updateTray();
    });
    await listen('alarm-missed', async () => {
      await loadAlarmState();
      app.render();
    });
    await listen('time-jump', () => {
      // The PC woke up or the clock/time zone changed: recalculate everything.
      refreshScheduleSoon();
      app.render();
      app.updateTray();
    });

    await refreshSchedule();
    const st = await loadAlarmState();
    if (st && st.active && isEnabled(prayerModule)) alarmUi.open(st.active).catch((e) => log('error', e));
  },

  onSettingsChanged() {
    refreshScheduleSoon();
  },

  tick(now) {
    if (ymd(new Date(now)) !== lastDay || now - lastRefresh > REFRESH_EVERY_MS) {
      refreshSchedule().then(() => app.updateTray());
    }
  },
};

export default prayerModule;
