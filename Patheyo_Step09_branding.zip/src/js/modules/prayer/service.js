// Turns settings into prayer times, dates, the "what is happening now" state and the list of
// alarms handed to the backend scheduler. All rules follow the mobile app (Patheyo):
//   • times: js/vendor/prayer-calc.js + if-bd-times.js (see engine.js)
//   • Hijri date: the tabular (Kuwaiti) formula of the mobile namaz page, + the user's day
//     correction; it moves to the next day at Maghrib
//   • Bengali date: the revised Bangladesh calendar (same formula as the mobile app)
//   • forbidden times: 15 min after sunrise, 12 min before Dhuhr, 15 min before sunset
//   • on Friday "যোহর" is shown as "জুম’আ"

import { fmtTime, lang, num, t } from '../../core/i18n.js';
import { ymd } from '../../core/util.js';
import { findCity } from './cities.js';
import { computeTimes } from './engine.js';
import { PRAYERS } from './methods.js';

export const HIJRI_MONTHS = {
  bn: ['মুহাররম', 'সফর', 'রবিউল আউয়াল', 'রবিউস সানি', 'জমাদিউল উলা', 'জমাদিউস সানি', 'রজব', 'শাবান', 'রমজান', 'শাওয়াল', 'জিলকদ', 'জিলহজ'],
  en: ['Muharram', 'Safar', "Rabi' al-Awwal", "Rabi' al-Thani", 'Jumada al-Ula', 'Jumada al-Akhirah', 'Rajab', "Sha'ban", 'Ramadan', 'Shawwal', "Dhu al-Qi'dah", 'Dhu al-Hijjah'],
};

/** Forbidden (makruh) windows, in minutes — the mobile namaz page's rule. */
export const FORBID = { sunrise: 15, noon: 12, sunset: 15 };

const MIN = 60000;
const DAY = 86400000;

/** How many days of alarms are handed to the scheduler at once. */
const DAYS_AHEAD = 7;

export function coords(s) {
  if (s.location.mode === 'city') {
    const city = findCity(s.location.cityId);
    if (city) return { lat: city.lat, lng: city.lng };
  }
  return { lat: Number(s.location.lat) || 0, lng: Number(s.location.lng) || 0 };
}

export function locationName(s) {
  if (s.location.mode === 'city') {
    const city = findCity(s.location.cityId);
    if (city) return lang() === 'bn' ? city.bn : city.en;
  }
  if (s.location.name) return s.location.name;
  const { lat, lng } = coords(s);
  return num(`${lat.toFixed(2)}, ${lng.toFixed(2)}`);
}

/** Hijri date of a calendar day: the mobile app's tabular formula (localGregorianToHijri). */
export function hijri(date, adjustDays = 0) {
  const y = date.getFullYear();
  const mo = date.getMonth() + 1;
  const d = date.getDate();
  const a = Math.floor((14 - mo) / 12);
  const y2 = y + 4800 - a;
  const m2 = mo + 12 * a - 3;
  const jdn = d + Math.floor((153 * m2 + 2) / 5) + 365 * y2 + Math.floor(y2 / 4) - Math.floor(y2 / 100) + Math.floor(y2 / 400) - 32045;
  let l = jdn - 1948440 + 10632 + (Number(adjustDays) || 0);
  const n = Math.floor((l - 1) / 10631);
  l = l - 10631 * n + 354;
  const j = Math.floor((10985 - l) / 5316) * Math.floor((50 * l) / 17719) + Math.floor(l / 5670) * Math.floor((43 * l) / 15238);
  l = l - Math.floor((30 - j) / 15) * Math.floor((17719 * j) / 50) - Math.floor(j / 16) * Math.floor((15238 * j) / 43) + 29;
  const month = Math.floor((24 * l) / 709);
  const day = l - Math.floor((709 * month) / 24);
  const year = 30 * n + j - 30;
  return month >= 1 && month <= 12 ? { day, month, year } : null;
}

export const hijriMonthName = (h) => (h ? HIJRI_MONTHS[lang()][h.month - 1] : '');

export function fmtHijri(h) {
  if (!h) return '';
  return `${num(h.day)} ${hijriMonthName(h)} ${num(h.year)}`;
}

/** Friday: Dhuhr is called Jumu'ah (the mobile home rule). */
export const isFriday = (date) => new Date(date).getDay() === 5;

/** Display name of a prayer; on Friday Dhuhr becomes Jumu'ah. */
export function waqtName(key, date) {
  if (key === 'dhuhr' && date && isFriday(date)) return t('waqt.jumuah');
  return t(`waqt.${key}`);
}

export function ramadanActive(s, date) {
  if (s.ramadan.mode === 'on') return true;
  if (s.ramadan.mode === 'off') return false;
  const h = hijri(date, s.prayer.hijriAdjust);
  return !!h && h.month === 9;
}

/** Prayer times for the calendar day of `date`. */
export function timesFor(s, date) {
  const { lat, lng } = coords(s);
  return computeTimes({ year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() }, lat, lng, {
    method: s.prayer.method,
    asr: s.prayer.asr,
    adjust: s.prayer.adjust,
  });
}

const dayOffset = (date, offset) => new Date(date.getFullYear(), date.getMonth(), date.getDate() + offset);

/**
 * What is happening now — the mobile home engine (WAQT.at):
 *   kind 'prayer'    a prayer time is running (cur = its key)
 *   kind 'gap'       after sunrise, before Dhuhr: Dhuhr is "coming"
 *   kind 'forbidden' one of the three forbidden windows (win = {key, start, end})
 */
function phaseAt(today, tomorrow, now) {
  const wins = [
    { key: 'sunrise', start: today.sunrise, end: today.sunrise + FORBID.sunrise * MIN },
    { key: 'noon', start: today.dhuhr - FORBID.noon * MIN, end: today.dhuhr },
    { key: 'sunset', start: today.sunset - FORBID.sunset * MIN, end: today.sunset },
  ];
  const win = wins.find((w) => now >= w.start && now < w.end);
  if (win) return { kind: 'forbidden', win, start: win.start, end: win.end };
  if (now < today.fajr) return { kind: 'prayer', cur: 'isha', start: today.isha - DAY, end: today.fajr, night: true };
  if (now < today.sunrise) return { kind: 'prayer', cur: 'fajr', start: today.fajr, end: today.sunrise };
  if (now < today.dhuhr) return { kind: 'gap', cur: 'dhuhr', start: today.sunrise, end: today.dhuhr };
  if (now < today.asr) return { kind: 'prayer', cur: 'dhuhr', start: today.dhuhr, end: today.asr };
  if (now < today.maghrib) return { kind: 'prayer', cur: 'asr', start: today.asr, end: today.maghrib };
  if (now < today.isha) return { kind: 'prayer', cur: 'maghrib', start: today.maghrib, end: today.isha };
  return { kind: 'prayer', cur: 'isha', start: today.isha, end: tomorrow.fajr };
}

/** Everything the pages and widgets need for "now". */
export function computeState(s, now = Date.now()) {
  const date = new Date(now);
  const today = timesFor(s, date);
  const tomorrow = timesFor(s, dayOffset(date, 1));

  const sequence = [...PRAYERS.map((key) => ({ key, at: today[key] })), { key: 'fajr', at: tomorrow.fajr }];
  const next = sequence.find((x) => x.at > now) || sequence[sequence.length - 1];
  const phase = phaseAt(today, tomorrow, now);

  // The Hijri date moves to the next day at Maghrib (mobile rule).
  const hijriDate = hijri(now >= today.maghrib ? dayOffset(date, 1) : date, s.prayer.hijriAdjust);

  return {
    date,
    today,
    tomorrow,
    next,
    phase,
    current: phase.kind === 'prayer' ? phase.cur : null,
    hijri: hijriDate,
    friday: isFriday(date),
    ramadan: ramadanActive(s, date),
  };
}

/** The alarms for the next few days, with the notification text already translated. */
export function buildAlarmItems(s, now = Date.now()) {
  if (!s.alarms.enabled) return [];
  const place = locationName(s);
  const tf = s.general.timeFormat;
  const items = [];
  const base = new Date(now);

  for (let offset = 0; offset < DAYS_AHEAD; offset++) {
    const date = dayOffset(base, offset);
    const day = ymd(date);
    const times = timesFor(s, date);
    const ramadan = ramadanActive(s, date);
    const friday = isFriday(date);

    for (const key of PRAYERS) {
      const cfg = s.alarms.waqt[key] || {};
      const at = times[key];
      const name = waqtName(key, date);
      const nameKey = key === 'dhuhr' && friday ? 'jumuah' : key;
      const body = t('alarm.body', { time: fmtTime(at, tf), place });
      const isIftar = ramadan && s.ramadan.iftarAlarm && key === 'maghrib';

      if (cfg.enabled || isIftar) {
        items.push({
          id: `${day}:${key}:main`,
          at,
          kind: isIftar ? 'iftar' : 'main',
          waqt: nameKey,
          title: isIftar ? t('alarm.iftarTitle') : t('azan.short', { waqtOf: t(`waqtOf.${nameKey}`) }),
          body,
          missedBody: t('alarm.missed', { waqt: isIftar ? t('ramadan.iftar') : name, time: fmtTime(at, tf) }),
          silent: false,
        });
      }

      const pre = Number(cfg.pre) || 0;
      if (cfg.enabled && pre > 0) {
        items.push({
          id: `${day}:${key}:pre`,
          at: at - pre * MIN,
          kind: 'pre',
          waqt: nameKey,
          title: t('alarm.preTitle', { waqt: name, n: num(pre) }),
          body,
          missedBody: '',
          silent: true,
        });
      }

      if (ramadan && s.ramadan.sehriAlarm && key === 'fajr') {
        const before = Number(s.ramadan.sehriBefore) || 0;
        items.push({
          id: `${day}:sehri:main`,
          at: at - before * MIN,
          kind: 'sehri',
          waqt: 'sehri',
          title: t('alarm.sehriTitle', { n: num(before) }),
          body: t('alarm.sehriBody', { time: fmtTime(at, tf) }),
          missedBody: t('alarm.missed', { waqt: t('ramadan.sehri'), time: fmtTime(at - before * MIN, tf) }),
          silent: false,
        });
      }
    }
  }

  return items.filter((item) => item.at > now).sort((a, b) => a.at - b.at);
}
