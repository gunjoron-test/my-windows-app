// Artwork of the mobile home screen, copied unchanged from Patheyo (assets/index.html):
// the mosque skyline under the hero card and the mihrab arch of the "current prayer" card.
// The "assalamu alaikum" calligraphy is in img/salam.svg (loaded once, see salamSvg()).

export const SKYLINE = `<svg class="hero-skyline" viewBox="0 0 400 64" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"><defs><linearGradient id="skyFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--sky-top);stop-opacity:var(--sky-top-o)"/><stop offset="1" style="stop-color:var(--sky-bot);stop-opacity:var(--sky-bot-o)"/></linearGradient><mask id="hilalCut" maskUnits="userSpaceOnUse" x="190" y="-6" width="20" height="20"><rect x="190" y="-6" width="20" height="20" fill="#fff"/><circle cx="201" cy="5.35" r="4.3" fill="#000"/></mask></defs><g class="sky-body" transform="translate(0 1) scale(1 .875)" fill="url(#skyFill)" stroke-linejoin="round" stroke-linecap="round"><path d="M132 72V40H268V72Z"/><path d="M1 72V62H29V72Z"/><path d="M399 72V62H371V72Z"/><path d="M5 62V59C5 54 9 52 12 52C15 52 19 54 19 59V62Z"/><path d="M395 62V59C395 54 391 52 388 52C385 52 381 54 381 59V62Z"/><path d="M29 72L30 44L28 44L28 41.5L30.4 41.5L30.8 29L28.2 29L28.2 26.5L30.2 26.5L30.2 21Q30.2 16 35 12.5Q39.8 16 39.8 21L39.8 26.5L41.8 26.5L41.8 29L39.2 29L39.6 41.5L42 41.5L42 44L40 44L41 72Z"/><path d="M371 72L370 44L372 44L372 41.5L369.6 41.5L369.2 29L371.8 29L371.8 26.5L369.8 26.5L369.8 21Q369.8 16 365 12.5Q360.2 16 360.2 21L360.2 26.5L358.2 26.5L358.2 29L360.8 29L360.4 41.5L358 41.5L358 44L360 44L359 72Z"/><path d="M41 72V58H132V72Z"/><path d="M359 72V58H268V72Z"/><path d="M64 58C63 50 69 45 74 42Q77.5 40.5 78 37Q78.5 40.5 82 42C87 45 93 50 92 58Z"/><path d="M336 58C337 50 331 45 326 42Q322.5 40.5 322 37Q321.5 40.5 318 42C313 45 307 50 308 58Z"/><path d="M48 58V55C48 51 50 50 52 50C54 50 56 51 56 55V58Z"/><path d="M352 58V55C352 51 350 50 348 50C346 50 344 51 344 55V58Z"/><path d="M100 58V55C100 51 102 50 104 50C106 50 108 51 108 55V58Z"/><path d="M300 58V55C300 51 298 50 296 50C294 50 292 51 292 55V58Z"/><path d="M117.5 58V40L116.5 40V36Q116.5 31 122 29Q127.5 31 127.5 36V40L126.5 40V58Z"/><path d="M282.5 58V40L283.5 40V36Q283.5 31 278 29Q272.5 31 272.5 36V40L273.5 40V58Z"/><path d="M135 40V37C135 33 138 31 140 31C142 31 145 33 145 37V40Z"/><path d="M265 40V37C265 33 262 31 260 31C258 31 255 33 255 37V40Z"/><path d="M149 40C148 34 152 31 155 29.5Q158 28 158 25.5Q158 28 161 29.5C164 31 168 34 167 40Z"/><path d="M251 40C252 34 248 31 245 29.5Q242 28 242 25.5Q242 28 239 29.5C236 31 232 34 233 40Z"/><path d="M177 40C170 38 169 30 175 25C183 19 196 17 200 14C204 17 217 19 225 25C231 30 230 38 223 40Z"/><g class="sky-lines" fill="none"><path d="M35 12.5V10"/><path d="M365 12.5V10"/><path d="M78 37V34.5"/><path d="M322 37V34.5"/><path d="M52 50V47.5"/><path d="M348 50V47.5"/><path d="M104 50V47.5"/><path d="M296 50V47.5"/><path d="M122 29V26.5"/><path d="M278 29V26.5"/><path d="M140 31V28.5"/><path d="M260 31V28.5"/><path d="M158 25.5V23"/><path d="M242 25.5V23"/><path d="M48.5 72V67.5Q48.5 65 52 62.5Q55.5 65 55.5 67.5V72"/><path d="M351.5 72V67.5Q351.5 65 348 62.5Q344.5 65 344.5 67.5V72"/><path d="M100.5 72V67.5Q100.5 65 104 62.5Q107.5 65 107.5 67.5V72"/><path d="M299.5 72V67.5Q299.5 65 296 62.5Q292.5 65 292.5 67.5V72"/><path d="M73 72V66Q73 63.5 78 61Q83 63.5 83 66V72"/><path d="M327 72V66Q327 63.5 322 61Q317 63.5 317 66V72"/><path d="M159 72V57Q159 51.5 165 49Q171 51.5 171 57V72"/><path d="M241 72V57Q241 51.5 235 49Q229 51.5 229 57V72"/><path d="M200 14V11.5"/><path d="M132 40H268"/><path d="M189 72V54Q189 45.5 200 43Q211 45.5 211 54V72"/></g></g><circle class="sky-moon" cx="200" cy="7.2" r="4.2" mask="url(#hilalCut)"/></svg>`;

const ARCH_PATH = 'M10 92V50C10 32 30 26 44 6C58 26 78 32 78 50V92';

export const ARCH = `<svg viewBox="0 0 88 100" aria-hidden="true" focusable="false">
  <defs><linearGradient id="wpGrad" gradientUnits="userSpaceOnUse" x1="0" y1="92" x2="0" y2="6"><stop offset="0" style="stop-color:var(--wp-a)"/><stop offset="1" style="stop-color:var(--wp-b)"/></linearGradient>
  <linearGradient id="wpShineGrad" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset="0.5" stop-color="#fff" stop-opacity="0.85"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>
  <mask id="wpShineMask" maskUnits="userSpaceOnUse" x="-20" y="-20" width="130" height="150"><path id="wp-mask-path" d="${ARCH_PATH}" pathLength="100" fill="none" stroke="#fff" stroke-width="4.4" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="0 100"/></mask></defs>
  <path class="wp-arch-bg" d="${ARCH_PATH}" pathLength="100"/>
  <path class="wp-arch-fill" id="wp-fill" d="${ARCH_PATH}" pathLength="100"/>
  <g mask="url(#wpShineMask)" class="wp-shine-wrap"><g class="wp-shine" id="wp-shine"><rect x="-14" y="-15" width="28" height="30" fill="url(#wpShineGrad)" transform="skewX(-18)"/></g></g>
  <g class="wp-star" id="wp-star"><circle class="wp-halo" r="7"/><circle class="wp-tipdot" r="3.9"/></g>
</svg>`;

let salam = '';
let salamLoading = null;

/** The calligraphy SVG (cached). Calls back once it is available. */
export function salamSvg(done) {
  if (salam) return salam;
  if (!salamLoading) {
    salamLoading = fetch('img/salam.svg')
      .then((r) => (r.ok ? r.text() : ''))
      .then((text) => {
        salam = text.trim().startsWith('<svg') ? text : '';
        return salam;
      })
      .catch(() => '');
  }
  if (done) salamLoading.then((text) => text && done(text));
  return '';
}
