// Prayer times — exactly the mobile app's calculation.
// The mobile app's own files are used unchanged (js/vendor/prayer-calc.js and if-bd-times.js,
// loaded before this module): Islamic Foundation Bangladesh timetable with district offsets,
// or the sun-position formula of the chosen method (Dhuhr 1 minute after noon, Maghrib 3 minutes
// after sunset, like the mobile app). Works fully offline.

const P = () => window.PtPrayer;

/** The method id the mobile app would use for this place ("auto" → Bangladesh: 100, elsewhere: 1). */
export function resolveMethod(setting, lat, lng) {
  const user = setting === 'auto' ? '0' : String(parseInt(setting, 10) || 0);
  return P().effectiveMethod(user, '1', lat, lng);
}

/** True when the Islamic Foundation timetable applies to this place. */
export const inBangladesh = (lat, lng) => !!(window.PtIFBD && window.PtIFBD.inBangladesh(lat, lng));

/**
 * Prayer times for one calendar day.
 * @param {{year:number, month:number, day:number}} date  calendar date (month 1-12)
 * @param {number} lat
 * @param {number} lng
 * @param {{method:string, asr:string, adjust?:object}} options
 * @returns {{fajr:number, sunrise:number, dhuhr:number, asr:number, maghrib:number, sunset:number, isha:number, method:number}}
 *          every value an exact moment (Unix ms) on that day, local time.
 */
export function computeTimes(date, lat, lng, options) {
  const adjust = options.adjust || {};
  const method = resolveMethod(options.method || 'auto', lat, lng);
  const noonOfDay = new Date(date.year, date.month - 1, date.day, 12, 0, 0);
  const t = P().times(noonOfDay, {
    lat,
    lng,
    method,
    school: options.asr === 'shafi' ? '0' : '1',
    offsets: {
      Fajr: Number(adjust.fajr) || 0,
      Dhuhr: Number(adjust.dhuhr) || 0,
      Asr: Number(adjust.asr) || 0,
      Maghrib: Number(adjust.maghrib) || 0,
      Isha: Number(adjust.isha) || 0,
    },
  });

  const at = (hhmm, extraMinutes = 0) => {
    const match = /^(\d{1,2}):(\d{2})$/.exec(String(hhmm || ''));
    if (!match) return NaN;
    return new Date(date.year, date.month - 1, date.day, Number(match[1]), Number(match[2]) + extraMinutes, 0).getTime();
  };

  return {
    fajr: at(t.Fajr),
    sunrise: at(t.Sunrise, Number(adjust.sunrise) || 0),
    dhuhr: at(t.Dhuhr),
    asr: at(t.Asr),
    maghrib: at(t.Maghrib),
    sunset: at(t.Sunset || t.Maghrib),
    isha: at(t.Isha),
    method,
  };
}
