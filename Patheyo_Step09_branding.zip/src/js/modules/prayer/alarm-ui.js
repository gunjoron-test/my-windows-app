// The adhan popup — the mobile app's full-screen adhan screen (AzanOverlayActivity):
// logo, "পাথেয় · আজান", "ফজরের নামাজের আজান হচ্ছে", "নামাজের সময় হয়েছে", the clock, a hadith or
// verse for the prayer, and two round buttons: Stop / Snooze.
// Rules of the mobile app (AzanContent.kt):
//   • at most 3 rings per prayer (the first + 2 repeats)
//   • Snooze, or the adhan ending without Stop, rings again after 10 minutes
//   • the last ring has no Snooze button
//   • Stop ends the whole sequence (planned repeats are removed)

import { invoke, log } from '../../core/bridge.js';
import { num, t } from '../../core/i18n.js';
import * as store from '../../core/store.js';
import { flash, icon } from '../../core/ui.js';
import { esc, pad2 } from '../../core/util.js';
import * as sound from './sound.js';

/** Rings per prayer, and the minutes between them (mobile: MAX_RINGS 3, SNOOZE_MINUTES 10). */
export const MAX_RINGS = 3;
const DEFAULT_SNOOZE = 10;
/** The popup closes by itself after this long even if the sound is silent. */
const AUTO_CLOSE_MS = 10 * 60 * 1000;

let activeItem = null;
let closeTimer = null;
let clockTimer = null;

const root = () => document.getElementById('alarm-root');

export const isOpen = () => !!activeItem;

/** "2026-11-16:fajr:main" → itself; "snooze-2026-11-16:fajr:main-r2" → "2026-11-16:fajr:main". */
function baseId(id) {
  const m = /^snooze-(.*)-r\d+$/.exec(String(id));
  return m ? m[1] : String(id);
}

function ringOf(id) {
  const m = /-r(\d+)$/.exec(String(id));
  return m ? Number(m[1]) : 1;
}

const isPrayer = (item) => ['fajr', 'dhuhr', 'jumuah', 'asr', 'maghrib', 'isha'].includes(item.waqt);

function quoteFor(item) {
  const key = isPrayer(item) ? item.waqt : 'general';
  return { text: t(`azan.quote.${key}`), src: t(`azan.src.${key}`) };
}

function clockParts() {
  const d = new Date();
  const tf = store.get().general.timeFormat;
  const h = d.getHours();
  return tf === '24h'
    ? { t: `${pad2(h)}:${pad2(d.getMinutes())}`, p: '' }
    : { t: `${pad2(h % 12 || 12)}:${pad2(d.getMinutes())}`, p: h < 12 ? 'AM' : 'PM' };
}

function onKey(event) {
  if (event.key === 'Escape' && activeItem) {
    event.preventDefault();
    close();
  }
}

export async function open(item) {
  activeItem = item;
  const s = store.get();
  const ring = ringOf(item.id);
  const last = ring >= MAX_RINGS;
  const minutes = Number(s.alarms.snoozeMinutes) || DEFAULT_SNOOZE;
  const prayer = isPrayer(item);
  const title = prayer ? t('azan.title', { waqtOf: t(`waqtOf.${item.waqt}`) }) : item.title;
  const sub = prayer ? t('azan.subtitle') : item.body;
  const q = quoteFor(item);
  const c = clockParts();

  root().innerHTML = `
    <div class="az-backdrop" role="alertdialog" aria-modal="true" aria-labelledby="az-title" aria-describedby="az-sub">
      <div class="az-box">
        <div class="az-logo"><img src="img/logo.png" alt=""></div>
        <div class="az-app">${esc(t('app.short'))}<span class="az-tag">${esc(t('azan.tag'))}</span></div>
        <div class="az-title" id="az-title">${esc(title)}</div>
        <div class="az-sub" id="az-sub">${esc(sub)}</div>
        <div class="az-clock" aria-hidden="true"><b id="az-clock">${c.t}</b><span id="az-mer">${c.p}</span></div>
        <div class="az-quote"><p>${esc(q.text)}</p><small>${esc(q.src)}</small></div>
        <div class="az-hint">${esc(last ? t('azan.lastHint') : t('azan.snoozeHint', { n: num(minutes) }))}</div>
        <div class="az-note" id="az-note"></div>
        <div class="az-actions">
          <button type="button" class="az-btn az-stop" data-action="alarmStop"><span class="az-btn__disc">${icon('volume-off')}</span>${esc(t('azan.stop'))}</button>
          ${last ? '' : `<button type="button" class="az-btn az-snooze" data-action="alarmSnooze"><span class="az-btn__disc">${icon('clock')}</span>${esc(t('azan.snooze'))}</button>`}
        </div>
      </div>
    </div>`;
  const stopButton = root().querySelector('[data-action="alarmStop"]');
  if (stopButton) stopButton.focus();
  document.addEventListener('keydown', onKey, true);

  clearInterval(clockTimer);
  clockTimer = setInterval(() => {
    const x = clockParts();
    const el = document.getElementById('az-clock');
    if (el && el.textContent !== x.t) el.textContent = x.t;
    const mer = document.getElementById('az-mer');
    if (mer && mer.textContent !== x.p) mer.textContent = x.p;
  }, 1000);

  clearTimeout(closeTimer);
  closeTimer = setTimeout(() => endedByItself(), AUTO_CLOSE_MS);

  const result = await sound.startAlarm(s.alarms, { onEnd: endedByItself });
  if (result.fallback) {
    const note = document.getElementById('az-note');
    if (note) note.textContent = t('alarm.customFailed');
  }
}

function hide() {
  sound.stop();
  clearTimeout(closeTimer);
  clearInterval(clockTimer);
  document.removeEventListener('keydown', onKey, true);
  activeItem = null;
  root().innerHTML = '';
  invoke('end_alarm').catch((e) => log('warn', e));
}

/** Plans the next ring of this prayer. Returns false when it was the last one. */
async function planRepeat(item) {
  const ring = ringOf(item.id);
  if (ring >= MAX_RINGS) return false;
  const minutes = Number(store.get().alarms.snoozeMinutes) || DEFAULT_SNOOZE;
  const base = baseId(item.id);
  try {
    await invoke('add_alarm', {
      item: { ...item, id: `snooze-${base}-r${ring + 1}`, at: Date.now() + minutes * 60000, kind: 'snooze', silent: false },
    });
    return minutes;
  } catch (e) {
    log('error', e);
    return false;
  }
}

/** Stop: silence and end the whole sequence of this prayer. */
export function close() {
  const item = activeItem;
  hide();
  if (item) invoke('remove_alarms', { prefix: `snooze-${baseId(item.id)}` }).catch((e) => log('warn', e));
}

/** Snooze: silence now and ring again after the snooze time. */
export async function snooze() {
  const item = activeItem;
  hide();
  if (!item) return;
  const minutes = await planRepeat(item);
  if (minutes) flash(t('azan.snoozed', { n: num(minutes) }));
}

/** The adhan ended (or the popup timed out) without Stop: repeat like the mobile app. */
async function endedByItself() {
  const item = activeItem;
  if (!item) return;
  hide();
  const minutes = await planRepeat(item);
  if (minutes) flash(t('azan.autoRepeat', { n: num(minutes) }));
}
