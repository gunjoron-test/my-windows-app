// Calculation methods — the same list, ids and names as the mobile app (Patheyo, namaz page
// "হিসাবের নিয়ম"). The numbers are the mobile/aladhan method ids; 100 = Islamic Foundation
// Bangladesh (fixed official timetable, shared/if-bd-times.js). "auto" = the mobile app's
// default: inside Bangladesh the Islamic Foundation timetable, elsewhere Karachi.

export const METHOD_IDS = ['auto', '100', '1', '3', '4', '2', '5', '8', '16', '10', '9', '11', '13', '15'];

/** The five daily prayers, in order. */
export const PRAYERS = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];

/** Everything shown in the timetable, in order. */
export const TIMETABLE = ['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'];

/** Settings of the first versions used names; they are translated once by the settings migration. */
export const LEGACY_METHODS = { karachi: 'auto', bangladesh: '100', mwl: '3', ummalqura: '4', isna: '2', egypt: '5' };
