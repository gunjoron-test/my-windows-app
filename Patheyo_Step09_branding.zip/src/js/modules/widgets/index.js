// Module A: desktop widgets. This file is the control page inside the main window and keeps
// the real widget windows in step with the settings. The widgets themselves are drawn by
// js/widget.js inside their own small windows (the prayer widget = the mobile home-screen widget).

import { invoke, listen, log } from '../../core/bridge.js';
import { num, t } from '../../core/i18n.js';
import { isEnabled } from '../../core/modules.js';
import * as store from '../../core/store.js';
import { card, flash, icon, notice, row, select, toggle } from '../../core/ui.js';
import { esc } from '../../core/util.js';
import { PRAYER_DESIGNS, WIDGET_IDS, WIDGET_MODES, WIDGET_STYLES, WIDGET_TYPES, widgetConfig, widgetSize } from './types.js';

let app = null;
let syncTimer = null;

/** Opens/closes the widget windows and applies layer mode and lock, according to settings. */
async function syncWindows() {
  const s = store.get();
  const moduleOn = isEnabled(widgetsModule);
  for (const id of WIDGET_IDS) {
    const cfg = widgetConfig(s, id);
    const size = widgetSize(id, cfg);
    try {
      await invoke('widget_sync', {
        id,
        open: moduleOn && cfg.enabled,
        mode: cfg.mode,
        locked: cfg.locked,
        width: size.width,
        height: size.height,
      });
    } catch (e) {
      log('error', `Widget ${id}: ${e && e.message ? e.message : e}`);
    }
  }
}

function syncSoon() {
  clearTimeout(syncTimer);
  syncTimer = setTimeout(syncWindows, 150);
}

async function resetWidget(id) {
  const cfg = widgetConfig(store.get(), id);
  const size = widgetSize(id, cfg);
  await invoke('widget_reset', { id, width: size.width, height: size.height });
}

function widgetCard(s, id) {
  const cfg = widgetConfig(s, id);
  const type = WIDGET_TYPES[id];
  const base = `widgets.${id}`;
  const styleOptions = WIDGET_STYLES.map((v) => [v, t(`widgets.style.${v}`)]);
  const modeOptions = WIDGET_MODES.map((v) => [v, t(`widgets.mode.${v}`)]);

  let body = row(t('widgets.show'), toggle(`${base}.enabled`, cfg.enabled), t(type.descKey));
  if (cfg.enabled) {
    if (id === 'prayer') {
      body += row(t('widgets.designLabel'), select(`${base}.design`, PRAYER_DESIGNS.map((v) => [v, t(`widgets.design.${v}`)]), cfg.design), t('widgets.designHint'));
    }
    body += `
      ${row(t('widgets.styleLabel'), select(`${base}.style`, styleOptions, cfg.style))}
      ${row(t('widgets.opacity'), `<input type="range" class="range" min="30" max="100" step="5" data-bind="${base}.opacity" data-type="int" value="${esc(cfg.opacity)}"> <span class="range-value">${esc(num(cfg.opacity))}%</span>`)}
      ${row(t('widgets.modeLabel'), select(`${base}.mode`, modeOptions, cfg.mode), t('widgets.modeHint'))}
      ${row(t('widgets.lockLabel'), toggle(`${base}.locked`, cfg.locked), t('widgets.lockHint'))}
      ${row(t('widgets.reset'), `<button type="button" class="pt-btn pt-btn--secondary pt-btn--sm" data-action="widgetReset" data-id="${id}">${icon('refresh', 'pt-ic--sm')}${esc(t('widgets.resetBtn'))}</button>`)}`;
  }
  return card(t(type.titleKey), body);
}

function renderWidgets() {
  const s = store.get();
  return `
    ${notice(t('widgets.intro'))}
    ${WIDGET_IDS.map((id) => widgetCard(s, id)).join('')}
    ${notice(t('widgets.limits'), 'warn')}`;
}

const widgetsModule = {
  id: 'widgets',
  titleKey: 'module.widgets',
  canDisable: true,

  pages: [{ id: 'widgets', icon: 'widget', titleKey: 'nav.widgets', subKey: 'sub.widgets', render: renderWidgets }],

  actions: {
    async widgetReset(el) {
      const id = el.dataset.id;
      if (!WIDGET_TYPES[id]) return;
      try {
        await resetWidget(id);
        flash(t('widgets.resetDone'));
      } catch (e) {
        log('error', e);
      }
    },
  },

  async init(appContext) {
    app = appContext;

    // Buttons on a widget (lock, settings, hide) arrive here; the main window saves the change.
    await listen('widget-action', (payload) => {
      const id = payload && payload.id;
      if (!WIDGET_TYPES[id]) return;
      const cfg = widgetConfig(store.get(), id);
      if (payload.action === 'toggleLock') {
        store.set(`widgets.${id}.locked`, !cfg.locked);
      } else if (payload.action === 'hide') {
        store.set(`widgets.${id}.enabled`, false);
      } else if (payload.action === 'settings') {
        invoke('show_main').catch((e) => log('warn', e));
        app.navigate('widgets');
      }
    });

    await syncWindows();
  },

  onSettingsChanged(path) {
    if (path === '*' || path.startsWith('widgets.') || path.startsWith('modules.')) syncSoon();
    // A different prayer design has other proportions: give the window the matching size.
    if (path === 'widgets.prayer.design') setTimeout(() => resetWidget('prayer').catch((e) => log('warn', e)), 400);
  },
};

export default widgetsModule;
