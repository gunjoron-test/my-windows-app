// The desktop widgets that exist, their starting size, and the available looks.
// The looks are the four variants of the mobile app's home-screen widgets:
//   glass (dark glass), light, nobg_dark (transparent, white text), nobg_light (transparent, dark text).
// The prayer widget also has the mobile designs: classic (1), essential (2), minimal (4).

export const WIDGET_TYPES = {
  prayer: { titleKey: 'widgets.type.prayer', descKey: 'widgets.desc.prayer', width: 400, height: 233 },
  clock: { titleKey: 'widgets.type.clock', descKey: 'widgets.desc.clock', width: 330, height: 200 },
  next: { titleKey: 'widgets.type.next', descKey: 'widgets.desc.next', width: 280, height: 130 },
  notes: { titleKey: 'widgets.type.notes', descKey: 'widgets.desc.notes', width: 300, height: 260 },
  tasks: { titleKey: 'widgets.type.tasks', descKey: 'widgets.desc.tasks', width: 300, height: 320 },
  calendar: { titleKey: 'widgets.type.calendar', descKey: 'widgets.desc.calendar', width: 300, height: 300 },
  weather: { titleKey: 'widgets.type.weather', descKey: 'widgets.desc.weather', width: 280, height: 180 },
  sysmon: { titleKey: 'widgets.type.sysmon', descKey: 'widgets.desc.sysmon', width: 280, height: 210 },
};

export const WIDGET_IDS = Object.keys(WIDGET_TYPES);

export const WIDGET_STYLES = ['glass', 'light', 'nobg_dark', 'nobg_light'];

/** Looks of NoorDesk (before Patheyo) → the closest Patheyo look. */
export const LEGACY_STYLES = { green: 'glass', dark: 'glass', glass: 'glass', light: 'light' };

export const PRAYER_DESIGNS = ['classic', 'essential', 'minimal'];

/** Window size of each prayer design (card proportions of the mobile widgets). */
export const DESIGN_SIZE = { classic: { width: 400, height: 233 }, essential: { width: 400, height: 178 }, minimal: { width: 380, height: 185 } };

export const WIDGET_MODES = ['normal', 'top', 'desktop'];

export const WIDGET_DEFAULT = { enabled: false, style: 'glass', design: 'classic', opacity: 100, mode: 'normal', locked: false };

/** Settings of one widget with safe fall-backs. */
export function widgetConfig(settings, id) {
  const saved = (settings.widgets && settings.widgets[id]) || {};
  const cfg = { ...WIDGET_DEFAULT, ...saved };
  if (!WIDGET_STYLES.includes(cfg.style)) cfg.style = LEGACY_STYLES[cfg.style] || 'glass';
  if (!PRAYER_DESIGNS.includes(cfg.design)) cfg.design = 'classic';
  if (!WIDGET_MODES.includes(cfg.mode)) cfg.mode = 'normal';
  cfg.opacity = Math.min(100, Math.max(30, Number(cfg.opacity) || 100));
  return cfg;
}

/** Starting window size of a widget. */
export function widgetSize(id, cfg) {
  if (id === 'prayer') return DESIGN_SIZE[cfg.design] || DESIGN_SIZE.classic;
  const type = WIDGET_TYPES[id];
  return { width: type.width, height: type.height };
}
