// Weather from Open-Meteo (free, no account or key). Used only when the user switches it on.
// Only the approximate position (2 decimals, about 1 km) is sent; nothing else.

const ENDPOINT = 'https://api.open-meteo.com/v1/forecast';

/** Groups the WMO weather codes into a few kinds that have an icon and a text. */
export function weatherKind(code) {
  const c = Number(code);
  if (c === 0) return 'clear';
  if (c >= 1 && c <= 3) return 'partly';
  if (c === 45 || c === 48) return 'fog';
  if (c >= 51 && c <= 57) return 'drizzle';
  if ((c >= 61 && c <= 67) || (c >= 80 && c <= 82)) return 'rain';
  if ((c >= 71 && c <= 77) || c === 85 || c === 86) return 'snow';
  if (c >= 95) return 'storm';
  return 'partly';
}

export const WEATHER_ICONS = {
  clear: '☀️',
  partly: '⛅',
  fog: '🌫️',
  drizzle: '🌦️',
  rain: '🌧️',
  snow: '❄️',
  storm: '⛈️',
};

/** A short key for the place and unit, so a change of location or unit triggers a new fetch. */
export const weatherKey = (lat, lng, unit) => `${Number(lat).toFixed(2)},${Number(lng).toFixed(2)},${unit}`;

/** Fetches the current weather. Returns the object stored as the cache, or throws. */
export async function fetchWeather(lat, lng, unit) {
  const params = new URLSearchParams({
    latitude: Number(lat).toFixed(2),
    longitude: Number(lng).toFixed(2),
    current: 'temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m',
    daily: 'temperature_2m_max,temperature_2m_min',
    timezone: 'auto',
    forecast_days: '1',
  });
  if (unit === 'f') params.set('temperature_unit', 'fahrenheit');

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10000);
  let data;
  try {
    const response = await fetch(`${ENDPOINT}?${params}`, { signal: controller.signal, cache: 'no-store' });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    data = await response.json();
  } finally {
    clearTimeout(timer);
  }

  const current = data && data.current;
  const daily = (data && data.daily) || {};
  if (!current || !Number.isFinite(Number(current.temperature_2m))) throw new Error('Unexpected answer');
  const first = (list) => (Array.isArray(list) && Number.isFinite(Number(list[0])) ? Math.round(Number(list[0])) : null);

  return {
    at: Date.now(),
    key: weatherKey(lat, lng, unit),
    unit,
    temp: Math.round(Number(current.temperature_2m)),
    code: Number(current.weather_code) || 0,
    humidity: Number.isFinite(Number(current.relative_humidity_2m)) ? Math.round(Number(current.relative_humidity_2m)) : null,
    wind: Number.isFinite(Number(current.wind_speed_10m)) ? Math.round(Number(current.wind_speed_10m)) : null,
    max: first(daily.temperature_2m_max),
    min: first(daily.temperature_2m_min),
  };
}
