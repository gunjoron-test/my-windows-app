// Module F: productivity.
//   * "Focus" page: Pomodoro timer, focus mode (sites + programs, manual or by schedule),
//     eye-rest (20-20-20) and water reminders.
//   * "Tasks" page: to-do list and quick notes (also shown in desktop widgets).
//   * "Screen time" page: per-program usage, stored only on this PC.
//   * Settings: weather (optional, only with the user's permission).
//
// Timed events (end of a Pomodoro, reminders) use the backend alarm scheduler with kinds
// "x-pomo", "x-eye" and "x-water", so they ring on time even while the window is hidden.

import { invoke, listen, log } from '../../core/bridge.js';
import { fmtCountdown, fmtTime, lang, num, t } from '../../core/i18n.js';
import { isEnabled } from '../../core/modules.js';
import * as store from '../../core/store.js';
import { ask, button, card, flash, notice, row, select, toggle } from '../../core/ui.js';
import { clamp, esc, ymd } from '../../core/util.js';
import { isBlockerActive, setFocusDomains } from '../blocker/index.js';
import { coords, locationName } from '../prayer/service.js';
import * as sound from '../prayer/sound.js';
import { fetchWeather, weatherKey } from './weather.js';

const DAY_KEYS = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
const MAX_TASKS = 200;
const MAX_NOTES = 20000;
const WEATHER_EVERY_MS = 30 * 60 * 1000;
const WEATHER_RETRY_MS = 5 * 60 * 1000;

let app = null;
let lastReminderCheck = 0;
let lastWeatherCheck = 0;

// ---------------------------------------------------------------- helpers

const lines = (text) =>
  String(text || '')
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);

const toMinutes = (text) => {
  const match = /^(\d{1,2}):(\d{2})$/.exec(String(text || ''));
  if (!match) return null;
  const value = Number(match[1]) * 60 + Number(match[2]);
  return value < 1440 ? value : null;
};

function fmtDuration(seconds) {
  const total = Math.round((Number(seconds) || 0) / 60);
  const h = Math.floor(total / 60);
  const m = total % 60;
  if (h) return t('st.hm', { h: num(h), m: num(m) });
  return t('st.m', { m: num(m) });
}

function remindSound() {
  if (store.get().productivity.reminderSound) sound.playOnce(store.get().alarms);
}

async function addReminder(kind, at, title, body) {
  await invoke('add_alarm', {
    item: { id: `x-${kind}:${at}`, at, kind: `x-${kind}`, waqt: '', title, body, missedBody: '', silent: true },
  });
}

async function clearReminders(kind) {
  await invoke('remove_alarms', { prefix: `x-${kind}` }).catch((e) => log('warn', e));
}

// ================================================================ Pomodoro

const pomo = { phase: 'idle', endsAt: 0, remaining: 0, paused: false, done: 0 };

function phaseMinutes(phase) {
  const p = store.get().productivity.pomodoro;
  const value = phase === 'work' ? p.work : phase === 'short' ? p.short : p.long;
  return clamp(Number(value) || 25, 1, 180);
}

async function startPhase(phase) {
  pomo.phase = phase;
  pomo.paused = false;
  pomo.endsAt = Date.now() + phaseMinutes(phase) * 60000;
  await clearReminders('pomo');
  const work = phase === 'work';
  await addReminder('pomo', pomo.endsAt, t(work ? 'pomo.workDoneTitle' : 'pomo.breakDoneTitle'), t(work ? 'pomo.workDoneBody' : 'pomo.breakDoneBody')).catch((e) =>
    log('warn', e),
  );
  app.render();
}

function finishPhase(withSound) {
  if (withSound) remindSound();
  if (pomo.phase === 'work') {
    pomo.done += 1;
    const every = clamp(Number(store.get().productivity.pomodoro.longEvery) || 4, 2, 10);
    flash(t('pomo.workDoneTitle'));
    startPhase(pomo.done % every === 0 ? 'long' : 'short');
  } else {
    pomo.phase = 'idle';
    pomo.endsAt = 0;
    flash(t('pomo.breakDoneTitle'));
    app.render();
  }
}

function pomoRemaining(now) {
  if (pomo.phase === 'idle') return phaseMinutes('work') * 60000;
  return pomo.paused ? pomo.remaining : Math.max(0, pomo.endsAt - now);
}

// ================================================================ eye and water reminders

const nextAt = { eye: 0, water: 0 };
const scheduling = { eye: false, water: false };

/** Next water reminder time inside the active hours. */
function nextWaterTime(w, from) {
  const interval = clamp(Number(w.interval) || 60, 15, 240) * 60000;
  const start = toMinutes(w.from);
  const end = toMinutes(w.to);
  const at = from + interval;
  if (start === null || end === null || start === end) return at;
  const d = new Date(at);
  const minutes = d.getHours() * 60 + d.getMinutes();
  const inside = start < end ? minutes >= start && minutes < end : minutes >= start || minutes < end;
  if (inside) return at;
  // Outside the active hours: the first reminder of the next active period.
  const next = new Date(d.getFullYear(), d.getMonth(), d.getDate(), Math.floor(start / 60), start % 60);
  if (next.getTime() <= at) next.setDate(next.getDate() + 1);
  return next.getTime();
}

async function scheduleReminder(kind) {
  if (scheduling[kind]) return;
  scheduling[kind] = true;
  try {
    await clearReminders(kind);
    nextAt[kind] = 0;
    const p = store.get().productivity;
    if (!isEnabled(productivityModule) || !p[kind].enabled) return;
    const now = Date.now();
    const at = kind === 'eye' ? now + clamp(Number(p.eye.interval) || 20, 5, 180) * 60000 : nextWaterTime(p.water, now);
    await addReminder(kind, at, t(`remind.${kind}Title`), t(`remind.${kind}Body`));
    nextAt[kind] = at;
  } catch (e) {
    log('warn', e);
  } finally {
    scheduling[kind] = false;
  }
}

// ================================================================ focus mode

let focusOn = false;
let lastFocusKey = '';

function scheduleActive(f, now) {
  const s = f.schedule;
  if (!s.enabled) return false;
  const d = new Date(now);
  const start = toMinutes(s.from);
  const end = toMinutes(s.to);
  if (start === null || end === null || start === end) return false;
  const minutes = d.getHours() * 60 + d.getMinutes();
  if (start < end) return !!s.days[DAY_KEYS[d.getDay()]] && minutes >= start && minutes < end;
  // Overnight period (for example 22:00-06:00): the day it started counts.
  if (minutes >= start) return !!s.days[DAY_KEYS[d.getDay()]];
  if (minutes < end) return !!s.days[DAY_KEYS[(d.getDay() + 6) % 7]];
  return false;
}

const focusActiveAt = (f, now) => (Number(f.manualUntil) || 0) > now || scheduleActive(f, now);

function cleanSites(text) {
  return lines(text)
    .map((line) => line.replace(/^[a-z]+:\/\//i, '').split(/[/?#:]/)[0].toLowerCase())
    .filter((name) => name.includes('.') && name.length <= 253)
    .slice(0, 500);
}

function cleanApps(text) {
  return lines(text)
    .map((line) => {
      const name = line.split(/[\\/]/).pop().toLowerCase();
      return name.endsWith('.exe') ? name : `${name}.exe`;
    })
    .filter((name) => name.length > 4)
    .slice(0, 100);
}

async function applyFocus(now) {
  const p = store.get().productivity;
  const on = isEnabled(productivityModule) && focusActiveAt(p.focus, now);
  const sites = on ? cleanSites(p.focus.sites) : [];
  const apps = on && p.focus.appMode !== 'off' ? cleanApps(p.focus.apps) : [];
  const key = JSON.stringify([on, sites, apps, p.focus.appMode, lang()]);
  if (key === lastFocusKey) return;
  lastFocusKey = key;
  const changed = on !== focusOn;
  focusOn = on;
  setFocusDomains(sites);
  try {
    await invoke('focus_apply', {
      active: on && apps.length > 0,
      apps,
      close: p.focus.appMode === 'close',
      title: t('focus.toastTitle'),
      warnBody: t('focus.toastWarn'),
      closedBody: t('focus.toastClosed'),
    });
  } catch (e) {
    log('warn', e);
  }
  if (changed) {
    flash(t(on ? 'focus.started' : 'focus.ended'));
    app.render();
    app.updateTray();
  }
}

// ================================================================ weather

let weatherBusy = false;
let lastWeatherTry = 0;
let weatherError = '';

async function updateWeather(force) {
  const p = store.get().productivity;
  if (!isEnabled(productivityModule) || !p.weather.enabled || weatherBusy) return;
  const { lat, lng } = coords(store.get());
  const unit = p.weather.unit === 'f' ? 'f' : 'c';
  const cache = p.weather.cache;
  const now = Date.now();
  const fresh = cache && cache.key === weatherKey(lat, lng, unit) && now - cache.at < WEATHER_EVERY_MS;
  if (!force && (fresh || now - lastWeatherTry < WEATHER_RETRY_MS)) return;

  weatherBusy = true;
  lastWeatherTry = now;
  try {
    const result = await fetchWeather(lat, lng, unit);
    result.place = locationName(store.get());
    weatherError = '';
    store.set('productivity.weather.cache', result);
  } catch (e) {
    weatherError = String(e && e.message ? e.message : e).slice(0, 200);
    log('warn', `Weather: ${weatherError}`);
    if (force) flash(t('weather.failed'), 'warn');
  } finally {
    weatherBusy = false;
  }
}

// ================================================================ screen time

let stData = null;
let stLoadedAt = 0;

async function loadScreenTime() {
  stLoadedAt = Date.now();
  try {
    stData = (await invoke('screentime_get')) || {};
  } catch (e) {
    log('warn', e);
    stData = {};
  }
}

async function configureScreenTime() {
  const on = isEnabled(productivityModule) && !!store.get().productivity.screenTime;
  await invoke('screentime_configure', { enabled: on }).catch((e) => log('warn', e));
}

// ================================================================ pages

function pomodoroCard(now) {
  const p = store.get().productivity.pomodoro;
  const phaseText = t(`pomo.phase.${pomo.phase}`);
  let controls;
  if (pomo.phase === 'idle') {
    controls = button('pomoStart', t('pomo.start'), 'primary big');
  } else {
    controls = `${button(pomo.paused ? 'pomoResume' : 'pomoPause', t(pomo.paused ? 'pomo.resume' : 'pomo.pause'), 'big')}
      ${pomo.phase === 'work' ? '' : button('pomoSkip', t('pomo.skip'), 'big')}
      ${button('pomoReset', t('pomo.reset'), 'big danger')}`;
  }
  const minuteOptions = (values) => values.map((v) => [v, t('common.minutes', { n: num(v) })]);
  return `<section class="card pomo-card phase-${pomo.phase}">
    <h2>🍅 ${esc(t('pomo.title'))}</h2>
    <div class="blocker-head">
      <div>
        <div class="small-label">${esc(phaseText)}${pomo.paused ? ` · ${esc(t('pomo.paused'))}` : ''}</div>
        <div class="pomo-time" id="pomo-time">${esc(fmtCountdown(pomoRemaining(now)).replace(/^[০0]{2}:/, ''))}</div>
        <div class="row-hint">${esc(t('pomo.doneCount', { n: num(pomo.done) }))}</div>
      </div>
      <div class="blocker-controls">${controls}</div>
    </div>
    <details><summary>${esc(t('pomo.settings'))}</summary>
      ${row(t('pomo.work'), select('productivity.pomodoro.work', minuteOptions([15, 20, 25, 30, 45, 50, 60, 90]), p.work, 'int'))}
      ${row(t('pomo.short'), select('productivity.pomodoro.short', minuteOptions([3, 5, 10, 15]), p.short, 'int'))}
      ${row(t('pomo.long'), select('productivity.pomodoro.long', minuteOptions([10, 15, 20, 30]), p.long, 'int'))}
      ${row(t('pomo.longEvery'), select('productivity.pomodoro.longEvery', [2, 3, 4, 5, 6].map((v) => [v, num(v)]), p.longEvery, 'int'))}
    </details>
    <p class="fine">${esc(t('pomo.hint'))}</p>
  </section>`;
}

function focusCard(now) {
  const f = store.get().productivity.focus;
  const manual = (Number(f.manualUntil) || 0) > now;
  const stateText = focusOn
    ? manual
      ? t('focus.onUntil', { time: fmtTime(f.manualUntil, store.get().general.timeFormat) })
      : t('focus.onSchedule')
    : t('focus.off');
  const dayBoxes = DAY_KEYS.map(
    (key) => `<label class="check day-check"><input type="checkbox" data-bind="productivity.focus.schedule.days.${key}" data-type="bool" ${f.schedule.days[key] ? 'checked' : ''}> ${esc(t(`day.${key}`))}</label>`,
  ).join('');
  const modeOptions = [['warn', t('focus.modeWarn')], ['close', t('focus.modeClose')], ['off', t('focus.modeOff')]];
  const blockerWarn = cleanSites(f.sites).length && !isBlockerActive() ? notice(t('focus.needBlocker'), 'warn') : '';

  return `<section class="card focus-card ${focusOn ? 'focus-on' : ''}">
    <h2>🎯 ${esc(t('focus.title'))}</h2>
    <div class="blocker-head">
      <div>
        <div class="blocker-state">${esc(stateText)}</div>
        <div class="row-hint">${esc(t('focus.hint'))}</div>
      </div>
      <div class="blocker-controls">
        ${manual ? button('focusStop', t('focus.stop'), 'big danger') : `${button('focus25', t('focus.for25'))} ${button('focus60', t('focus.for60'))} ${button('focus120', t('focus.for120'))}`}
      </div>
    </div>
    ${blockerWarn}
    <div class="row-label block">${esc(t('focus.sites'))}</div>
    <div class="row-hint">${esc(t('focus.sitesHint'))}</div>
    <textarea class="area" rows="4" data-bind="productivity.focus.sites" data-type="multiline" aria-label="${esc(t('focus.sites'))}" placeholder="facebook.com&#10;youtube.com" spellcheck="false">${esc(f.sites)}</textarea>
    <div class="row-label block">${esc(t('focus.apps'))}</div>
    <div class="row-hint">${esc(t('focus.appsHint'))}</div>
    <textarea class="area" rows="3" data-bind="productivity.focus.apps" data-type="multiline" aria-label="${esc(t('focus.apps'))}" placeholder="steam.exe&#10;discord.exe" spellcheck="false">${esc(f.apps)}</textarea>
    ${row(t('focus.appMode'), select('productivity.focus.appMode', modeOptions, f.appMode), t('focus.appModeHint'))}
    <div class="row-label block">${esc(t('focus.schedule'))}</div>
    ${row(t('focus.scheduleOn'), toggle('productivity.focus.schedule.enabled', f.schedule.enabled))}
    ${f.schedule.enabled ? `${row(t('focus.from'), `<input type="time" class="text time" data-bind="productivity.focus.schedule.from" value="${esc(f.schedule.from)}">`)}
      ${row(t('focus.to'), `<input type="time" class="text time" data-bind="productivity.focus.schedule.to" value="${esc(f.schedule.to)}">`)}
      <div class="day-row">${dayBoxes}</div>` : ''}
  </section>`;
}

function remindersCard() {
  const p = store.get().productivity;
  const minuteOptions = (values) => values.map((v) => [v, t('common.minutes', { n: num(v) })]);
  const nextLine = (kind) =>
    p[kind].enabled && nextAt[kind] ? `<p class="fine">${esc(t('remind.next', { time: fmtTime(nextAt[kind], store.get().general.timeFormat) }))}</p>` : '';
  return card(
    `🔔 ${t('remind.title')}`,
    `${row(t('remind.eye'), toggle('productivity.eye.enabled', p.eye.enabled), t('remind.eyeHint'))}
     ${p.eye.enabled ? row(t('remind.every'), select('productivity.eye.interval', minuteOptions([15, 20, 30, 45, 60]), p.eye.interval, 'int')) : ''}
     ${nextLine('eye')}
     ${row(t('remind.water'), toggle('productivity.water.enabled', p.water.enabled), t('remind.waterHint'))}
     ${p.water.enabled ? `${row(t('remind.every'), select('productivity.water.interval', minuteOptions([30, 45, 60, 90, 120]), p.water.interval, 'int'))}
       ${row(t('remind.from'), `<input type="time" class="text time" data-bind="productivity.water.from" value="${esc(p.water.from)}">`)}
       ${row(t('remind.to'), `<input type="time" class="text time" data-bind="productivity.water.to" value="${esc(p.water.to)}">`)}` : ''}
     ${nextLine('water')}
     ${row(t('remind.sound'), toggle('productivity.reminderSound', p.reminderSound), t('remind.soundHint'))}
     <p class="fine">${esc(t('remind.note'))}</p>`,
  );
}

function renderFocus() {
  const now = Date.now();
  return `${pomodoroCard(now)}${focusCard(now)}${remindersCard()}`;
}

function tickFocusPage(now) {
  const el = document.getElementById('pomo-time');
  if (el) el.textContent = fmtCountdown(pomoRemaining(now)).replace(/^[০0]{2}:/, '');
}

// ---------------------------------------------------------------- tasks and notes

function fmtDue(dateText) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(dateText || ''));
  if (!match) return '';
  const d = new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
  return new Intl.DateTimeFormat(lang() === 'bn' ? 'bn-BD' : 'en-GB', { day: 'numeric', month: 'short' }).format(d);
}

function renderTasks() {
  const p = store.get().productivity;
  const today = ymd(new Date());
  const tasks = [...(p.tasks || [])].sort((a, b) => Number(a.done) - Number(b.done) || String(a.due || '9999').localeCompare(String(b.due || '9999')));
  const rows = tasks.length
    ? tasks
        .map((task) => {
          const overdue = !task.done && task.due && task.due < today;
          return `<li class="task ${task.done ? 'done' : ''}">
            <label class="check"><input type="checkbox" data-action="taskToggle" data-id="${esc(task.id)}" ${task.done ? 'checked' : ''}> <span>${esc(task.text)}</span></label>
            ${task.due ? `<span class="due ${overdue ? 'overdue' : ''}">${esc(fmtDue(task.due))}</span>` : ''}
            <button type="button" class="btn small" data-action="taskDelete" data-id="${esc(task.id)}" aria-label="${esc(t('tasks.delete'))}">✕</button>
          </li>`;
        })
        .join('')
    : `<p class="fine">${esc(t('tasks.empty'))}</p>`;
  const doneCount = tasks.filter((x) => x.done).length;

  return `
    ${card(
      `✅ ${t('tasks.title')}`,
      `<div class="task-add">
         <input type="text" class="text" id="task-text" maxlength="200" placeholder="${esc(t('tasks.addPlaceholder'))}" aria-label="${esc(t('tasks.addPlaceholder'))}">
         <input type="date" class="text date" id="task-due" aria-label="${esc(t('tasks.due'))}">
         ${button('taskAdd', t('tasks.add'), 'primary')}
       </div>
       <ul class="task-list">${rows}</ul>
       ${doneCount ? button('taskClearDone', t('tasks.clearDone', { n: num(doneCount) })) : ''}
       <p class="fine">${esc(t('tasks.hint'))}</p>`,
    )}
    ${card(
      `📝 ${t('notes.title')}`,
      `<textarea class="area notes-area" rows="10" data-bind="productivity.notes" data-type="multiline" aria-label="${esc(t('notes.title'))}" placeholder="${esc(t('notes.placeholder'))}">${esc(p.notes)}</textarea>
       <p class="fine">${esc(t('notes.hint'))}</p>`,
    )}`;
}

function addTask(text, due) {
  const clean = String(text || '').trim().slice(0, 200);
  if (!clean) return false;
  const tasks = [...(store.get().productivity.tasks || [])];
  if (tasks.length >= MAX_TASKS) {
    flash(t('tasks.tooMany'), 'warn');
    return false;
  }
  const dueOk = /^\d{4}-\d{2}-\d{2}$/.test(String(due || '')) ? due : '';
  tasks.push({ id: `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`, text: clean, done: false, due: dueOk });
  store.set('productivity.tasks', tasks);
  return true;
}

function toggleTask(id) {
  const tasks = (store.get().productivity.tasks || []).map((x) => (x.id === id ? { ...x, done: !x.done } : x));
  store.set('productivity.tasks', tasks);
}

// ---------------------------------------------------------------- screen time

function renderScreenTime() {
  const p = store.get().productivity;
  if (!stData) loadScreenTime().then(() => app.render());
  const days = stData || {};
  const today = ymd(new Date());
  const todayApps = Object.entries(days[today] || {}).sort((a, b) => b[1] - a[1]);
  const todayTotal = todayApps.reduce((sum, [, s]) => sum + s, 0);
  const top = todayApps.slice(0, 12);
  const maxSec = top.length ? top[0][1] : 1;

  const appRows = top.length
    ? top
        .map(
          ([name, sec]) => `<div class="bar-row">
            <span class="bar-name">${esc(name)}</span>
            <span class="bar"><span style="width:${Math.max(2, Math.round((sec / maxSec) * 100))}%"></span></span>
            <span class="bar-value">${esc(fmtDuration(sec))}</span>
          </div>`,
        )
        .join('')
    : `<p class="fine">${esc(t(p.screenTime ? 'st.noneToday' : 'st.offNote'))}</p>`;

  const week = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = ymd(d);
    const total = Object.values(days[key] || {}).reduce((sum, s) => sum + s, 0);
    week.push({ d, total });
  }
  const weekMax = Math.max(1, ...week.map((w) => w.total));
  const weekRows = week
    .map(
      (w) => `<div class="bar-row">
        <span class="bar-name">${esc(new Intl.DateTimeFormat(lang() === 'bn' ? 'bn-BD' : 'en-GB', { weekday: 'short', day: 'numeric' }).format(w.d))}</span>
        <span class="bar"><span style="width:${w.total ? Math.max(2, Math.round((w.total / weekMax) * 100)) : 0}%"></span></span>
        <span class="bar-value">${esc(w.total ? fmtDuration(w.total) : '—')}</span>
      </div>`,
    )
    .join('');

  return `
    ${card(
      `⏱️ ${t('st.title')}`,
      `${row(t('st.toggle'), toggle('productivity.screenTime', p.screenTime), t('st.toggleHint'))}
       <div class="stat-grid"><div><div class="small-label">${esc(t('st.today'))}</div><div class="big-value">${esc(fmtDuration(todayTotal))}</div></div></div>`,
    )}
    ${card(t('st.todayApps'), appRows)}
    ${card(t('st.week'), weekRows)}
    ${card(t('st.dataTitle'), `${row(t('st.clear'), button('stClear', t('st.clearBtn'), 'danger'), t('st.clearHint'))}`)}`;
}

// ---------------------------------------------------------------- settings section (weather)

function weatherSettings() {
  const w = store.get().productivity.weather;
  const cache = w.cache;
  const status = !w.enabled
    ? ''
    : cache
      ? `<p class="fine">${esc(t('weather.updated', { time: fmtTime(cache.at, store.get().general.timeFormat) }))}</p>`
      : `<p class="fine">${esc(weatherError ? `${t('weather.failed')} ${weatherError}` : t('weather.loading'))}</p>`;
  return card(
    `🌤️ ${t('weather.title')}`,
    `${row(t('weather.toggle'), toggle('productivity.weather.enabled', w.enabled), t('weather.privacy'))}
     ${w.enabled ? `${row(t('weather.unit'), select('productivity.weather.unit', [['c', '°C'], ['f', '°F']], w.unit))}
       ${row(t('weather.refresh'), button('weatherRefresh', t('weather.refreshBtn')))}` : ''}
     ${status}`,
  );
}

// ================================================================ module

const productivityModule = {
  id: 'productivity',
  titleKey: 'module.productivity',
  canDisable: true,

  pages: [
    { id: 'focus', icon: 'target', titleKey: 'nav.focus', subKey: 'sub.focus', render: renderFocus, tick: tickFocusPage },
    { id: 'tasks', icon: 'check-circle', titleKey: 'nav.tasks', subKey: 'sub.tasks', render: renderTasks },
    {
      id: 'screentime',
      icon: 'clock',
      titleKey: 'nav.screentime', subKey: 'sub.screentime',
      render: renderScreenTime,
      tick: (now) => {
        if (now - stLoadedAt > 60000) loadScreenTime().then(() => app.render());
      },
    },
  ],

  settingsSections: weatherSettings,

  actions: {
    // ---- Pomodoro
    pomoStart() {
      return startPhase('work');
    },
    async pomoPause() {
      pomo.remaining = Math.max(0, pomo.endsAt - Date.now());
      pomo.paused = true;
      await clearReminders('pomo');
      app.render();
    },
    async pomoResume() {
      pomo.paused = false;
      pomo.endsAt = Date.now() + pomo.remaining;
      const work = pomo.phase === 'work';
      await addReminder('pomo', pomo.endsAt, t(work ? 'pomo.workDoneTitle' : 'pomo.breakDoneTitle'), t(work ? 'pomo.workDoneBody' : 'pomo.breakDoneBody')).catch((e) =>
        log('warn', e),
      );
      app.render();
    },
    async pomoSkip() {
      await clearReminders('pomo');
      pomo.phase = 'idle';
      pomo.endsAt = 0;
      app.render();
    },
    async pomoReset() {
      await clearReminders('pomo');
      pomo.phase = 'idle';
      pomo.endsAt = 0;
      pomo.paused = false;
      pomo.done = 0;
      app.render();
    },

    // ---- focus
    focus25() {
      store.set('productivity.focus.manualUntil', Date.now() + 25 * 60000);
    },
    focus60() {
      store.set('productivity.focus.manualUntil', Date.now() + 60 * 60000);
    },
    focus120() {
      store.set('productivity.focus.manualUntil', Date.now() + 120 * 60000);
    },
    focusStop() {
      store.set('productivity.focus.manualUntil', 0);
    },

    // ---- tasks
    taskAdd() {
      const text = document.getElementById('task-text');
      const due = document.getElementById('task-due');
      if (text && addTask(text.value, due ? due.value : '')) {
        const again = document.getElementById('task-text');
        if (again) again.focus();
      }
    },
    taskToggle(el) {
      toggleTask(el.dataset.id);
    },
    taskDelete(el) {
      const tasks = (store.get().productivity.tasks || []).filter((x) => x.id !== el.dataset.id);
      store.set('productivity.tasks', tasks);
    },
    async taskClearDone() {
      if (!await ask(t('tasks.confirmClear'))) return;
      store.set('productivity.tasks', (store.get().productivity.tasks || []).filter((x) => !x.done));
    },

    // ---- screen time
    async stClear() {
      if (!await ask(t('st.confirmClear'))) return;
      await invoke('screentime_clear').catch((e) => log('warn', e));
      await loadScreenTime();
      app.render();
    },

    // ---- weather
    weatherRefresh() {
      return updateWeather(true);
    },
  },

  async init(appContext) {
    app = appContext;

    // A Pomodoro cannot continue across a restart, so leftover timer alarms are removed.
    await clearReminders('pomo');
    await configureScreenTime();
    await scheduleReminder('eye');
    await scheduleReminder('water');

    await listen('alarm-fire', (item) => {
      const kind = String((item && item.kind) || '');
      if (kind === 'x-pomo') {
        if (pomo.phase !== 'idle' && !pomo.paused && Math.abs(item.at - pomo.endsAt) < 2000) finishPhase(true);
      } else if (kind === 'x-eye' || kind === 'x-water') {
        remindSound();
        flash(item.title);
        scheduleReminder(kind.slice(2)).then(() => app.render());
      }
    });

    // Buttons and typing inside the desktop widgets (notes, tasks) arrive here.
    await listen('widget-action', (payload) => {
      if (!payload) return;
      if (payload.action === 'notes' && typeof payload.text === 'string') {
        store.set('productivity.notes', payload.text.slice(0, MAX_NOTES));
      } else if (payload.action === 'taskToggle' && payload.taskId) {
        toggleTask(String(payload.taskId));
      } else if (payload.action === 'taskAdd' && payload.text) {
        addTask(String(payload.text), '');
      }
    });

    await listen('focus-app', (hit) => {
      if (hit && hit.name) flash(t(hit.closed ? 'focus.flashClosed' : 'focus.flashWarn', { name: hit.name }), 'warn');
    });

    await listen('time-jump', () => {
      scheduleReminder('eye');
      scheduleReminder('water');
    });

    await applyFocus(Date.now());
    updateWeather(false);
  },

  onSettingsChanged(path) {
    if (path === '*' || path.startsWith('productivity.eye') || path === 'modules.productivity' || path === 'general.language') scheduleReminder('eye');
    if (path === '*' || path.startsWith('productivity.water') || path === 'modules.productivity' || path === 'general.language') scheduleReminder('water');
    if (path === '*' || path === 'productivity.screenTime' || path === 'modules.productivity') configureScreenTime();
    if (path === '*' || path.startsWith('productivity.focus') || path === 'modules.productivity' || path === 'general.language') applyFocus(Date.now());
    if (path === 'productivity.weather.enabled' || path === 'productivity.weather.unit' || path.startsWith('location.')) updateWeather(true);
  },

  tick(now) {
    applyFocus(now);

    // A timer whose alarm was missed (for example while the PC slept) still moves on.
    if (pomo.phase !== 'idle' && !pomo.paused && now > pomo.endsAt + 5000) finishPhase(false);

    // Ticks can be slowed down by Windows while the window is hidden, so time stamps are used.
    if (now - lastReminderCheck > 15000) {
      lastReminderCheck = now;
      const p = store.get().productivity;
      for (const kind of ['eye', 'water']) {
        const lost = nextAt[kind] && now > nextAt[kind] + 180000;
        if (p[kind].enabled && (lost || !nextAt[kind])) scheduleReminder(kind);
      }
    }
    if (now - lastWeatherCheck > 60000) {
      lastWeatherCheck = now;
      updateWeather(false);
    }
  },
};

export default productivityModule;
