// Application shell: navigation, rendering, automatic saving of settings controls.

import { invoke, log } from './core/bridge.js';
import { setLang, t } from './core/i18n.js';
import { allModules, enabledModules, enabledPages, findAction, registerModule } from './core/modules.js';
import * as onboarding from './core/onboarding.js';
import * as store from './core/store.js';
import { esc } from './core/util.js';
import blockerModule from './modules/blocker/index.js';
import coreModule from './modules/core/index.js';
import inspectorModule from './modules/inspector/index.js';
import prayerModule from './modules/prayer/index.js';
import productivityModule from './modules/productivity/index.js';
import securityModule from './modules/security/index.js';
import systemModule from './modules/system/index.js';
import widgetsModule from './modules/widgets/index.js';

// The order here is the order in the side menu. Later steps register their modules here.
registerModule(prayerModule);
registerModule(widgetsModule);
registerModule(blockerModule);
registerModule(inspectorModule);
registerModule(securityModule);
registerModule(productivityModule);
registerModule(systemModule);
registerModule(coreModule);

let currentPageId = null;
let lastTrayKey = '';
const darkQuery = window.matchMedia('(prefers-color-scheme: dark)');

/** Side menu groups (module id → group); the order of the groups is the order shown. */
const NAV_GROUPS = [
  ['prayer', ['prayer', 'widgets']],
  ['protect', ['blocker', 'inspector', 'security']],
  ['work', ['productivity']],
  ['system', ['system']],
  ['app', ['core']],
];

function applyAppearance() {
  const general = store.get().general;
  setLang(general.language);
  const theme = general.theme === 'system' ? (darkQuery.matches ? 'dark' : 'light') : general.theme;
  document.documentElement.dataset.theme = theme;
  document.title = t('app.name');
}

const ic = (name, cls = '') => (window.PT && window.PT.icon ? window.PT.icon(name, cls) : '');

function brandHtml() {
  return `<img class="brand-logo" src="img/logo.png" alt="" width="44" height="44">
    <span class="brand-text">
      <span class="brand-name"><b>${esc(t('app.short'))}</b> ${esc(t('app.by'))}</span>
      <span class="brand-tag">${esc(t('app.tagline'))}</span>
    </span>`;
}

function navHtml(pages, active) {
  const byModule = new Map();
  for (const module of enabledModules()) byModule.set(module.id, module.pages || []);
  return NAV_GROUPS.map(([group, moduleIds]) => {
    const items = moduleIds.flatMap((id) => byModule.get(id) || []).filter((p) => pages.includes(p));
    if (!items.length) return '';
    return `<div class="nav-group"><div class="nav-group__label">${esc(t(`navGroup.${group}`))}</div>${items
      .map(
        (p) => `<button type="button" class="nav-item" data-nav="${p.id}" ${p.id === active.id ? 'aria-current="page"' : ''}>
          <span class="nav-item__ic">${ic(p.icon)}</span><span class="nav-item__label">${esc(t(p.titleKey))}</span>
        </button>`,
      )
      .join('')}</div>`;
  }).join('');
}

function headerHtml(page) {
  const dark = document.documentElement.dataset.theme !== 'light' && document.documentElement.dataset.theme !== 'sepia';
  return `<span class="pt-header__mark">${ic(page.icon)}</span>
    <span class="pt-header__text">
      <span class="pt-header__title">${esc(t(page.titleKey))}</span>
      ${page.subKey ? `<span class="pt-header__sub">${esc(t(page.subKey))}</span>` : ''}
    </span>
    <span class="pt-header__actions">
      <button type="button" class="pt-iconbtn" data-action="toggleTheme" title="${esc(t('set.theme'))}" aria-label="${esc(t('set.theme'))}">${ic(dark ? 'sun' : 'moon')}</button>
    </span>`;
}

function currentPage() {
  const pages = enabledPages();
  return pages.find((p) => p.id === currentPageId) || pages[0];
}

function render() {
  const pages = enabledPages();
  const page = currentPage();
  currentPageId = page.id;

  // Remember where the user was, so re-drawing after a change does not lose their place.
  const view = document.getElementById('view');
  const scroll = view.scrollTop;
  const active = document.activeElement;
  const focusSelector =
    active && active.dataset && active.dataset.bind
      ? `[data-bind="${active.dataset.bind}"]`
      : active && active.dataset && active.dataset.action
        ? `[data-action="${active.dataset.action}"]`
        : null;

  document.getElementById('brand').innerHTML = brandHtml();
  document.getElementById('nav').innerHTML = navHtml(pages, page);
  document.getElementById('page-header').innerHTML = headerHtml(page);
  document.documentElement.dataset.page = page.id;

  try {
    view.innerHTML = `<div class="page page--${page.id}">${page.render()}</div>`;
    if (page.afterRender) page.afterRender(view);
  } catch (e) {
    log('error', e);
    view.innerHTML = `<div class="page"><div class="pt-notice pt-notice--danger">${esc(t('notice.pageError'))}</div></div>`;
  }
  document.getElementById('overlay-root').innerHTML = onboarding.render();

  view.scrollTop = scroll;
  if (focusSelector) {
    const again = document.querySelector(focusSelector);
    if (again) again.focus({ preventScroll: true });
  }
}

function updateTray() {
  let tooltip = t('app.name');
  for (const module of enabledModules()) {
    if (module.trayTooltip) {
      try {
        tooltip = module.trayTooltip();
        break;
      } catch (e) {
        log('warn', e);
      }
    }
  }
  const open = t('tray.open');
  const quit = t('tray.quit');
  const key = `${open}|${quit}|${tooltip}`;
  if (key === lastTrayKey) return; // nothing changed, do not rebuild the tray menu
  lastTrayKey = key;
  invoke('set_tray_text', { open, quit, tooltip }).catch((e) => log('warn', e));
}

/** Reads the value of a control marked with data-bind. Returns undefined if it is not valid. */
function readControl(el) {
  const type = el.dataset.type;
  if (type === 'bool') return el.checked;
  if (type === 'int' || type === 'float') {
    let value = type === 'int' ? parseInt(el.value, 10) : parseFloat(el.value);
    if (!Number.isFinite(value)) return undefined;
    if (el.min !== undefined && el.min !== '') value = Math.max(Number(el.min), value);
    if (el.max !== undefined && el.max !== '') value = Math.min(Number(el.max), value);
    return value;
  }
  if (type === 'multiline') return String(el.value).slice(0, 200000); // lists typed in a text box
  return String(el.value).slice(0, 200);
}

function wireEvents() {
  document.addEventListener('click', (event) => {
    const navButton = event.target.closest('[data-nav]');
    if (navButton) {
      currentPageId = navButton.dataset.nav;
      render();
      document.getElementById('view').scrollTop = 0;
      return;
    }
    const actionButton = event.target.closest('[data-action]');
    if (actionButton && actionButton.dataset.action === 'toggleTheme') {
      // Header button: switch between the dark and the light theme (like the mobile app).
      const nowDark = document.documentElement.dataset.theme === 'dark';
      store.set('general.theme', nowDark ? 'light' : 'dark');
      return;
    }
    if (actionButton) {
      const action = findAction(actionButton.dataset.action);
      if (action) Promise.resolve(action(actionButton, event)).catch((e) => log('error', e));
    }
  });

  document.addEventListener('change', (event) => {
    const el = event.target;
    // A control that is not a saved setting (for example a search box) calls an action instead.
    if (el.dataset && el.dataset.onchange) {
      const action = findAction(el.dataset.onchange);
      if (action) Promise.resolve(action(el, event)).catch((e) => log('error', e));
      return;
    }
    if (!el.dataset || !el.dataset.bind) return;
    const value = readControl(el);
    if (value === undefined) {
      render(); // put the previous valid value back
      return;
    }
    store.set(el.dataset.bind, value);
  });

  store.subscribe((path) => {
    applyAppearance();
    for (const module of allModules()) {
      if (module.onSettingsChanged) {
        try {
          module.onSettingsChanged(path);
        } catch (e) {
          log('error', e);
        }
      }
    }
    render();
    updateTray();
  });

  darkQuery.addEventListener('change', () => {
    applyAppearance();
  });

  window.addEventListener('error', (event) => log('error', `${event.message} @ ${event.filename}:${event.lineno}`));
  window.addEventListener('unhandledrejection', (event) => log('error', `Unhandled: ${event.reason && event.reason.message ? event.reason.message : event.reason}`));
}

function startClock() {
  let lastMinute = -1;
  setInterval(() => {
    const now = Date.now();
    try {
      const page = currentPage();
      if (page.tick && !onboarding.isOpen()) page.tick(now);
      for (const module of enabledModules()) if (module.tick) module.tick(now);
    } catch (e) {
      log('error', e);
    }
    const minute = Math.floor(now / 60000);
    if (minute !== lastMinute) {
      lastMinute = minute;
      updateTray();
    }
  }, 1000);
}

async function boot() {
  await store.load();
  applyAppearance();
  wireEvents();
  if (!store.get().onboarded) onboarding.start();
  render();

  const navigate = (pageId) => {
    currentPageId = pageId;
    render();
  };
  const appContext = { render, updateTray, navigate };
  for (const module of allModules()) {
    if (!module.init) continue;
    try {
      await module.init(appContext);
    } catch (e) {
      log('error', e);
    }
  }

  render();
  updateTray();
  startClock();
}

boot().catch((e) => {
  log('error', e);
  document.getElementById('view').textContent = 'Startup error. Please export the log from Settings.';
});
