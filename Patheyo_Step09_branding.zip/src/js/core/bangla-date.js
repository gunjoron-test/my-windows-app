// Bengali calendar date (Bangabda), using the revised calendar that is official in Bangladesh:
// the year starts on 14 April; the first six months have 31 days, Falgun has 29 days
// (30 when it falls in a Gregorian leap year) and the other months have 30 days.
// Note: the calendar used in West Bengal (India) is different and can be a day apart.

import { lang, num } from './i18n.js';

const MONTHS = {
  bn: ['বৈশাখ', 'জ্যৈষ্ঠ', 'আষাঢ়', 'শ্রাবণ', 'ভাদ্র', 'আশ্বিন', 'কার্তিক', 'অগ্রহায়ণ', 'পৌষ', 'মাঘ', 'ফাল্গুন', 'চৈত্র'],
  en: ['Boishakh', 'Joishtho', 'Asharh', 'Srabon', 'Bhadro', 'Ashwin', 'Kartik', 'Agrahayan', 'Poush', 'Magh', 'Falgun', 'Chaitra'],
};

const isLeap = (year) => (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;

/** @returns {{day:number, month:number, year:number}} month is 1-12 (1 = Boishakh). */
export function banglaDate(date) {
  const y = date.getFullYear();
  const beforeNewYear = date.getMonth() < 3 || (date.getMonth() === 3 && date.getDate() < 14);
  const startYear = beforeNewYear ? y - 1 : y;

  // Whole days since 14 April of the starting year (UTC is used only to count days safely).
  const start = Date.UTC(startYear, 3, 14);
  const today = Date.UTC(y, date.getMonth(), date.getDate());
  let remaining = Math.round((today - start) / 86400000);

  // Falgun lies in February/March of the following Gregorian year.
  const lengths = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, isLeap(startYear + 1) ? 30 : 29, 30];
  let month = 0;
  while (month < 11 && remaining >= lengths[month]) {
    remaining -= lengths[month];
    month += 1;
  }
  return { day: remaining + 1, month: month + 1, year: startYear - 593 };
}

export const banglaMonthName = (b) => MONTHS[lang()][b.month - 1];

export function fmtBanglaDate(date) {
  const b = banglaDate(date);
  const suffix = lang() === 'bn' ? 'বঙ্গাব্দ' : 'BS';
  return `${num(b.day)} ${MONTHS[lang()][b.month - 1]} ${num(b.year)} ${suffix}`;
}
