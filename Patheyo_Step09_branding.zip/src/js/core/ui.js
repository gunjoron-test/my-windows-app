// Small HTML building blocks shared by all pages — they produce the components of the mobile
// app's design system (css/patheyo-ds.css: pt-card, pt-section, pt-switch, pt-btn, pt-notice,
// pt-toast, pt-dialog). Controls with data-bind="settings.path" are saved automatically by app.js.

import { esc } from './util.js';

/** An icon of the mobile app's icon set (js/vendor/pt-icons.js). */
export const icon = (name, cls = '') => (window.PT && window.PT.icon ? window.PT.icon(name, cls) : '');

/** Gold section heading with the eight-point star and fading line (mobile "pt-section"). */
export const section = (title, action = '') =>
  `<div class="pt-section"><span class="pt-section__title">${esc(title)}</span><span class="pt-section__line"></span>${action}</div>`;

/** A section heading followed by one card. */
export const card = (title, body, extraClass = '') =>
  `<div class="ds-block">${title ? section(title) : ''}<section class="pt-card card ${extraClass}">${body}</section></div>`;

/** One settings line: label (+ optional hint) on the left, control on the right. */
export function row(label, control, hint = '') {
  const aria = ` aria-label="${esc(label)}"`;
  const labelled = control.replace(/<(input|select)\b/, (m) => m + aria);
  return `<div class="row">
    <div class="row-text"><div class="row-label">${esc(label)}</div>${hint ? `<div class="row-hint">${esc(hint)}</div>` : ''}</div>
    <div class="row-ctl">${labelled}</div>
  </div>`;
}

export const toggle = (path, on) =>
  `<label class="pt-switch"><input type="checkbox" data-bind="${path}" data-type="bool" ${on ? 'checked' : ''}><span class="pt-switch__track"></span></label>`;

/** options: [[value, label], ...] */
export const select = (path, options, value, type = '') =>
  `<select class="ds-select" data-bind="${path}" data-type="${type}">${options
    .map(([v, l]) => `<option value="${esc(v)}" ${String(v) === String(value) ? 'selected' : ''}>${esc(l)}</option>`)
    .join('')}</select>`;

export const number = (path, value, min, max, step = 1, type = 'int') =>
  `<input type="number" class="num" data-bind="${path}" data-type="${type}" value="${esc(value)}" min="${min}" max="${max}" step="${step}">`;

/** kind: '' (secondary), 'primary', 'danger', plus 'big' / 'small'. */
export function btnClass(kind = '') {
  const parts = String(kind).split(/\s+/).filter(Boolean);
  const cls = ['pt-btn'];
  if (parts.includes('danger')) cls.push('pt-btn--danger');
  else if (!parts.includes('primary')) cls.push('pt-btn--secondary');
  if (parts.includes('big')) cls.push('pt-btn--lg');
  if (parts.includes('small')) cls.push('pt-btn--sm');
  return cls.join(' ');
}

export const button = (action, label, kind = '') =>
  `<button type="button" class="${btnClass(kind)}" data-action="${action}">${esc(label)}</button>`;

/** kind: 'info' (blue), 'warn' (amber), 'danger', 'success'. */
export function notice(text, kind = 'info') {
  const map = { warn: ['pt-notice--warning', 'alert'], danger: ['pt-notice--danger', 'alert'], success: ['pt-notice--success', 'check-circle'] };
  const [cls, ic] = map[kind] || ['', 'info'];
  return `<div class="pt-notice ${cls}" role="note">${icon(ic)}<span>${esc(text)}</span></div>`;
}

/** Short message that drops in from the top (mobile toast). */
export function flash(text, kind = 'info') {
  const host = document.getElementById('toasts');
  if (!host) return;
  const el = document.createElement('div');
  el.className = `pt-toast ${kind === 'warn' ? 'pt-toast--danger' : 'pt-toast--success'}`;
  el.setAttribute('role', 'status');
  el.innerHTML = `${icon(kind === 'warn' ? 'alert' : 'check-circle')}<span>${esc(text)}</span>`;
  host.appendChild(el);
  while (host.children.length > 3) host.firstElementChild.remove();
  setTimeout(() => {
    el.classList.add('is-closing');
    setTimeout(() => el.remove(), 260);
  }, 3600);
}

/**
 * Confirmation dialog in the middle of the window (mobile pt-dialog). Resolves true / false.
 * The text's first paragraph is the title; the rest (after a blank line) is the explanation.
 */
export function ask(text, options = {}) {
  const host = document.getElementById('dialog-root');
  if (!host) return Promise.resolve(window.confirm(text));
  const parts = String(text).split(/\n\s*\n/);
  const title = options.title || parts.shift();
  const body = options.title ? text : parts.join('\n\n');
  const danger = options.danger !== undefined ? options.danger : /(মুছ|delete|remove|বন্ধ|off|reset|রিসেট|quit)/i.test(text);
  const okText = options.ok || (document.documentElement.lang === 'en' ? 'Yes, continue' : 'হ্যাঁ, করুন');
  const cancelText = options.cancel || (document.documentElement.lang === 'en' ? 'Cancel' : 'বাতিল');

  return new Promise((resolve) => {
    const previous = document.activeElement;
    host.innerHTML = `<div class="pt-scrim pt-dialog-scrim" data-dlg="scrim"></div>
      <div class="pt-dialog" role="alertdialog" aria-modal="true" aria-labelledby="dlg-title" aria-describedby="dlg-body">
        <div class="pt-medal pt-dialog__icon ${danger ? 'is-danger' : ''}">${icon(options.icon || (danger ? 'alert' : 'info'), 'pt-ic--lg')}</div>
        <div class="pt-dialog__title" id="dlg-title">${esc(title)}</div>
        ${body ? `<div class="pt-dialog__body" id="dlg-body">${esc(body).replace(/\n/g, '<br>')}</div>` : ''}
        <div class="pt-dialog__actions">
          <button type="button" class="pt-btn pt-btn--secondary" data-dlg="no">${esc(cancelText)}</button>
          <button type="button" class="pt-btn ${danger ? 'pt-btn--danger' : ''}" data-dlg="yes">${esc(okText)}</button>
        </div>
      </div>`;
    const finish = (answer) => {
      document.removeEventListener('keydown', onKey, true);
      host.innerHTML = '';
      if (previous && previous.focus) previous.focus({ preventScroll: true });
      resolve(answer);
    };
    const onKey = (event) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        event.stopPropagation();
        finish(false);
      }
    };
    document.addEventListener('keydown', onKey, true);
    host.querySelector('[data-dlg="yes"]').addEventListener('click', () => finish(true));
    host.querySelector('[data-dlg="no"]').addEventListener('click', () => finish(false));
    host.querySelector('[data-dlg="scrim"]').addEventListener('click', () => finish(false));
    host.querySelector(danger ? '[data-dlg="no"]' : '[data-dlg="yes"]').focus();
  });
}
