// First-run wizard. Each module can add its own steps (module.onboarding).

import { t } from './i18n.js';
import { enabledModules } from './modules.js';
import * as store from './store.js';
import { notice, row, select, toggle } from './ui.js';
import { esc } from './util.js';

let open = false;
let step = 0;

export const isOpen = () => open;

export function start() {
  open = true;
  step = 0;
}

export const languageOptions = () => [['bn', 'বাংলা'], ['en', 'English']];

export const themeOptions = () => [
  ['system', t('theme.system')],
  ['light', t('theme.light')],
  ['dark', t('theme.dark')],
];

function steps() {
  return [
    {
      titleKey: 'ob.welcomeTitle',
      render: (s) =>
        `<p>${esc(t('ob.welcomeText'))}</p>
         ${row(t('set.language'), select('general.language', languageOptions(), s.general.language))}
         ${row(t('set.theme'), select('general.theme', themeOptions(), s.general.theme))}`,
    },
    ...enabledModules().flatMap((m) => m.onboarding || []),
    {
      titleKey: 'ob.finishTitle',
      render: (s) =>
        `<p>${esc(t('ob.finishText'))}</p>
         ${row(t('set.autostart'), toggle('general.startWithWindows', s.general.startWithWindows), t('set.autostartHint'))}
         ${notice(t('ob.trayNote'))}`,
    },
  ];
}

export function render() {
  if (!open) return '';
  const list = steps();
  step = Math.min(step, list.length - 1);
  const current = list[step];
  const last = step === list.length - 1;
  const dots = list.map((_, i) => `<span class="dot ${i === step ? 'on' : ''}"></span>`).join('');

  return `<div class="overlay" role="dialog" aria-modal="true" aria-labelledby="ob-title">
    <div class="wizard">
      <div class="wizard-top"><img src="img/logo.png" alt=""><span class="brand-name"><b>${esc(t('app.short'))}</b> ${esc(t('app.by'))}</span><span style="flex:1"></span><div class="wizard-dots" aria-hidden="true">${dots}</div></div>
      <h1 id="ob-title">${esc(t(current.titleKey))}</h1>
      <div class="wizard-body">${current.render(store.get())}</div>
      <div class="wizard-actions">
        ${step > 0 ? `<button type="button" class="pt-btn pt-btn--secondary" data-action="obBack">${esc(t('ob.back'))}</button>` : '<span></span>'}
        <button type="button" class="pt-btn" data-action="${last ? 'obFinish' : 'obNext'}">${esc(t(last ? 'ob.finish' : 'ob.next'))}</button>
      </div>
    </div>
  </div>`;
}

export function next() {
  step += 1;
}

export function back() {
  step = Math.max(0, step - 1);
}

export function finish() {
  open = false;
  store.set('onboarded', true);
}
