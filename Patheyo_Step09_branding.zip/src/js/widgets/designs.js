// The prayer widget of the mobile app, drawn on a canvas exactly like its Kotlin code
// (widgethub/widget: ClassicDesign.kt = design 1 "Classic" and 2 "Essential", MinimalDesign.kt =
// design 4 "Minimal"). Measurements are the mobile design units; colours are Palettes.kt.
// The JavaScript translation comes from the mobile project (tools/android-preview/widgets.js);
// here it is fed with live data (snapshot()) instead of the sample.

import { lang, num, t } from '../core/i18n.js';
import { hijriMonthName } from '../modules/prayer/service.js';
import { banglaDate, banglaMonthName } from '../core/bangla-date.js';

/* eslint-disable */
const PAL = {"MIN_GLASS": {"cardFill": 4278915616, "cardStroke": 956301311, "primary": 4294967295, "secondary": 3019898879, "accent": 4294296171, "track": 788529151}, "MIN_LIGHT": {"cardFill": 4293322468, "cardStroke": 603979776, "primary": 4279966490, "secondary": 4282006072, "accent": 4278870432, "track": 637534208}, "MIN_NOBG_DARK": {"cardFill": 0, "cardStroke": 0, "primary": 4294967295, "secondary": 3221225471, "accent": 4294296171, "track": 956301311}, "MIN_NOBG_LIGHT": {"cardFill": 0, "cardStroke": 0, "primary": 4279966490, "secondary": 4281216556, "accent": 4278870432, "track": 855638016}, "D1_GLASS": {"cardFill": 4278915616, "cardStroke": 4291217093, "day": 4294967295, "hijri": 4294967295, "date": 4294967295, "divider": 4289901234, "name": 4294967295, "time": 4294967295, "hlFill": 4292532954, "hlText": 4278915616, "now": 4294967295, "nowTime": 4294967295, "pillLabel": 4294967295, "pillTime": 4294967295, "clock": 4294967295, "pm": 4294967295}, "D1_LIGHT": {"cardFill": 4292532954, "cardStroke": 4283914070, "day": 4278190080, "hijri": 4278190080, "date": 4282137659, "divider": 4282137659, "name": 4282137659, "time": 4282137659, "hlFill": 4282137659, "hlText": 4294375158, "now": 4282137659, "nowTime": 4282137659, "pillLabel": 4282137659, "pillTime": 4282137659, "clock": 4279974492, "pm": 4282137659}, "D1_NOBG_DARK": {"cardFill": 0, "cardStroke": 0, "day": 4294967295, "hijri": 4294967295, "date": 4294967295, "divider": 4289901234, "name": 4294967295, "time": 4294967295, "hlFill": 4292532954, "hlText": 4278915616, "now": 4294967295, "nowTime": 4294967295, "pillLabel": 4294967295, "pillTime": 4294967295, "clock": 4294967295, "pm": 4294967295}, "D1_NOBG_LIGHT": {"cardFill": 0, "cardStroke": 0, "day": 4278190080, "hijri": 4278190080, "date": 4282137659, "divider": 4282137659, "name": 4282137659, "time": 4282137659, "hlFill": 4282137659, "hlText": 4294375158, "now": 4282137659, "nowTime": 4282137659, "pillLabel": 4282137659, "pillTime": 4282137659, "clock": 4279974492, "pm": 4282137659}, "D2_GLASS": {"cardFill": 4278915616, "cardStroke": 4291217093, "day": 4294967295, "hijri": 4294967295, "date": 4294967295, "divider": 4289901234, "name": 4294967295, "time": 4294967295, "hlFill": 4292532954, "hlText": 4278915616, "now": 4294967295, "nowTime": 4294967295, "pillLabel": 4294967295, "pillTime": 4294967295, "clock": 0, "pm": 0}, "D2_LIGHT": {"cardFill": 4292532954, "cardStroke": 4283914070, "day": 4278190080, "hijri": 4278190080, "date": 4282137659, "divider": 4282137659, "name": 4282137659, "time": 4282137659, "hlFill": 4282137659, "hlText": 4294375158, "now": 4282137659, "nowTime": 4282137659, "pillLabel": 4282137659, "pillTime": 4282137659, "clock": 0, "pm": 0}, "D2_NOBG_DARK": {"cardFill": 0, "cardStroke": 0, "day": 4294967295, "hijri": 4294967295, "date": 4294967295, "divider": 4289901234, "name": 4294967295, "time": 4294967295, "hlFill": 4292532954, "hlText": 4278915616, "now": 4294967295, "nowTime": 4294967295, "pillLabel": 4294967295, "pillTime": 4294967295, "clock": 0, "pm": 0}, "D2_NOBG_LIGHT": {"cardFill": 0, "cardStroke": 0, "day": 4278190080, "hijri": 4278190080, "date": 4282137659, "divider": 4282137659, "name": 4282137659, "time": 4282137659, "hlFill": 4282137659, "hlText": 4294375158, "now": 4282137659, "nowTime": 4282137659, "pillLabel": 4282137659, "pillTime": 4282137659, "clock": 0, "pm": 0}};
/* eslint-enable */

/** design id → mobile design number */
export const DESIGNS = { classic: 1, essential: 2, minimal: 4 };
const VKEY = { glass: 'GLASS', light: 'LIGHT', nobg_dark: 'NOBG_DARK', nobg_light: 'NOBG_LIGHT' };

const K = 1000 / 1170; // Fonts.BRAND_SCALE (the brand font has 1000 units per em, the design 1170)
const MIN = 60000;
const DAY = 86400000;
const GREG_MONTHS_BN = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
const GREG_MONTHS_EN = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

function argb(v) {
  if (!v) return 'rgba(0,0,0,0)';
  const a = ((v >>> 24) & 255) / 255;
  return `rgba(${(v >>> 16) & 255},${(v >>> 8) & 255},${v & 255},${a.toFixed(3)})`;
}
const lum = (v) => 0.299 * ((v >> 16) & 255) + 0.587 * ((v >> 8) & 255) + 0.114 * (v & 255);
const pad2 = (n) => (n < 10 ? `0${n}` : `${n}`);
function hms(ms) {
  const s = (Math.max(0, ms) / 1000) | 0;
  return `${pad2((s / 3600) | 0)}:${pad2(((s / 60) | 0) % 60)}:${pad2(s % 60)}`;
}

// Font faces are declared in css/widget.css (PtNS without size-adjust, so K is applied here).
const TF = { bold: ['700', 'PtNS', true], regular: ['400', 'PtNS', true], bebas: ['400', 'PtBebas', false], outfit: ['300', 'PtOutfit', false] };
let ctx;
function setFont(tf, size) {
  const f = TF[tf];
  ctx.font = `${f[0]} ${f[2] ? size * K : size}px ${f[1]}`;
}
function measure(s, tf, size) {
  setFont(tf, size);
  return ctx.measureText(s).width;
}
function text(s, x, y, size, color, tf, align) {
  setFont(tf, size);
  ctx.fillStyle = argb(color);
  ctx.textAlign = align || 'left';
  ctx.textBaseline = 'alphabetic';
  ctx.fillText(s, x, y);
  ctx.textAlign = 'left';
}
function fit(s, tf, size, maxW) {
  const w = measure(s, tf, size);
  return w > maxW ? (size * maxW) / w : size;
}
function rrect(l, tp, r, b, rx) {
  ctx.beginPath();
  ctx.roundRect(l, tp, r - l, b - tp, rx);
}
function fillRR(l, tp, r, b, rx, color) {
  rrect(l, tp, r, b, rx);
  ctx.fillStyle = argb(color);
  ctx.fill();
}
function tile(l, tp, r, b, rx, color, edge) {
  fillRR(l, tp, r, b, rx, color);
  if (edge) {
    rrect(l + 0.75, tp + 0.75, r - 0.75, b - 0.75, rx);
    ctx.lineWidth = 1.5;
    ctx.strokeStyle = argb(edge);
    ctx.stroke();
  }
}
function bar(x0, x1, y, h, frac, track, fill) {
  fillRR(x0, y, x1, y + h, h / 2, track);
  const fx = x0 + (x1 - x0) * Math.min(1, Math.max(0, frac));
  if (fx - x0 > h) fillRR(x0, y, fx, y + h, h / 2, fill);
}
function slimClock(hm, x, base, size, color) {
  setFont('outfit', size);
  const m0 = ctx.measureText('0');
  const m1 = ctx.measureText(':');
  const dy = (-m0.actualBoundingBoxAscent + m0.actualBoundingBoxDescent) / 2 - (-m1.actualBoundingBoxAscent + m1.actualBoundingBoxDescent) / 2;
  const a = hm.substr(0, 2);
  const b = hm.substr(3);
  const aw = measure(a, 'outfit', size);
  const cw = measure(':', 'outfit', size);
  const bw = measure(b, 'outfit', size);
  text(a, x, base, size, color, 'outfit');
  text(':', x + aw, base + dy, size, color, 'outfit');
  text(b, x + aw + cw, base, size, color, 'outfit');
  return aw + cw + bw;
}
function remLine(snap, dr, base, dsz, lsz, dcol, lcol, endMs) {
  text(hms((endMs || snap.periodEndMs) - snap.nowMs), dr, base, dsz, dcol, 'bebas', 'right');
  text(t('wdg.left'), dr + 10, base, lsz, lcol, 'regular');
}
function logoRing(art, m, cx, cy, lr) {
  ctx.beginPath();
  ctx.arc(cx, cy, lr, 0, 6.2832);
  ctx.fillStyle = argb((m.primary & 0xffffff) | 0x14000000);
  ctx.fill();
  ctx.lineWidth = lr * 0.111;
  ctx.strokeStyle = argb(m.primary);
  ctx.stroke();
  const lg = art.logo(lum(m.primary) > 150);
  const lh = lr * 1.333;
  const lw = (lh * lg.width) / lg.height;
  ctx.drawImage(lg, cx - lw / 2, cy - lh / 2, lw, lh);
}

// ---------------------------------------------------------------- live snapshot (Snapshot.kt)

/** "০৪:৫২" — 12-hour clock with two digits, digits in the app language. */
function clock12(ms) {
  const d = new Date(ms);
  return num(`${pad2(d.getHours() % 12 || 12)}:${pad2(d.getMinutes())}`);
}

export function snapshot(s, st, nowMs) {
  const tm = st.today;
  let cur;
  let start;
  let end;
  let running = true;
  if (nowMs < tm.fajr) [cur, start, end] = [4, tm.isha - DAY, tm.fajr];
  else if (nowMs < tm.sunrise) [cur, start, end] = [0, tm.fajr, tm.sunrise];
  else if (nowMs < tm.dhuhr) [cur, start, end, running] = [-1, tm.sunrise, tm.dhuhr, false];
  else if (nowMs < tm.asr) [cur, start, end] = [1, tm.dhuhr, tm.asr];
  else if (nowMs < tm.maghrib) [cur, start, end] = [2, tm.asr, tm.maghrib];
  else if (nowMs < tm.isha) [cur, start, end] = [3, tm.maghrib, tm.isha];
  else [cur, start, end] = [4, tm.isha, st.tomorrow.fajr];

  // Thursday after sunset until Friday sunset: "জুম’আ" instead of "যোহর" (mobile widget rule).
  const dow = st.date.getDay();
  const jumuah = (dow === 5 && nowMs < tm.maghrib) || (dow === 4 && nowMs >= tm.maghrib);
  const names = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'].map((k) => t(`waqt.${k}`));
  if (jumuah) names[1] = t('waqt.jumuah');
  const name = cur >= 0 ? names[cur] : names[1];

  const srEnd = tm.sunrise + 15 * MIN;
  const noonStart = tm.dhuhr - 12 * MIN;
  const evStart = tm.sunset - 15 * MIN;
  let forbid = 0;
  let forbidStart = 0;
  let forbidEnd = 0;
  if (nowMs >= tm.sunrise && nowMs < srEnd) [forbid, forbidStart, forbidEnd] = [1, tm.sunrise, srEnd];
  else if (nowMs >= srEnd && nowMs < noonStart) forbid = 2;
  else if (nowMs >= noonStart && nowMs < tm.dhuhr) [forbid, forbidStart, forbidEnd] = [1, noonStart, tm.dhuhr];
  else if (nowMs >= evStart && nowMs < tm.sunset) [forbid, forbidStart, forbidEnd] = [1, evStart, tm.sunset];

  const isDay = nowMs >= tm.sunrise && nowMs < tm.sunset;
  const h = st.hijri;
  const b = banglaDate(st.date);
  const months = lang() === 'en' ? GREG_MONTHS_EN : GREG_MONTHS_BN;
  return {
    nowMs,
    hijriDay: h ? num(pad2(h.day)) : '--',
    hijriMonthYear: h ? `${hijriMonthName(h)} ${num(h.year)}` : '--- ----',
    gregDay: num(pad2(st.date.getDate())),
    gregMonth: months[st.date.getMonth()],
    gregYear: num(st.date.getFullYear()),
    banglaDay: num(pad2(b.day)),
    banglaMonth: banglaMonthName(b),
    banglaYear: num(b.year),
    prayerNames: names,
    prayerTimes: [tm.fajr, tm.dhuhr, tm.asr, tm.maghrib, tm.isha].map(clock12),
    sehri: clock12(tm.fajr),
    iftar: clock12(tm.maghrib),
    current: cur,
    currentName: name,
    running,
    periodStartMs: start,
    periodEndMs: end,
    isPm: new Date(nowMs).getHours() >= 12,
    forbid,
    forbidStartMs: forbidStart,
    forbidEndMs: forbidEnd,
    gregFirst: false,
    sunLabel: isDay ? t('forbid.sunset') : t('forbid.sunrise'),
    sunTime: clock12(isDay ? tm.sunset : nowMs < tm.sunrise ? tm.sunrise : st.tomorrow.sunrise),
  };
}

// ---------------------------------------------------------------- Classic / Essential

const DATE_SEP = 30;
const CH12_X = 710;
const CH12_GAP = 10;
const PILL_SHIFT = 14;
const COL_CX = [137.35, 342.5, 542.72, 771.11, 984.43];
const HL_W = 185.78;
const HL_H = 145.83;
const HL_RX = 21.19;
const HL_NAME_DY = -5.82;
const HL_TIME_DY = -6.21;
const SUNRISE_R = [820, 25, 1072, 175];
const IFTAR_R = [806, 222, 1060, 358];
const LOGO2_R = [26, 16, 208, 198];
const D1_TILES = [[63, 222, 191, 350], [204, 222, 332, 350], [344, 281, 412, 349]];

const cardW = (d) => (d === 3 ? 981.41 : d >= 4 && d <= 9 ? 1000 : 1114.25);
function cardH(d, compact) {
  if (compact && d === 2) return 380;
  if (compact && d === 1) return 540;
  return { 1: 608.16, 2: 445.15, 3: 465.35, 4: 448, 5: 428, 6: 480, 7: 570, 9: 540 }[d] || 500;
}
const cardRx = (d) => (d === 1 ? 50.17 : d === 2 ? 42.93 : 56);

/** Window size (px) that fits a design well. */
export function designSize(design) {
  const d = DESIGNS[design] || 1;
  const w = 400;
  return { width: w, height: Math.round((w * (cardH(d) + 46)) / (cardW(d) + 46)) };
}

function clipOut(rects) {
  ctx.beginPath();
  ctx.rect(-5000, -5000, 10000, 10000);
  rects.forEach((r) => ctx.rect(r[0], r[1], r[2] - r[0], r[3] - r[1]));
  ctx.clip('evenodd');
}
function drawArt(img, d, cw, chh, soft) {
  ctx.save();
  const holes = [SUNRISE_R, LOGO2_R];
  if (d === 1) holes.push(IFTAR_R);
  if (soft) D1_TILES.forEach((tl) => holes.push([tl[0] - 2, tl[1] - 2, tl[2] + 2, tl[3] + 2]));
  clipOut(holes);
  ctx.drawImage(img, 0, 0, cw, chh);
  ctx.restore();
  if (soft) D1_TILES.forEach((tl) => fillRR(tl[0] - 0.5, tl[1] - 0.5, tl[2] + 0.5, tl[3] + 0.5, 22, 0x24244866));
  const piece = (r) => ctx.drawImage(img, r[0], r[1], r[2] - r[0], r[3] - r[1], r[0] + PILL_SHIFT, r[1], r[2] - r[0], r[3] - r[1]);
  piece(SUNRISE_R);
  if (d === 1) piece(IFTAR_R);
}

function classic(art, d, snap, pal) {
  const yOff = d === 1 ? 0 : -160;
  const dayX = 216.32;
  const bigDay = snap.gregFirst ? snap.gregDay : snap.hijriDay;
  const bigMonth = snap.gregFirst ? `${snap.gregMonth} ${snap.gregYear}` : snap.hijriMonthYear;
  text(bigDay, dayX, 103.57, 110, pal.day, 'bold');
  const hx = dayX + measure(bigDay, 'bold', 110) + 10.53;
  let hs = 55;
  const hw = measure(bigMonth, 'bold', hs);
  const hAvail = 825 - hx;
  if (hw > hAvail) hs = (55 * hAvail) / hw;
  text(bigMonth, hx, 102.29, hs, pal.hijri, 'bold');
  let ds = 52;
  const g1 = snap.gregFirst ? `${snap.hijriDay} ${snap.hijriMonthYear}` : `${snap.gregDay} ${snap.gregMonth} ${snap.gregYear}`;
  const g2 = `${snap.banglaDay} ${snap.banglaMonth} ${snap.banglaYear}`;
  let w1 = measure(g1, 'bold', ds);
  const w2 = measure(g2, 'bold', ds);
  const total = w1 + DATE_SEP + w2;
  const f = total > 612 ? 612 / total : 1;
  if (f < 1) {
    ds *= f;
    w1 *= f;
  }
  text(g1, dayX, 162.99, ds, pal.date, 'bold');
  const dvx = dayX + w1 + ((DATE_SEP - 2.2) / 2) * f;
  ctx.fillStyle = argb((pal.date & 0xffffff) | 0xbf000000);
  ctx.fillRect(dvx, 123.4, 2.2 * f, 45.19);
  text(g2, dayX + w1 + DATE_SEP * f, 162.99, ds, pal.date, 'bold');
  text(snap.sunLabel, 1006.18 + PILL_SHIFT, 89.51, 52.19, pal.pillLabel, 'bold', 'center');
  text(snap.sunTime, 1005.07 + PILL_SHIFT, 146.66, 63.36, pal.pillTime, 'bold', 'center');
  // logo (squircle)
  const ink = pal.date;
  const lx = 116;
  const ly = 107;
  const half = 79;
  const rr = 46;
  fillRR(lx - half, ly - half, lx + half, ly + half, rr, (ink & 0xffffff) | 0x14000000);
  rrect(lx - half, ly - half, lx + half, ly + half, rr);
  ctx.lineWidth = 6;
  ctx.strokeStyle = argb(ink);
  ctx.stroke();
  const lg = art.logo(lum(pal.date) > 150);
  const lh = 104;
  const lw = (lh * lg.width) / lg.height;
  ctx.drawImage(lg, lx - lw / 2, ly - lh / 2, lw, lh);
  if (d === 1) {
    const now = new Date(snap.nowMs);
    text(t('wdg.sehri'), 698.77, 279.37, 52.19, pal.pillLabel, 'bold', 'center');
    text(snap.sehri, 703.71, 331.96, 63.36, pal.pillTime, 'bold', 'center');
    text(t('wdg.iftar'), 995.9 + PILL_SHIFT, 279.37, 52.19, pal.pillLabel, 'bold', 'center');
    text(snap.iftar, 992.11 + PILL_SHIFT, 331.96, 63.36, pal.pillTime, 'bold', 'center');
    text(snap.isPm ? 'PM' : 'AM', 424.41, 299.25, 40, pal.pm, 'bebas');
    text(pad2(now.getHours() % 12 || 12), 65.32, 332.48, 136.17, pal.clock, 'bebas');
    text(pad2(now.getMinutes()), 218.54, 334.48, 125, pal.clock, 'bebas');
    text(pad2(now.getSeconds()), 353.03, 340.13, 65, pal.clock, 'bebas');
  }
  const nameY = 448.74 + yOff;
  const timeY = 502.65 + yOff;
  const hlY = 381.16 + yOff;
  for (let i = 0; i < 5; i++) {
    const cx = COL_CX[i];
    const hl = snap.current === i && snap.forbid === 0;
    if (hl) fillRR(cx - HL_W / 2, hlY, cx + HL_W / 2, hlY + HL_H, HL_RX, pal.hlFill);
    text(snap.prayerNames[i], cx, nameY + (hl ? HL_NAME_DY : 0), 60, hl ? pal.hlText : pal.name, 'regular', 'center');
    text(snap.prayerTimes[i], cx, timeY + (hl ? HL_TIME_DY : 0), 60, hl ? pal.hlText : pal.time, 'bold', 'center');
  }
  if (snap.forbid === 2) return;
  const nowY = 577.67 + yOff;
  const inF = snap.forbid === 1;
  const warn = lum(pal.name) > 150 ? 0xffff8f7a : 0xffc62828;
  const prefix = inF ? t('wdg.forbidLeft') : snap.running ? t('wdg.elapsed', { name: snap.currentName }) : t('wdg.startsIn', { name: snap.currentName });
  let ps = 50;
  const labelEnd = CH12_X - CH12_GAP;
  let pw = measure(prefix, inF ? 'bold' : 'regular', ps);
  const maxLabel = labelEnd - 40;
  if (pw > maxLabel) {
    ps *= maxLabel / pw;
    pw = maxLabel;
  }
  text(prefix, labelEnd - pw, nowY, ps, inF ? warn : pal.now, inF ? 'bold' : 'regular');
  text(hms(inF ? snap.forbidEndMs - snap.nowMs : snap.running ? snap.nowMs - snap.periodStartMs : snap.periodEndMs - snap.nowMs), CH12_X, nowY, 40, pal.nowTime, 'bebas');
}

// ---------------------------------------------------------------- Minimal

function minimal(art, snap, m) {
  const cw = cardW(4);
  const now = new Date(snap.nowMs);
  const hm = `${pad2(now.getHours() % 12 || 12)}:${pad2(now.getMinutes())}`;
  const L = 40;
  const R = cw - 40;
  const colW = (R - L) / 5;
  const span = Math.max(1, snap.periodEndMs - snap.periodStartMs);
  const frac = Math.min(1, Math.max(0, (snap.nowMs - snap.periodStartMs) / span));
  const warn = lum(m.primary) > 150 ? 0xffff8f7a : 0xffc62828;
  const f4 = snap.forbid;
  const dsz = 39;
  logoRing(art, m, L + 29, 64, 29);
  text(`${snap.gregDay} ${snap.gregMonth} ${snap.gregYear}`, L + 74, 80, dsz, m.secondary, 'bold');
  text(`${snap.hijriDay} ${snap.hijriMonthYear}`, R, 80, dsz, m.secondary, 'bold', 'right');
  const clockSize = 172;
  const clockEnd = L - 6 + (measure('00', 'outfit', clockSize) * 2 + measure(':', 'outfit', clockSize));
  const cwNow = measure(hm.substr(0, 2), 'outfit', clockSize) + measure(':', 'outfit', clockSize) + measure(hm.substr(3), 'outfit', clockSize);
  slimClock(hm, clockEnd - cwNow, 250, clockSize, m.primary);
  const sx = clockEnd + 22 + measure('00', 'outfit', 44) / 2;
  text(snap.isPm ? 'PM' : 'AM', sx, 202, 44, m.accent, 'outfit', 'center');
  text(pad2(now.getSeconds()), sx, 250, 44, m.primary, 'outfit', 'center');
  const bx0 = clockEnd + 22 + 90;
  const chipTxt = t('home.running');
  const chipSz = 26;
  const chipW = measure(chipTxt, 'bold', chipSz) + 32;
  if (f4 === 0) {
    const nsz = fit(snap.currentName, 'bold', 68, R - bx0 - chipW - 16);
    const nw = measure(snap.currentName, 'bold', nsz);
    text(snap.currentName, R - chipW - 16 - nw, 204, nsz, m.accent, 'bold');
    const cx0 = R - chipW;
    tile(cx0, 156, R, 200, 22, (m.accent & 0xffffff) | 0x2e000000, ((m.accent & 0xffffff) | 0x80000000) >>> 0);
    text(chipTxt, cx0 + chipW / 2, 188, chipSz, m.accent, 'bold', 'center');
    remLine(snap, 898, 254, 44, 38, m.primary, m.primary);
  } else if (f4 === 1) {
    const label = t('home.forbiddenTitle');
    const nz = fit(label, 'bold', 68, R - bx0);
    text(label, R, 204, nz, warn, 'bold', 'right');
    remLine(snap, 898, 254, 44, 38, m.primary, m.primary, snap.forbidEndMs);
  } else {
    text('–', R, 204, 84, m.secondary, 'bold', 'right');
    text('–', R, 254, 50, m.secondary, 'bold', 'right');
  }
  const barFrac = f4 === 1 ? Math.min(1, Math.max(0, (snap.nowMs - snap.forbidStartMs) / Math.max(1, snap.forbidEndMs - snap.forbidStartMs))) : f4 === 2 ? 0 : frac;
  bar(L, R, 296, 8, barFrac, m.track, f4 === 1 ? warn : m.accent);
  for (let i = 0; i < 5; i++) {
    const cx = L + colW * (i + 0.5);
    const on = f4 === 0 && snap.current === i;
    text(snap.prayerNames[i], cx, 360, 39, on ? m.accent : m.secondary, 'bold', 'center');
    text(snap.prayerTimes[i], cx, 416, 48, on ? m.accent : m.primary, 'bold', 'center');
  }
}

// ---------------------------------------------------------------- drawing (WidgetRenderer.draw)

const imgs = {};
function load(src) {
  if (!imgs[src]) {
    imgs[src] = new Promise((ok, no) => {
      const i = new Image();
      i.onload = () => ok(i);
      i.onerror = no;
      i.src = `img/widget/${src}`;
    });
  }
  return imgs[src];
}

let fontsReady = null;
export function loadFonts() {
  if (!fontsReady) {
    fontsReady = Promise.all(['700 20px PtNS', '400 20px PtNS', '400 20px PtBebas', '300 20px PtOutfit'].map((f) => document.fonts.load(f, 'অ0'))).catch(() => {});
  }
  return fontsReady;
}

/** Draws the design into the canvas, filling the given CSS size. */
export async function draw(canvas, design, variant, snap, W, H) {
  await loadFonts();
  const d = DESIGNS[design] || 1;
  const v = VKEY[variant] || 'GLASS';
  const compact = d <= 2 && snap.forbid === 2;
  const cw = cardW(d);
  const chh = cardH(d, compact);
  const PAD = 23;
  const dpr = Math.max(1, window.devicePixelRatio || 1);
  const s = Math.min(W / (cw + 2 * PAD), H / (chh + 2 * PAD));
  const ox = (W - cw * s) / 2;
  const oy = (H - chh * s) / 2;
  const logoLight = await load('logo_path_w.webp');
  const logoDark = await load('logo_path_d.webp');
  const img = d <= 2 ? await load(`art_d${d}_${variant in VKEY ? variant : 'glass'}.webp`) : null;

  if (canvas.width !== Math.round(W * dpr) || canvas.height !== Math.round(H * dpr)) {
    canvas.width = Math.round(W * dpr);
    canvas.height = Math.round(H * dpr);
  }
  canvas.style.width = `${W}px`;
  canvas.style.height = `${H}px`;
  ctx = canvas.getContext('2d');
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.setTransform(dpr * s, 0, 0, dpr * s, dpr * ox, dpr * oy);
  const pal = d >= 4 ? PAL[`MIN_${v}`] : PAL[`D${d}_${v}`];
  const fill = pal.cardFill;
  const stroke = pal.cardStroke;
  if (fill) {
    const rx = cardRx(d);
    const a = Math.round(((fill >>> 24) & 255) * 0.85);
    fillRR(0.5, 0.5, cw - 0.5, chh - 0.5, rx, ((a << 24) | (fill & 0xffffff)) >>> 0);
    if (stroke) {
      rrect(0.5, 0.5, cw - 0.5, chh - 0.5, rx);
      ctx.lineWidth = 1;
      ctx.strokeStyle = argb(stroke);
      ctx.stroke();
    }
  }
  const art = { logo: (light) => (light ? logoLight : logoDark) };
  if (d <= 2) {
    drawArt(img, d, cw, cardH(d), d === 1 && (v === 'LIGHT' || v === 'NOBG_LIGHT'));
    classic(art, d, snap, pal);
  } else minimal(art, snap, pal);
}
