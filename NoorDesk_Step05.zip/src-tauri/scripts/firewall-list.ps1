# Firewall manager: lists the Windows Firewall rules that belong to a program.
# This script ONLY READS and needs no administrator rights.
param([string]$InputFile, [string]$OutputFile)

$ErrorActionPreference = 'Stop'
$out = @{ ok = $false; message = ''; rules = @() }

try {
    # Program path of every rule, read in one go (asking rule by rule would take minutes).
    $programs = @{}
    foreach ($filter in @(Get-NetFirewallApplicationFilter -All -ErrorAction SilentlyContinue)) {
        $path = [string]$filter.Program
        if ($path -and ($path -ne 'Any')) { $programs[[string]$filter.InstanceID] = $path }
    }

    $list = New-Object System.Collections.ArrayList
    foreach ($rule in @(Get-NetFirewallRule -ErrorAction SilentlyContinue)) {
        $id = [string]$rule.Name
        if (-not $programs.ContainsKey($id)) { continue }
        [void]$list.Add(@{
            id = $id
            name = [string]$rule.DisplayName
            program = [string]$programs[$id]
            direction = [string]$rule.Direction
            action = [string]$rule.Action
            enabled = ([string]$rule.Enabled -eq 'True')
            group = [string]$rule.Group
            ours = ([string]$rule.Group -eq 'NoorDesk')
        })
    }
    $out.rules = @($list)
    $out.ok = $true
} catch {
    $out.message = [string]$_.Exception.Message
}

[System.IO.File]::WriteAllText($OutputFile, ($out | ConvertTo-Json -Depth 5 -Compress))
