# Firewall manager: changes Windows Firewall rules. Runs with administrator rights
# (Windows asks the user first). Every action returns what is needed to undo it.
#
#   add      create a rule that blocks (or allows) one program            -> created ids
#   remove   delete rules, but only rules this app created itself          -> removed rule details
#   restore  create rules again from saved details (undo of remove)        -> created ids
#   enable   switch existing rules on or off                               -> previous states
param([string]$InputFile, [string]$OutputFile)

$ErrorActionPreference = 'Stop'
$group = 'NoorDesk'
$out = @{ ok = $false; message = ''; created = @(); removed = @(); previous = @(); skipped = @() }

function New-AppRule([string]$displayName, [string]$program, [string]$direction, [string]$action, [bool]$enabled) {
    $state = 'True'
    if (-not $enabled) { $state = 'False' }
    $rule = New-NetFirewallRule -DisplayName $displayName -Program $program -Direction $direction -Action $action -Group $group -Profile Any -Enabled $state
    return [string]$rule.Name
}

try {
    $in = [System.IO.File]::ReadAllText($InputFile) | ConvertFrom-Json
    $action = [string]$in.action

    if ($action -eq 'add') {
        $program = [string]$in.program
        if (-not [System.IO.Path]::IsPathRooted($program)) { throw 'The program path is not complete.' }
        if ([System.IO.Path]::GetExtension($program).ToLower() -ne '.exe') { throw 'Only .exe programs can be chosen.' }
        if (-not (Test-Path -LiteralPath $program -PathType Leaf)) { throw 'The program file was not found.' }
        $label = ([string]$in.label).Trim()
        if (-not $label) { $label = [System.IO.Path]::GetFileName($program) }
        if ($label.Length -gt 80) { $label = $label.Substring(0, 80) }
        $ruleAction = 'Block'
        if ([string]$in.ruleAction -eq 'allow') { $ruleAction = 'Allow' }

        $directions = @('Outbound')
        if ([string]$in.direction -eq 'in') { $directions = @('Inbound') }
        if ([string]$in.direction -eq 'both') { $directions = @('Outbound', 'Inbound') }
        $created = @()
        foreach ($direction in $directions) {
            $created += New-AppRule ('NoorDesk: ' + $label + ' (' + $direction + ')') $program $direction $ruleAction $true
        }
        $out.created = @($created)
    }
    elseif ($action -eq 'remove') {
        $removed = @()
        foreach ($id in @($in.ids)) {
            $rule = Get-NetFirewallRule -Name ([string]$id) -ErrorAction SilentlyContinue
            if (-not $rule) { $out.skipped += [string]$id; continue }
            if ([string]$rule.Group -ne $group) { $out.skipped += [string]$id; continue }   # never delete rules of other programs
            $filter = $rule | Get-NetFirewallApplicationFilter
            $removed += @{
                name = [string]$rule.DisplayName
                program = [string]$filter.Program
                direction = [string]$rule.Direction
                action = [string]$rule.Action
                enabled = ([string]$rule.Enabled -eq 'True')
            }
            Remove-NetFirewallRule -Name ([string]$id)
        }
        $out.removed = @($removed)
    }
    elseif ($action -eq 'restore') {
        $created = @()
        foreach ($saved in @($in.rules)) {
            $direction = 'Outbound'
            if ([string]$saved.direction -eq 'Inbound') { $direction = 'Inbound' }
            $ruleAction = 'Block'
            if ([string]$saved.action -eq 'Allow') { $ruleAction = 'Allow' }
            $created += New-AppRule ([string]$saved.name) ([string]$saved.program) $direction $ruleAction ([bool]$saved.enabled)
        }
        $out.created = @($created)
    }
    elseif ($action -eq 'enable') {
        $previous = @()
        foreach ($item in @($in.items)) {
            $rule = Get-NetFirewallRule -Name ([string]$item.id) -ErrorAction SilentlyContinue
            if (-not $rule) { $out.skipped += [string]$item.id; continue }
            $previous += @{ id = [string]$item.id; enabled = ([string]$rule.Enabled -eq 'True') }
            $state = 'False'
            if ([bool]$item.enabled) { $state = 'True' }
            Set-NetFirewallRule -Name ([string]$item.id) -Enabled $state
        }
        $out.previous = @($previous)
    }
    else { throw 'Unknown action.' }

    $out.ok = $true
} catch {
    $out.message = [string]$_.Exception.Message
}

[System.IO.File]::WriteAllText($OutputFile, ($out | ConvertTo-Json -Depth 5 -Compress))
