//! Blocklists: download, read and look up.
//!
//! Names are stored as 64-bit fingerprints in sorted lists, so several hundred thousand
//! rules need only a few megabytes of memory.

use std::collections::HashMap;
use std::fs;
use std::net::IpAddr;
use std::path::{Path, PathBuf};
use std::process::Command;

use super::Config;

pub struct Source {
    pub id: &'static str,
    pub url: &'static str,
}

/// The open blocklists the app knows about.
pub const SOURCES: [Source; 8] = [
    // Optional categories (Step 5): harmful sites and family filters.
    Source {
        id: "malware",
        url: "https://malware-filter.gitlab.io/malware-filter/urlhaus-filter-hosts.txt",
    },
    Source {
        id: "phishing",
        url: "https://malware-filter.gitlab.io/malware-filter/phishing-filter-hosts.txt",
    },
    Source {
        id: "adult",
        url: "https://raw.githubusercontent.com/StevenBlack/hosts/master/alternates/porn-only/hosts",
    },
    Source {
        id: "gambling",
        url: "https://raw.githubusercontent.com/StevenBlack/hosts/master/alternates/gambling-only/hosts",
    },
    Source {
        id: "stevenblack",
        url: "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts",
    },
    Source {
        id: "adguard",
        url: "https://adguardteam.github.io/AdGuardSDNSFilter/Filters/filter.txt",
    },
    Source {
        id: "easylist",
        url: "https://easylist.to/easylist/easylist.txt",
    },
    Source {
        id: "easyprivacy",
        url: "https://easylist.to/easylist/easyprivacy.txt",
    },
];

const MAX_USER_ENTRIES: usize = 5000;
const MAX_CUSTOM_SOURCES: usize = 10;
/// A downloaded list with fewer rules than this is treated as a failed download
/// (for example a Wi-Fi login page that was returned instead of the list).
const MIN_RULES_IN_DOWNLOAD: usize = 20;

/// FNV-1a fingerprint of a name.
pub fn fingerprint(name: &str) -> u64 {
    let mut hash: u64 = 0xcbf2_9ce4_8422_2325;
    for byte in name.as_bytes() {
        hash ^= *byte as u64;
        hash = hash.wrapping_mul(0x0000_0100_0000_01b3);
    }
    hash
}

#[derive(Default)]
pub struct Rules {
    /// Names blocked exactly as written (hosts-file style lists).
    exact: Vec<u64>,
    /// Names blocked together with all their sub-names (filter style lists, user block list).
    suffix: Vec<u64>,
    /// Names that are always allowed, together with their sub-names.
    allow: Vec<u64>,
}

fn in_set(set: &[u64], name: &str) -> bool {
    set.binary_search(&fingerprint(name)).is_ok()
}

/// True if the name or one of its parent names is in the set. A bare ending such as "com"
/// is never tested.
fn in_set_or_parent(set: &[u64], name: &str) -> bool {
    if set.is_empty() {
        return false;
    }
    let mut rest = name;
    loop {
        if !rest.contains('.') {
            return false;
        }
        if in_set(set, rest) {
            return true;
        }
        match rest.find('.') {
            Some(dot) => rest = &rest[dot + 1..],
            None => return false,
        }
    }
}

impl Rules {
    pub fn block_count(&self) -> usize {
        self.exact.len() + self.suffix.len()
    }

    pub fn is_blocked(&self, name: &str) -> bool {
        if name.is_empty() || !name.contains('.') {
            return false;
        }
        if in_set_or_parent(&self.allow, name) {
            return false;
        }
        in_set(&self.exact, name) || in_set_or_parent(&self.suffix, name)
    }
}

/// Returns a clean lower-case domain name, or None if the text is not one.
pub fn clean_domain(text: &str) -> Option<String> {
    let name = text.trim().trim_end_matches('.').to_ascii_lowercase();
    if name.len() < 3 || name.len() > 253 || !name.contains('.') {
        return None;
    }
    if name.starts_with('.') || name.starts_with('-') || name.contains("..") {
        return None;
    }
    if !name
        .chars()
        .all(|c| c.is_ascii_lowercase() || c.is_ascii_digit() || c == '-' || c == '_' || c == '.')
    {
        return None;
    }
    if name.parse::<IpAddr>().is_ok() || name == "localhost.localdomain" {
        return None;
    }
    Some(name)
}

/// Cleans a line typed by the user: accepts "example.com", "https://example.com/page" etc.
fn clean_user_entry(line: &str) -> Option<String> {
    let mut text = line.trim();
    if text.is_empty() || text.starts_with('#') {
        return None;
    }
    if let Some(index) = text.find("://") {
        text = &text[index + 3..];
    }
    if let Some(index) = text.find(|c: char| c == '/' || c == '?' || c == ':') {
        text = &text[..index];
    }
    clean_domain(text)
}

/// Reads one list (hosts format, "||name^" filter format, or plain names).
/// Returns how many block rules it contained.
fn parse_into(text: &str, exact: &mut Vec<u64>, suffix: &mut Vec<u64>, allow: &mut Vec<u64>) -> usize {
    let mut found = 0usize;
    for raw in text.lines() {
        let line = raw.trim();
        if line.is_empty() || line.starts_with('#') || line.starts_with('!') || line.starts_with('[') {
            continue;
        }

        // Filter format exception: @@||name^
        if let Some(rest) = line.strip_prefix("@@||") {
            if let Some(name) = rest.strip_suffix('^').and_then(clean_domain) {
                allow.push(fingerprint(&name));
            }
            continue;
        }
        // Filter format rule for a whole domain: ||name^   (rules with options or paths are skipped)
        if let Some(rest) = line.strip_prefix("||") {
            if let Some(name) = rest.strip_suffix('^').and_then(clean_domain) {
                suffix.push(fingerprint(&name));
                found += 1;
            }
            continue;
        }

        // Hosts format: "0.0.0.0 name"; or a plain name on its own.
        let mut parts = line.split_whitespace();
        let first = match parts.next() {
            Some(first) => first,
            None => continue,
        };
        let candidate = if first == "0" || first.parse::<IpAddr>().is_ok() {
            match parts.next() {
                Some(second) if !second.starts_with('#') => second,
                _ => continue,
            }
        } else {
            match parts.next() {
                Some(second) if !second.starts_with('#') => continue, // not a plain name line
                _ => first,
            }
        };
        if let Some(name) = clean_domain(candidate) {
            exact.push(fingerprint(&name));
            found += 1;
        }
    }
    found
}

fn custom_source_id(url: &str) -> String {
    format!("custom-{:016x}", fingerprint(url))
}

fn cache_file(dir: &Path, id: &str) -> PathBuf {
    dir.join(format!("{}.txt", id))
}

/// (id, url) of every list that is switched on.
pub fn enabled_sources(config: &Config) -> Vec<(String, String)> {
    let mut out: Vec<(String, String)> = Vec::new();
    for source in SOURCES.iter() {
        if config.sources.iter().any(|id| id.as_str() == source.id) {
            out.push((source.id.to_string(), source.url.to_string()));
        }
    }
    for url in config.custom_sources.iter().take(MAX_CUSTOM_SOURCES) {
        let url = url.trim();
        if valid_url(url) {
            out.push((custom_source_id(url), url.to_string()));
        }
    }
    out
}

fn valid_url(url: &str) -> bool {
    url.starts_with("https://")
        && url.len() <= 500
        && !url
            .chars()
            .any(|c| c.is_whitespace() || c.is_control() || c == '"' || c == '\'' || c == '`')
}

/// Builds the lookup rules from the lists saved on disk plus the user's own lists.
/// Also returns how many rules each list contributed.
pub fn build(dir: &Path, config: &Config) -> (Rules, HashMap<String, usize>) {
    let mut rules = Rules::default();
    let mut counts: HashMap<String, usize> = HashMap::new();

    for (id, _url) in enabled_sources(config) {
        let count = match fs::read_to_string(cache_file(dir, &id)) {
            Ok(text) => parse_into(&text, &mut rules.exact, &mut rules.suffix, &mut rules.allow),
            Err(_) => 0,
        };
        counts.insert(id, count);
    }

    let mut own = 0usize;
    for line in config.block.iter().take(MAX_USER_ENTRIES) {
        if let Some(name) = clean_user_entry(line) {
            rules.suffix.push(fingerprint(&name));
            own += 1;
        }
    }
    counts.insert("own".to_string(), own);

    for line in config.allow.iter().take(MAX_USER_ENTRIES) {
        if let Some(name) = clean_user_entry(line) {
            rules.allow.push(fingerprint(&name));
        }
    }

    rules.exact.sort_unstable();
    rules.exact.dedup();
    rules.suffix.sort_unstable();
    rules.suffix.dedup();
    rules.allow.sort_unstable();
    rules.allow.dedup();
    (rules, counts)
}

fn curl_path() -> PathBuf {
    match std::env::var_os("SystemRoot") {
        Some(root) => {
            let path = PathBuf::from(root).join("System32").join("curl.exe");
            if path.exists() {
                path
            } else {
                PathBuf::from("curl.exe")
            }
        }
        None => PathBuf::from("curl.exe"),
    }
}

/// Downloads one list with the curl program that is part of Windows and stores it in the
/// cache folder. The old copy is kept if the download fails or looks wrong.
fn download(dir: &Path, id: &str, url: &str) -> Result<usize, String> {
    if !valid_url(url) {
        return Err("Only https:// addresses are allowed".into());
    }
    fs::create_dir_all(dir).map_err(|e| e.to_string())?;
    let dest = cache_file(dir, id);
    let temp = dir.join(format!("{}.download", id));

    let mut command = Command::new(curl_path());
    command
        .args([
            "--location",
            "--fail",
            "--silent",
            "--show-error",
            "--max-time",
            "180",
            "--max-filesize",
            "80000000",
            "--proto",
            "=https",
            "--proto-redir",
            "=https",
            "--output",
        ])
        .arg(&temp)
        .arg(url);
    super::hide_window(&mut command);

    let output = command
        .output()
        .map_err(|e| format!("curl could not be started: {}", e))?;
    if !output.status.success() {
        let _ = fs::remove_file(&temp);
        let message: String = String::from_utf8_lossy(&output.stderr)
            .trim()
            .chars()
            .take(200)
            .collect();
        return Err(if message.is_empty() {
            "Download failed".to_string()
        } else {
            message
        });
    }

    let text = match fs::read_to_string(&temp) {
        Ok(text) => text,
        Err(e) => {
            let _ = fs::remove_file(&temp);
            return Err(e.to_string());
        }
    };
    let (mut exact, mut suffix, mut allow) = (Vec::new(), Vec::new(), Vec::new());
    let count = parse_into(&text, &mut exact, &mut suffix, &mut allow);
    if count < MIN_RULES_IN_DOWNLOAD {
        let _ = fs::remove_file(&temp);
        return Err("The downloaded file does not look like a blocklist".into());
    }
    fs::rename(&temp, &dest).map_err(|e| e.to_string())?;
    Ok(count)
}

/// Downloads every list that is switched on. Returns the number of lists updated and the
/// first error, if any.
pub fn update_all(dir: &Path, config: &Config) -> (usize, Option<String>) {
    let mut updated = 0usize;
    let mut first_error: Option<String> = None;
    for (id, url) in enabled_sources(config) {
        match download(dir, &id, &url) {
            Ok(_) => updated += 1,
            Err(e) => {
                crate::logging::write("WARN", &format!("Blocklist {} failed: {}", id, e));
                if first_error.is_none() {
                    first_error = Some(e);
                }
            }
        }
    }
    (updated, first_error)
}
