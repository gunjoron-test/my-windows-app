//! Locations of the files the app stores on disk (all inside the per-user app data folder).

use std::fs;
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, Ordering};

use tauri::{AppHandle, Manager};

/// True when the previous session ended without a clean exit (crash, power loss, kill).
static UNCLEAN_PREVIOUS_EXIT: AtomicBool = AtomicBool::new(false);

/// Per-user data folder, created on demand.
pub fn data_dir(app: &AppHandle) -> PathBuf {
    let dir = app
        .path()
        .app_data_dir()
        .unwrap_or_else(|_| std::env::temp_dir().join("noordesk"));
    let _ = fs::create_dir_all(&dir);
    dir
}

pub fn settings_file(app: &AppHandle) -> PathBuf {
    data_dir(app).join("settings.json")
}

pub fn settings_backup_file(app: &AppHandle) -> PathBuf {
    data_dir(app).join("settings.backup.json")
}

pub fn schedule_file(app: &AppHandle) -> PathBuf {
    data_dir(app).join("schedule.json")
}

pub fn widgets_file(app: &AppHandle) -> PathBuf {
    data_dir(app).join("widgets.json")
}

pub fn blocker_file(app: &AppHandle) -> PathBuf {
    data_dir(app).join("blocker.json")
}

pub fn blocklist_dir(app: &AppHandle) -> PathBuf {
    let dir = data_dir(app).join("blocklists");
    let _ = fs::create_dir_all(&dir);
    dir
}

pub fn netwatch_file(app: &AppHandle) -> PathBuf {
    data_dir(app).join("netwatch.json")
}

pub fn log_dir(app: &AppHandle) -> PathBuf {
    let dir = data_dir(app).join("logs");
    let _ = fs::create_dir_all(&dir);
    dir
}

fn running_flag(app: &AppHandle) -> PathBuf {
    data_dir(app).join("running.flag")
}

/// Creates the "running" flag. Returns true if it already existed, which means the
/// previous session did not exit cleanly.
pub fn mark_running(app: &AppHandle) -> bool {
    let flag = running_flag(app);
    let unclean = flag.exists();
    UNCLEAN_PREVIOUS_EXIT.store(unclean, Ordering::Relaxed);
    let _ = fs::write(&flag, b"running");
    unclean
}

pub fn clear_running(app: &AppHandle) {
    let _ = fs::remove_file(running_flag(app));
}

pub fn previous_exit_was_unclean() -> bool {
    UNCLEAN_PREVIOUS_EXIT.load(Ordering::Relaxed)
}
