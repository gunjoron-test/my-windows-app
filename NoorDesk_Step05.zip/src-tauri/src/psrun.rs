//! Runs one of the app's bundled PowerShell scripts and returns the JSON it writes.
//!
//! The script and its input are written to the app's own folder, the script is run, and the
//! output file is read. With `elevated` the script runs with administrator rights: Windows
//! shows its permission question (UAC), and Err("cancelled") means the user answered No.

use std::fs;
use std::path::Path;
use std::process::Command;
use std::sync::Mutex;

use serde_json::Value;
use tauri::AppHandle;

use crate::{blocker, paths};

/// Exit code of the launcher when the user refuses the Windows permission question.
const EXIT_CANCELLED: i32 = 5;

/// Scripts share temporary file names, so only one runs at a time.
static RUN_LOCK: Mutex<()> = Mutex::new(());

fn quoted(path: &Path) -> String {
    path.to_string_lossy().replace('\'', "''")
}

pub fn run(
    app: &AppHandle,
    name: &str,
    script: &str,
    input: &Value,
    elevated: bool,
) -> Result<Value, String> {
    let _guard = RUN_LOCK.lock().unwrap_or_else(|e| e.into_inner());

    let dir = paths::data_dir(app).join("scripts-tmp");
    fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    let script_file = dir.join(format!("{}.ps1", name));
    let input_file = dir.join(format!("{}-in.json", name));
    let output_file = dir.join(format!("{}-out.json", name));
    let _ = fs::remove_file(&output_file);

    // The byte-order mark makes Windows PowerShell read the script as UTF-8.
    fs::write(&script_file, format!("\u{feff}{}", script).as_bytes()).map_err(|e| e.to_string())?;
    fs::write(&input_file, input.to_string().as_bytes()).map_err(|e| e.to_string())?;

    let mut command = Command::new("powershell.exe");
    if elevated {
        let launcher = format!(
            "try {{ Start-Process -FilePath 'powershell.exe' -Verb RunAs -WindowStyle Hidden -Wait -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File','\"{}\"','-InputFile','\"{}\"','-OutputFile','\"{}\"' -ErrorAction Stop; exit 0 }} catch {{ exit {} }}",
            quoted(&script_file),
            quoted(&input_file),
            quoted(&output_file),
            EXIT_CANCELLED
        );
        command.args([
            "-NoProfile",
            "-NonInteractive",
            "-ExecutionPolicy",
            "Bypass",
            "-Command",
            launcher.as_str(),
        ]);
    } else {
        command
            .args(["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File"])
            .arg(&script_file)
            .arg("-InputFile")
            .arg(&input_file)
            .arg("-OutputFile")
            .arg(&output_file);
    }
    blocker::hide_window(&mut command);

    let status = command.status();
    let text = fs::read_to_string(&output_file);
    let _ = fs::remove_file(&script_file);
    let _ = fs::remove_file(&input_file);
    let _ = fs::remove_file(&output_file);

    let status = status.map_err(|e| format!("PowerShell could not be started: {}", e))?;
    if elevated && status.code() == Some(EXIT_CANCELLED) {
        return Err("cancelled".into());
    }
    let text = text.map_err(|_| "no-result".to_string())?;
    serde_json::from_str::<Value>(text.trim_start_matches('\u{feff}')).map_err(|_| "no-result".to_string())
}

/// Like `run`, but also turns a script-level failure ({"ok": false, "message": ...}) into Err.
pub fn run_checked(
    app: &AppHandle,
    name: &str,
    script: &str,
    input: &Value,
    elevated: bool,
) -> Result<Value, String> {
    let value = run(app, name, script, input, elevated)?;
    if value.get("ok").and_then(|v| v.as_bool()) == Some(true) {
        Ok(value)
    } else {
        let message = value.get("message").and_then(|v| v.as_str()).unwrap_or("");
        Err(if message.is_empty() {
            "no-result".to_string()
        } else {
            message.to_string()
        })
    }
}
