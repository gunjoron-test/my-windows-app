// Module C: system-wide ad and tracker blocker (control page).
// The filter itself runs in the backend; this page shows its state and sends it settings.

import { invoke, log } from '../../core/bridge.js';
import { fmtTime, num, t } from '../../core/i18n.js';
import * as store from '../../core/store.js';
import { button, card, flash, notice, row, select, toggle } from '../../core/ui.js';
import { esc } from '../../core/util.js';

export const SOURCE_IDS = ['stevenblack', 'adguard', 'easylist', 'easyprivacy'];

/** Optional filter categories (Step 5): harmful sites and family filters. */
export const CATEGORY_IDS = ['malware', 'phishing', 'adult', 'gambling'];

const EMPTY_STATUS = {
  active: false, paused: false, running: false, busy: false, v6: false, dnsChanged: false,
  total: 0, today: 0, forwarded: 0, ruleCount: 0, listCounts: {}, lastUpdate: 0,
  upstreams: [], recent: [], lastError: '',
};

let app = null;
let status = { ...EMPTY_STATUS };
let working = false; // a button action started from this page is running
let configTimer = null;
let lastPoll = 0;
let pageKey = '';

const lines = (text) =>
  String(text || '')
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);

function configFromSettings() {
  const b = store.get().blocker;
  return {
    sources: [...SOURCE_IDS, ...CATEGORY_IDS].filter((id) => b.sources[id]),
    doh: b.doh || 'off',
    customSources: lines(b.customSources).slice(0, 10),
    allow: lines(b.allowList).slice(0, 5000),
    block: lines(b.blockList).slice(0, 5000),
    updateDays: Number(b.updateDays) || 0,
    fallback: b.fallback,
  };
}

async function pushConfig() {
  try {
    status = (await invoke('blocker_configure', { config: configFromSettings() })) || status;
  } catch (e) {
    log('error', e);
  }
}

function pushConfigSoon() {
  clearTimeout(configTimer);
  configTimer = setTimeout(pushConfig, 500);
}

async function poll() {
  lastPoll = Date.now();
  try {
    status = (await invoke('blocker_status')) || status;
  } catch (e) {
    log('warn', e);
  }
}

/** Turns an error code from the backend into a sentence. */
function errorText(error) {
  const raw = String(error && error.message ? error.message : error);
  const code = raw.split(':')[0].trim();
  const known = ['busy', 'cancelled', 'port53', 'lists', 'no-upstream', 'selftest', 'no-result'];
  return known.includes(code) ? t(`blocker.err.${code}`) : `${t('blocker.err.other')} ${raw.slice(0, 200)}`;
}

async function runAction(command, args, okText) {
  if (working) return;
  working = true;
  app.render();
  try {
    status = (await invoke(command, args || {})) || status;
    if (okText) flash(okText);
  } catch (e) {
    flash(errorText(e), 'warn');
    await poll();
  }
  working = false;
  app.render();
}

// ---------------------------------------------------------------- page

function stateName() {
  if (!status.active) return 'off';
  if (!status.running) return 'broken';
  return status.paused ? 'paused' : 'on';
}

const stateKey = () => [stateName(), status.busy, working, status.dnsChanged, status.ruleCount, status.lastUpdate, status.lastError].join('|');

function fmtWhen(ms) {
  if (!ms) return t('blocker.never');
  const d = new Date(ms);
  const date = new Intl.DateTimeFormat(store.get().general.language === 'bn' ? 'bn-BD' : 'en-GB', { day: 'numeric', month: 'short', year: 'numeric' }).format(d);
  return `${date}, ${fmtTime(ms, store.get().general.timeFormat)}`;
}

function statusCard() {
  const state = stateName();
  const busy = working || status.busy;
  const disabled = busy ? 'disabled' : '';

  let controls;
  if (state === 'off') {
    controls = `<button type="button" class="btn primary big" data-action="blockerEnable" ${disabled}>${esc(t('blocker.turnOn'))}</button>`;
  } else {
    controls = `
      <button type="button" class="btn big" data-action="blockerPause" ${disabled}>${esc(t(status.paused ? 'blocker.resume' : 'blocker.pause'))}</button>
      <button type="button" class="btn big danger" data-action="blockerDisable" ${disabled}>${esc(t('blocker.turnOff'))}</button>`;
  }

  return `<section class="card blocker-status state-${state}">
    <div class="blocker-head">
      <div>
        <div class="small-label">${esc(t('blocker.statusLabel'))}</div>
        <div class="blocker-state">${esc(t(`blocker.state.${state}`))}</div>
        <div class="row-hint">${esc(busy ? t('blocker.working') : t(`blocker.stateHint.${state}`))}</div>
      </div>
      <div class="blocker-controls">${controls}</div>
    </div>
    <div class="stat-grid">
      <div><div class="small-label">${esc(t('blocker.today'))}</div><div class="big-value" id="blk-today">${esc(num(status.today))}</div></div>
      <div><div class="small-label">${esc(t('blocker.total'))}</div><div class="big-value" id="blk-total">${esc(num(status.total))}</div></div>
      <div><div class="small-label">${esc(t('blocker.rules'))}</div><div class="big-value">${esc(num(status.ruleCount))}</div></div>
    </div>
    ${status.lastError && state !== 'on' ? notice(`${t('blocker.lastError')} ${errorText(status.lastError)}`, 'warn') : ''}
    ${state === 'off' && status.dnsChanged ? notice(t('blocker.leftover'), 'warn') : ''}
    <p class="fine">${esc(t('blocker.uacNote'))}</p>
  </section>`;
}

function logRows() {
  if (!status.recent.length) return `<p class="fine">${esc(t('blocker.logEmpty'))}</p>`;
  const tf = store.get().general.timeFormat;
  const rows = status.recent
    .slice(0, 60)
    .map(
      (entry) => `<tr>
        <td class="mono">${esc(entry.domain)}</td>
        <td>${esc(num(entry.count))}</td>
        <td>${esc(fmtTime(entry.at, tf))}</td>
        <td><button type="button" class="btn small" data-action="blockerAllow" data-domain="${esc(entry.domain)}">${esc(t('blocker.allowBtn'))}</button></td>
      </tr>`,
    )
    .join('');
  return `<table class="times log-table">
    <thead><tr><th scope="col">${esc(t('blocker.logDomain'))}</th><th scope="col">${esc(t('blocker.logCount'))}</th><th scope="col">${esc(t('blocker.logTime'))}</th><th scope="col"></th></tr></thead>
    <tbody>${rows}</tbody>
  </table>`;
}

const textArea = (path, value, label, placeholder) =>
  `<textarea class="area" rows="5" data-bind="${path}" data-type="multiline" aria-label="${esc(label)}" placeholder="${esc(placeholder)}" spellcheck="false">${esc(value)}</textarea>`;

function renderBlocker() {
  const b = store.get().blocker;
  pageKey = stateKey();

  const sourceRows = SOURCE_IDS.map((id) => {
    const count = status.listCounts && status.listCounts[id];
    const hint = `${t(`blocker.src.${id}.desc`)}${count ? ` · ${t('blocker.rulesCount', { n: num(count) })}` : ''}`;
    return row(t(`blocker.src.${id}`), toggle(`blocker.sources.${id}`, b.sources[id]), hint);
  }).join('');

  const categoryRows = CATEGORY_IDS.map((id) => {
    const count = status.listCounts && status.listCounts[id];
    const hint = `${t(`blocker.cat.${id}.desc`)}${count ? ` · ${t('blocker.rulesCount', { n: num(count) })}` : ''}`;
    return row(t(`blocker.cat.${id}`), toggle(`blocker.sources.${id}`, !!b.sources[id]), hint);
  }).join('');

  const dohOptions = [['off', t('blocker.dohOff')], ['cloudflare', 'Cloudflare (1.1.1.1)'], ['quad9', 'Quad9 (9.9.9.9)'], ['google', 'Google (8.8.8.8)']];
  const dohState =
    !b.doh || b.doh === 'off'
      ? ''
      : `<p class="fine">${esc(t('blocker.dohStats', { ok: num(status.dohOk || 0), failed: num(status.dohFailed || 0) }))}</p>`;

  const updateOptions = [[1, t('blocker.every1')], [3, t('blocker.every3')], [7, t('blocker.every7')], [0, t('blocker.everyOff')]];
  const fallbackOptions = [['cloudflare', 'Cloudflare (1.1.1.1)'], ['quad9', 'Quad9 (9.9.9.9)'], ['google', 'Google (8.8.8.8)']];
  const busy = working || status.busy ? 'disabled' : '';

  return `
    ${statusCard()}
    ${notice(t('blocker.honest'))}
    ${card(
      t('blocker.listsTitle'),
      `${sourceRows}
       ${row(t('blocker.updateEvery'), select('blocker.updateDays', updateOptions, b.updateDays, 'int'), `${t('blocker.lastUpdate')}: ${fmtWhen(status.lastUpdate)}`)}
       ${row(t('blocker.updateNow'), `<button type="button" class="btn" data-action="blockerUpdate" ${busy}>${esc(t('blocker.updateNowBtn'))}</button>`, t('blocker.updateHint'))}
       <div class="row-label block">${esc(t('blocker.customSources'))}</div>
       <div class="row-hint">${esc(t('blocker.customSourcesHint'))}</div>
       ${textArea('blocker.customSources', b.customSources, t('blocker.customSources'), 'https://example.com/list.txt')}`,
    )}
    ${card(
      t('blocker.catTitle'),
      `<p class="fine">${esc(t('blocker.catHint'))}</p>${categoryRows}`,
    )}
    ${card(
      t('blocker.dohTitle'),
      `${row(t('blocker.dohLabel'), select('blocker.doh', dohOptions, b.doh || 'off'), t('blocker.dohHint'))}${dohState}`,
    )}
    ${card(
      t('blocker.allowTitle'),
      `<p class="fine">${esc(t('blocker.allowHint'))}</p>${textArea('blocker.allowList', b.allowList, t('blocker.allowTitle'), 'example.com')}`,
    )}
    ${card(
      t('blocker.blockTitle'),
      `<p class="fine">${esc(t('blocker.blockHint'))}</p>${textArea('blocker.blockList', b.blockList, t('blocker.blockTitle'), 'ads.example.com')}`,
    )}
    ${card(
      t('blocker.logTitle'),
      `<p class="fine">${esc(t('blocker.logHint'))}</p>
       <div id="blk-log">${logRows()}</div>
       ${button('blockerClearLog', t('blocker.logClear'))}`,
    )}
    ${card(
      t('blocker.safetyTitle'),
      `${row(t('blocker.fallback'), select('blocker.fallback', fallbackOptions, b.fallback), t('blocker.fallbackHint'))}
       <p class="fine">${esc(t('blocker.upstreams'))}: ${esc(status.upstreams.length ? status.upstreams.join(', ') : '—')}</p>
       ${row(t('blocker.repair'), `<button type="button" class="btn danger" data-action="blockerRepair" ${busy}>${esc(t('blocker.repairBtn'))}</button>`, t('blocker.repairHint'))}
       ${row(t('blocker.tool'), button('blockerOpenFolder', t('blocker.toolBtn')), t('blocker.toolHint'))}
       ${notice(t('blocker.uninstallNote'), 'warn')}`,
    )}`;
}

async function tickBlocker() {
  if (Date.now() - lastPoll < 2000 || working) return;
  await poll();
  const typing = document.activeElement && document.activeElement.tagName === 'TEXTAREA';
  if (stateKey() !== pageKey && !typing) {
    app.render();
    return;
  }
  // Only the running numbers and the log change: update just those.
  const today = document.getElementById('blk-today');
  if (today) today.textContent = num(status.today);
  const total = document.getElementById('blk-total');
  if (total) total.textContent = num(status.total);
  const logBox = document.getElementById('blk-log');
  if (logBox && !logBox.contains(document.activeElement)) logBox.innerHTML = logRows();
}

const blockerModule = {
  id: 'blocker',
  titleKey: 'module.blocker',
  canDisable: true,

  pages: [{ id: 'blocker', icon: '🛡️', titleKey: 'nav.blocker', render: renderBlocker, tick: () => { tickBlocker().catch((e) => log('warn', e)); } }],

  actions: {
    blockerEnable() {
      return runAction('blocker_enable', {}, t('blocker.enabledMsg'));
    },
    blockerDisable() {
      if (!window.confirm(t('blocker.confirmOff'))) return undefined;
      return runAction('blocker_disable', {}, t('blocker.disabledMsg'));
    },
    blockerRepair() {
      if (!window.confirm(t('blocker.confirmRepair'))) return undefined;
      return runAction('blocker_repair', {}, t('blocker.repairedMsg'));
    },
    blockerUpdate() {
      return runAction('blocker_update', {}, t('blocker.updatedMsg'));
    },
    async blockerPause() {
      try {
        status = (await invoke('blocker_pause', { paused: !status.paused })) || status;
      } catch (e) {
        log('error', e);
      }
      app.render();
    },
    async blockerClearLog() {
      try {
        status = (await invoke('blocker_clear_log')) || status;
      } catch (e) {
        log('error', e);
      }
      app.render();
    },
    blockerAllow(el) {
      const domain = el.dataset.domain;
      if (!domain) return;
      const current = lines(store.get().blocker.allowList);
      if (!current.includes(domain)) {
        store.set('blocker.allowList', [...current, domain].join('\n'));
        flash(t('blocker.allowedMsg', { domain }));
      }
    },
    async blockerOpenFolder() {
      await invoke('blocker_open_folder').catch((e) => log('warn', e));
    },
  },

  async init(appContext) {
    app = appContext;
    await pushConfig();
    await poll();
  },

  onSettingsChanged(path) {
    if (path === '*' || path.startsWith('blocker.')) pushConfigSoon();
    // The blocker changes a Windows setting, so the module cannot be hidden while it is on.
    if (path === 'modules.blocker' && store.get().modules.blocker === false && (status.active || status.dnsChanged)) {
      store.set('modules.blocker', true);
      flash(t('blocker.cannotHide'), 'warn');
    }
  },
};

export default blockerModule;
