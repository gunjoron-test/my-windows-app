// Module E: extra privacy and security tools.
//   * Firewall page: new-program alert, block a program, rules made by this app, other rules, undo.
//   * Cleaner page: preview and delete browser cookies / history / cache, clear the clipboard.
// (Encrypted DNS and the filter categories live on the ad blocker page; the privacy score
//  lives on the privacy check page.)

import { invoke, listen, log, pickFile } from '../../core/bridge.js';
import { fmtTime, lang, num, t } from '../../core/i18n.js';
import { isEnabled } from '../../core/modules.js';
import * as store from '../../core/store.js';
import { button, card, flash, notice, row, toggle } from '../../core/ui.js';
import { esc } from '../../core/util.js';

let app = null;

// ---- firewall state
let rules = null; // null = not loaded yet
let fwLoading = false;
let fwError = '';
let fwHistory = [];
let fwFilter = '';
let fwWorking = false;
let watch = { enabled: false, learning: false, known: 0, pending: [] };
let lastWatchPoll = 0;

// ---- cleaner state
let cleanData = null;
let cleanLoading = false;
let cleanWorking = false;
let cleanError = '';
let cleanResults = null;
let cleanClipboard = false;
const cleanSelected = new Set(); // "browser|profile|kind"

const baseName = (path) => String(path || '').split(/[\\/]/).pop();

function fmtWhen(ms) {
  if (!ms) return '';
  const date = new Intl.DateTimeFormat(lang() === 'bn' ? 'bn-BD' : 'en-GB', { day: 'numeric', month: 'short' }).format(new Date(ms));
  return `${date}, ${fmtTime(ms, store.get().general.timeFormat)}`;
}

function fmtBytes(bytes) {
  const mb = (Number(bytes) || 0) / 1048576;
  if (mb >= 1024) return `${num((mb / 1024).toFixed(1))} GB`;
  if (mb >= 10) return `${num(Math.round(mb))} MB`;
  return `${num(mb.toFixed(1))} MB`;
}

function errorText(error) {
  const raw = String(error && error.message ? error.message : error);
  if (raw === 'cancelled') return t('fw.cancelled');
  if (raw === 'no-result') return t('fw.noResult');
  return `${t('fw.failed')} ${raw.slice(0, 200)}`;
}

// ================================================================ firewall

async function loadRules() {
  if (fwLoading) return;
  fwLoading = true;
  fwError = '';
  app.render();
  try {
    const result = await invoke('firewall_list');
    rules = (result && result.rules) || [];
  } catch (e) {
    log('error', e);
    rules = [];
    fwError = errorText(e);
  }
  fwLoading = false;
  app.render();
}

async function applyFirewall(request, okText) {
  if (fwWorking) return false;
  fwWorking = true;
  app.render();
  let ok = false;
  try {
    const answer = await invoke('firewall_apply', { request });
    fwHistory = (answer && answer.history) || fwHistory;
    flash(okText);
    ok = true;
  } catch (e) {
    flash(errorText(e), 'warn');
  }
  fwWorking = false;
  await loadRules();
  return ok;
}

async function configureWatch() {
  const on = isEnabled(securityModule) && !!store.get().security.newProgramAlert;
  try {
    watch = (await invoke('netwatch_configure', { enabled: on, title: t('fw.alertToastTitle'), body: t('fw.alertToastBody') })) || watch;
  } catch (e) {
    log('warn', e);
  }
}

async function pollWatch() {
  lastWatchPoll = Date.now();
  try {
    watch = (await invoke('netwatch_status')) || watch;
  } catch (e) {
    log('warn', e);
  }
}

const directionText = (direction) => t(direction === 'Inbound' ? 'fw.dirIn' : 'fw.dirOut');

function alertCard() {
  const s = store.get();
  const pending = watch.pending || [];
  const list = pending.length
    ? pending
        .map(
          (p) => `<div class="finding sev-medium">
            <div class="finding-head"><span class="sev">${esc(t('fw.alertNew'))}</span><h3>${esc(p.name)}</h3></div>
            <p class="mono">${esc(p.path)}</p>
            <p class="fine">${esc(t('fw.alertSeen'))}: ${esc(fmtWhen(p.firstSeen))}</p>
            <div class="finding-actions">
              <button type="button" class="btn" data-action="fwAllowNew" data-path="${esc(p.path)}">${esc(t('fw.alertAllow'))}</button>
              <button type="button" class="btn danger" data-action="fwBlockNew" data-path="${esc(p.path)}" ${fwWorking ? 'disabled' : ''}>${esc(t('fw.alertBlock'))}</button>
            </div>
          </div>`,
        )
        .join('')
    : s.security.newProgramAlert
      ? `<p class="fine">${esc(t(watch.learning ? 'fw.alertLearning' : 'fw.alertNone', { n: num(watch.known || 0) }))}</p>`
      : '';
  return card(
    t('fw.alertTitle'),
    `${row(t('fw.alertToggle'), toggle('security.newProgramAlert', s.security.newProgramAlert), t('fw.alertHint'))}${list}`,
  );
}

function ruleRow(rule, mine) {
  const stateText = t(rule.enabled ? 'fw.on' : 'fw.off');
  const actionCell = mine
    ? `<button type="button" class="btn small danger" data-action="fwRemove" data-id="${esc(rule.id)}" data-name="${esc(rule.name)}" ${fwWorking ? 'disabled' : ''}>${esc(t('fw.remove'))}</button>`
    : `<button type="button" class="btn small" data-action="fwToggle" data-id="${esc(rule.id)}" data-name="${esc(rule.name)}" data-enabled="${rule.enabled ? '1' : '0'}" ${fwWorking ? 'disabled' : ''}>${esc(t(rule.enabled ? 'fw.turnOff' : 'fw.turnOn'))}</button>`;
  return `<tr>
    <td>${esc(rule.name)}</td>
    <td class="mono" title="${esc(rule.program)}">${esc(baseName(rule.program))}</td>
    <td>${esc(directionText(rule.direction))}</td>
    <td>${esc(t(rule.action === 'Block' ? 'fw.block' : 'fw.allow'))}</td>
    <td>${esc(stateText)}</td>
    <td>${actionCell}</td>
  </tr>`;
}

const ruleTable = (list, mine) => `<table class="times log-table">
  <thead><tr><th scope="col">${esc(t('fw.colName'))}</th><th scope="col">${esc(t('fw.colProgram'))}</th><th scope="col">${esc(t('fw.colDir'))}</th><th scope="col">${esc(t('fw.colAction'))}</th><th scope="col">${esc(t('fw.colState'))}</th><th scope="col"></th></tr></thead>
  <tbody>${list.map((r) => ruleRow(r, mine)).join('')}</tbody>
</table>`;

function historyCard() {
  if (!fwHistory.length) return card(t('fw.historyTitle'), `<p class="fine">${esc(t('fw.historyEmpty'))}</p>`);
  const rows = [...fwHistory]
    .reverse()
    .slice(0, 40)
    .map((entry) => {
      const state = entry.undone
        ? `<span class="fine">${esc(t('insp.historyUndone'))}</span>`
        : `<button type="button" class="btn small" data-action="fwUndo" data-entry="${esc(entry.entryId)}" ${fwWorking ? 'disabled' : ''}>${esc(t('insp.undoBtn'))}</button>`;
      return `<tr><td>${esc(t(`fw.kind.${entry.kind}`))}</td><td>${esc(entry.label || '')}</td><td>${esc(fmtWhen(entry.at))}</td><td>${state}</td></tr>`;
    })
    .join('');
  return card(
    t('fw.historyTitle'),
    `<table class="times log-table"><thead><tr><th scope="col">${esc(t('fw.colChange'))}</th><th scope="col">${esc(t('fw.colName'))}</th><th scope="col">${esc(t('insp.historyWhen'))}</th><th scope="col"></th></tr></thead><tbody>${rows}</tbody></table>`,
  );
}

function renderFirewall() {
  const all = rules || [];
  const mine = all.filter((r) => r.ours);
  const needle = fwFilter.trim().toLowerCase();
  const others = all.filter((r) => !r.ours && (!needle || `${r.name} ${r.program}`.toLowerCase().includes(needle)));

  const loadingNote = fwLoading ? notice(t('fw.loading')) : '';
  return `
    ${notice(t('fw.intro'))}
    ${alertCard()}
    ${card(
      t('fw.blockTitle'),
      row(t('fw.blockLabel'), `<button type="button" class="btn primary" data-action="fwPickProgram" ${fwWorking ? 'disabled' : ''}>${esc(t('fw.blockBtn'))}</button>`, t('fw.blockHint')),
    )}
    ${loadingNote}
    ${fwError ? notice(fwError, 'warn') : ''}
    ${card(t('fw.mineTitle'), mine.length ? ruleTable(mine, true) : `<p class="fine">${esc(t('fw.mineEmpty'))}</p>`)}
    ${card(
      t('fw.othersTitle', { n: num(all.length - mine.length) }),
      `<p class="fine">${esc(t('fw.othersHint'))}</p>
       <div class="filter-line">
         <input type="text" class="text" data-onchange="fwFilter" value="${esc(fwFilter)}" placeholder="${esc(t('fw.filterPlaceholder'))}" aria-label="${esc(t('fw.filterPlaceholder'))}">
         ${button('fwRefresh', t('fw.refresh'))}
       </div>
       ${others.length ? ruleTable(others.slice(0, 100), false) : `<p class="fine">${esc(t('fw.othersEmpty'))}</p>`}
       ${others.length > 100 ? `<p class="fine">${esc(t('fw.othersMore', { n: num(others.length - 100) }))}</p>` : ''}`,
    )}
    ${historyCard()}`;
}

function tickFirewall() {
  if (rules === null && !fwLoading) {
    loadRules();
    return;
  }
  if (store.get().security.newProgramAlert && Date.now() - lastWatchPoll > 5000) {
    const before = (watch.pending || []).length;
    pollWatch().then(() => {
      if ((watch.pending || []).length !== before) app.render();
    });
  }
}

// ================================================================ cleaner

async function scanCleaner() {
  if (cleanLoading) return;
  cleanLoading = true;
  cleanError = '';
  app.render();
  try {
    cleanData = await invoke('cleaner_scan');
    // Forget ticks for things that no longer exist.
    const valid = new Set();
    for (const browser of (cleanData && cleanData.browsers) || []) {
      for (const profile of browser.profiles || []) {
        for (const item of profile.items || []) valid.add(`${browser.id}|${profile.name}|${item.kind}`);
      }
    }
    for (const key of [...cleanSelected]) if (!valid.has(key)) cleanSelected.delete(key);
  } catch (e) {
    log('error', e);
    cleanError = String(e && e.message ? e.message : e).slice(0, 300);
  }
  cleanLoading = false;
  app.render();
}

function selectedBytes() {
  let total = 0;
  for (const browser of (cleanData && cleanData.browsers) || []) {
    for (const profile of browser.profiles || []) {
      for (const item of profile.items || []) {
        if (cleanSelected.has(`${browser.id}|${profile.name}|${item.kind}`)) total += Number(item.bytes) || 0;
      }
    }
  }
  return total;
}

function browserCard(browser) {
  const kinds = [...new Set((browser.profiles || []).flatMap((p) => (p.items || []).map((i) => i.kind)))];
  const head = kinds.map((kind) => `<th scope="col">${esc(t(`clean.kind.${kind}`))}</th>`).join('');
  const rows = (browser.profiles || [])
    .map((profile) => {
      const cells = kinds
        .map((kind) => {
          const item = (profile.items || []).find((i) => i.kind === kind);
          if (!item) return '<td>—</td>';
          const key = `${browser.id}|${profile.name}|${kind}`;
          const label = `${browser.name}, ${profile.name}, ${t(`clean.kind.${kind}`)}`;
          return `<td><label class="check"><input type="checkbox" data-action="cleanToggle" data-key="${esc(key)}" aria-label="${esc(label)}" ${cleanSelected.has(key) ? 'checked' : ''} ${browser.running ? 'disabled' : ''}> ${esc(fmtBytes(item.bytes))}</label></td>`;
        })
        .join('');
      return `<tr><th scope="row">${esc(profile.name)}</th>${cells}</tr>`;
    })
    .join('');
  return card(
    browser.name,
    `${browser.running ? notice(t('clean.running', { name: browser.name }), 'warn') : ''}
     <table class="times log-table"><thead><tr><th scope="col">${esc(t('clean.colProfile'))}</th>${head}</tr></thead><tbody>${rows}</tbody></table>
     ${browser.id === 'firefox' ? `<p class="fine">${esc(t('clean.firefoxNote'))}</p>` : ''}`,
  );
}

function resultsCard() {
  if (!cleanResults) return '';
  const rows = (cleanResults.results || [])
    .map((r) => {
      const state = r.ok ? `${t('clean.done')} (${fmtBytes(r.freed)})` : t(r.message === 'running' ? 'clean.msg.running' : 'clean.msg.failed');
      return `<tr><td>${esc(r.browser)}</td><td>${esc(r.profile)}</td><td>${esc(t(`clean.kind.${r.kind}`))}</td><td>${esc(state)}</td></tr>`;
    })
    .join('');
  const clip = cleanResults.clipboard && cleanResults.clipboard.requested
    ? `<p>${esc(t(cleanResults.clipboard.cleared ? 'clean.clipDone' : 'clean.clipFailed'))}</p>`
    : '';
  return card(
    t('clean.resultTitle'),
    `${clip}${rows ? `<table class="times log-table"><tbody>${rows}</tbody></table>` : ''}`,
  );
}

function renderCleaner() {
  const browsers = (cleanData && cleanData.browsers) || [];
  const count = cleanSelected.size + (cleanClipboard ? 1 : 0);
  const busy = cleanWorking || cleanLoading;

  return `
    ${notice(t('clean.warning'), 'warn')}
    <section class="card">
      <div class="blocker-head">
        <div>
          <div class="blocker-state">${esc(t('clean.title'))}</div>
          <div class="row-hint">${esc(t(cleanData ? 'clean.scanned' : 'clean.notScanned'))}</div>
        </div>
        <div class="blocker-controls"><button type="button" class="btn primary big" data-action="cleanScan" ${busy ? 'disabled' : ''}>${esc(t(cleanLoading ? 'clean.scanning' : cleanData ? 'clean.scanAgain' : 'clean.scanBtn'))}</button></div>
      </div>
    </section>
    ${cleanError ? notice(`${t('clean.scanFailed')} ${cleanError}`, 'warn') : ''}
    ${resultsCard()}
    ${cleanData && !browsers.length ? notice(t('clean.noBrowsers')) : ''}
    ${browsers.map(browserCard).join('')}
    ${card(
      t('clean.clipTitle'),
      `<label class="check"><input type="checkbox" data-action="cleanClipToggle" ${cleanClipboard ? 'checked' : ''}> ${esc(t('clean.clipLabel'))}</label>
       <p class="fine">${esc(t('clean.clipHint'))}</p>`,
    )}
    <section class="card">
      <div class="blocker-head">
        <div>
          <div class="row-label">${esc(t('clean.selected', { n: num(count), size: fmtBytes(selectedBytes()) }))}</div>
          <div class="row-hint">${esc(t('clean.selectedHint'))}</div>
        </div>
        <div class="blocker-controls"><button type="button" class="btn danger big" data-action="cleanApply" ${busy || !count ? 'disabled' : ''}>${esc(t(cleanWorking ? 'clean.working' : 'clean.applyBtn'))}</button></div>
      </div>
    </section>`;
}

// ================================================================ module

const securityModule = {
  id: 'security',
  titleKey: 'module.security',
  canDisable: true,

  pages: [
    { id: 'firewall', icon: '🧱', titleKey: 'nav.firewall', render: renderFirewall, tick: tickFirewall },
    { id: 'cleaner', icon: '🧹', titleKey: 'nav.cleaner', render: renderCleaner },
  ],

  actions: {
    // ---- firewall
    fwRefresh() {
      return loadRules();
    },
    fwFilter(el) {
      fwFilter = String(el.value || '').slice(0, 80);
      app.render();
    },
    async fwPickProgram() {
      const path = await pickFile(t('fw.programFiles'), ['exe']);
      if (!path) return;
      const name = baseName(path);
      if (!window.confirm(t('fw.confirmBlock', { name }))) return;
      await applyFirewall({ action: 'add', program: path, label: name, direction: 'out' }, t('fw.blocked', { name }));
    },
    async fwRemove(el) {
      const name = el.dataset.name || '';
      if (!window.confirm(t('fw.confirmRemove', { name }))) return;
      await applyFirewall({ action: 'remove', ids: [el.dataset.id], label: name }, t('fw.removed'));
    },
    async fwToggle(el) {
      const name = el.dataset.name || '';
      const turnOn = el.dataset.enabled !== '1';
      if (!window.confirm(t(turnOn ? 'fw.confirmOn' : 'fw.confirmOff', { name }))) return;
      await applyFirewall({ action: 'enable', items: [{ id: el.dataset.id, enabled: turnOn }], label: name }, t('fw.changed'));
    },
    async fwUndo(el) {
      if (fwWorking || !window.confirm(t('fw.confirmUndo'))) return;
      fwWorking = true;
      app.render();
      try {
        const answer = await invoke('firewall_undo', { entryId: el.dataset.entry });
        fwHistory = (answer && answer.history) || fwHistory;
        flash(t('insp.undone'));
      } catch (e) {
        flash(errorText(e), 'warn');
      }
      fwWorking = false;
      await loadRules();
    },
    async fwAllowNew(el) {
      try {
        watch = (await invoke('netwatch_decide', { path: el.dataset.path })) || watch;
      } catch (e) {
        log('warn', e);
      }
      app.render();
    },
    async fwBlockNew(el) {
      const path = el.dataset.path;
      const name = baseName(path);
      if (!window.confirm(t('fw.confirmBlock', { name }))) return;
      const ok = await applyFirewall({ action: 'add', program: path, label: name, direction: 'out' }, t('fw.blocked', { name }));
      if (!ok) return;
      try {
        watch = (await invoke('netwatch_decide', { path })) || watch;
      } catch (e) {
        log('warn', e);
      }
      app.render();
    },

    // ---- cleaner
    cleanScan() {
      cleanResults = null;
      return scanCleaner();
    },
    cleanToggle(el) {
      if (el.checked) cleanSelected.add(el.dataset.key);
      else cleanSelected.delete(el.dataset.key);
      app.render();
    },
    cleanClipToggle(el) {
      cleanClipboard = !!el.checked;
      app.render();
    },
    async cleanApply() {
      const count = cleanSelected.size + (cleanClipboard ? 1 : 0);
      if (!count || cleanWorking) return;
      if (!window.confirm(t('clean.confirm', { n: num(count), size: fmtBytes(selectedBytes()) }))) return;
      cleanWorking = true;
      app.render();
      const targets = [...cleanSelected].map((key) => {
        const [browser, profile, kind] = key.split('|');
        return { browser, profile, kind };
      });
      try {
        cleanResults = await invoke('cleaner_apply', { targets, clipboard: cleanClipboard });
        cleanSelected.clear();
        cleanClipboard = false;
        flash(t('clean.finished'));
      } catch (e) {
        log('error', e);
        flash(`${t('clean.scanFailed')} ${String(e && e.message ? e.message : e).slice(0, 200)}`, 'warn');
      }
      cleanWorking = false;
      await scanCleaner();
    },
  },

  async init(appContext) {
    app = appContext;
    try {
      fwHistory = (await invoke('firewall_history')) || [];
    } catch (e) {
      log('warn', e);
    }
    await configureWatch();
    await listen('netwatch-new', async (entry) => {
      await pollWatch();
      flash(t('fw.alertFlash', { name: (entry && entry.name) || '' }), 'warn');
      app.render();
    });
  },

  onSettingsChanged(path) {
    if (path === '*' || path === 'security.newProgramAlert' || path === 'general.language' || path === 'modules.security') {
      configureWatch().then(() => app.render());
    }
  },
};

export default securityModule;
