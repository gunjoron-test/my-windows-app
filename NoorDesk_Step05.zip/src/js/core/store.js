// Settings: one JSON document saved by the backend.
// Every module owns one top-level section, so later modules only add a section here.

import { invoke, log } from './bridge.js';
import { clone, deepMerge, getPath, setPath } from './util.js';

export const SCHEMA_VERSION = 1;

export const DEFAULTS = {
  schemaVersion: SCHEMA_VERSION,
  onboarded: false,

  general: {
    language: 'bn', // 'bn' | 'en'
    theme: 'system', // 'system' | 'light' | 'dark'
    timeFormat: '12h', // '12h' | '24h'
    startWithWindows: false,
  },

  // Module on/off switches. A module that is not listed counts as "on".
  modules: {
    prayer: true,
    widgets: true,
    blocker: true,
    inspector: true,
    security: true,
  },

  // Extra privacy and security tools (Step 5).
  security: {
    newProgramAlert: false, // tell me when a never-seen program uses the network
  },

  // Ad and tracker blocker (Step 3). Whether it is on or off is kept by the backend,
  // because that state must match the Windows network setting.
  blocker: {
    sources: {
      stevenblack: true, adguard: true, easylist: false, easyprivacy: false,
      // optional categories (Step 5)
      malware: false, phishing: false, adult: false, gambling: false,
    },
    doh: 'off', // encrypted DNS: 'off' | 'cloudflare' | 'quad9' | 'google'
    customSources: '', // one https address per line
    allowList: '', // one name per line
    blockList: '', // one name per line
    updateDays: 3, // 0 = never update automatically
    fallback: 'cloudflare', // 'cloudflare' | 'quad9' | 'google'
  },

  // Desktop widgets (Step 2). Window position and size are kept separately by the backend.
  widgets: {
    prayer: { enabled: false, style: 'green', opacity: 100, mode: 'normal', locked: false },
    clock: { enabled: false, style: 'green', opacity: 100, mode: 'normal', locked: false },
    next: { enabled: false, style: 'green', opacity: 100, mode: 'normal', locked: false },
  },

  location: {
    mode: 'city', // 'city' | 'manual'
    cityId: 'dhaka',
    name: '',
    lat: 23.8103,
    lng: 90.4125,
  },

  prayer: {
    method: 'karachi',
    asr: 'hanafi', // 'hanafi' | 'shafi'
    adjust: { fajr: 0, sunrise: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 },
    hijriAdjust: 0,
  },

  alarms: {
    enabled: true,
    waqt: {
      fajr: { enabled: true, pre: 0 },
      dhuhr: { enabled: true, pre: 0 },
      asr: { enabled: true, pre: 0 },
      maghrib: { enabled: true, pre: 0 },
      isha: { enabled: true, pre: 0 },
    },
    sound: 'chime', // 'chime' | 'bell' | 'beep' | 'custom'
    customPath: '',
    volume: 80,
    snoozeMinutes: 5,
    wakeFromSleep: false,
  },

  ramadan: {
    mode: 'auto', // 'auto' | 'on' | 'off'
    sehriAlarm: true,
    sehriBefore: 30,
    iftarAlarm: true,
  },
};

let settings = clone(DEFAULTS);
let saveTimer = null;
const listeners = new Set();

function migrate(data) {
  // Future schema changes are handled here, one version at a time.
  data.schemaVersion = SCHEMA_VERSION;
  return data;
}

export async function load() {
  let saved = null;
  try {
    saved = await invoke('load_settings');
  } catch (e) {
    log('error', e);
  }
  settings = migrate(deepMerge(clone(DEFAULTS), saved || {}));
  return settings;
}

export const get = () => settings;

export const read = (path) => getPath(settings, path);

function persist() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    invoke('save_settings', { settings }).catch((e) => log('error', e));
  }, 250);
}

/** Changes one value, saves, and tells everyone who subscribed. */
export function set(path, value) {
  setPath(settings, path, value);
  persist();
  for (const fn of listeners) {
    try {
      fn(path, value);
    } catch (e) {
      log('error', e);
    }
  }
}

export async function reset() {
  settings = clone(DEFAULTS);
  persist();
  for (const fn of listeners) fn('*', null);
}

export function subscribe(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}
