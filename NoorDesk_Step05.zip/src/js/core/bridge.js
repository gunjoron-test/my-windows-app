// The only place that talks to the Rust backend.
// When the page is opened in a normal browser (design preview), a small stand-in is used.

const T = window.__TAURI__ || null;

export const isTauri = !!T;

const PREVIEW_KEY = 'noordesk.preview.settings';

async function previewInvoke(cmd, args) {
  switch (cmd) {
    case 'load_settings':
      try {
        return JSON.parse(localStorage.getItem(PREVIEW_KEY) || 'null');
      } catch {
        return null;
      }
    case 'save_settings':
      localStorage.setItem(PREVIEW_KEY, JSON.stringify(args.settings));
      return null;
    case 'get_alarm_state':
      return { active: null, missed: [], pending: 0, nextAt: null };
    case 'app_info':
      return { version: 'preview', dataDir: '', logFile: '', uncleanPreviousExit: false };
    case 'set_schedule':
      return args.items.length;
    case 'get_autostart':
      return false;
    case 'set_autostart':
      return args.enabled;
    case 'blocker_status':
    case 'blocker_configure':
    case 'blocker_pause':
    case 'blocker_clear_log':
      return {
        active: false, paused: false, running: false, busy: false, v6: false, dnsChanged: false,
        total: 1284, today: 57, forwarded: 0, ruleCount: 0, listCounts: {}, lastUpdate: 0,
        upstreams: [], lastError: '',
        recent: [{ at: Date.now(), domain: 'ads.example.com', count: 3 }],
      };
    case 'blocker_enable':
    case 'blocker_disable':
    case 'blocker_repair':
    case 'blocker_update':
      throw new Error('Not available in preview');
    case 'inspector_scan':
      // Preview only: an optional sample file next to index.html.
      return { ...(await (await fetch('_scan-sample.json')).json()), scannedAt: Date.now() };
    case 'inspector_history':
      return [];
    case 'blocker_check':
      return args.names.map(() => false);
    case 'firewall_list':
      return { ok: true, rules: [
        { id: 'r1', name: 'NoorDesk: sample.exe (Outbound)', program: 'C:\\Program Files\\Sample\\sample.exe', direction: 'Outbound', action: 'Block', enabled: true, group: 'NoorDesk', ours: true },
        { id: 'r2', name: 'Sample Browser', program: 'C:\\Program Files\\Browser\\browser.exe', direction: 'Inbound', action: 'Allow', enabled: true, group: '', ours: false },
        { id: 'r3', name: 'Sample Game', program: '%ProgramFiles%\\Game\\game.exe', direction: 'Outbound', action: 'Allow', enabled: false, group: '', ours: false },
      ] };
    case 'firewall_history':
      return [];
    case 'netwatch_configure':
    case 'netwatch_status':
    case 'netwatch_decide':
      return { enabled: true, learning: false, known: 42, pending: [{ path: 'c:\\users\\me\\downloads\\newtool.exe', name: 'newtool.exe', firstSeen: Date.now() }] };
    case 'cleaner_scan':
      return { ok: true, browsers: [
        { id: 'chrome', name: 'Google Chrome', running: false, profiles: [{ name: 'Default', items: [{ kind: 'cookies', bytes: 1500000 }, { kind: 'history', bytes: 34000000 }, { kind: 'cache', bytes: 755000000 }] }] },
        { id: 'firefox', name: 'Mozilla Firefox', running: true, profiles: [{ name: 'abcd.default-release', items: [{ kind: 'cookies', bytes: 900000 }, { kind: 'cache', bytes: 1426000000 }] }] },
      ] };
    case 'firewall_apply':
    case 'firewall_undo':
    case 'cleaner_apply':
      throw new Error('Not available in preview');
    case 'read_audio_file':
      throw new Error('Not available in preview');
    default:
      return null;
  }
}

export function invoke(cmd, args = {}) {
  return T ? T.core.invoke(cmd, args) : previewInvoke(cmd, args);
}

/** Listens to an event from the backend. The callback receives the payload. */
export async function listen(eventName, callback) {
  if (!T) return () => {};
  return T.event.listen(eventName, (event) => callback(event.payload));
}

/** Sends an event to every window of the app (used by widgets to talk to the main window). */
export async function emit(eventName, payload) {
  if (!T) return;
  await T.event.emit(eventName, payload);
}

function currentWindow() {
  if (!T || !T.window || !T.window.getCurrentWindow) return null;
  try {
    return T.window.getCurrentWindow();
  } catch {
    return null;
  }
}

/** Label of the window this page runs in ("main", "widget-prayer", ...), or null in a browser. */
export function currentWindowLabel() {
  const win = currentWindow();
  if (win && win.label) return win.label;
  try {
    return window.__TAURI_INTERNALS__.metadata.currentWindow.label;
  } catch {
    return null;
  }
}

/** Lets the user drag this (frameless) window with the mouse. */
export function startDragging() {
  const win = currentWindow();
  if (win) win.startDragging().catch(() => {});
}

/** Lets the user resize this (frameless) window from its bottom-right corner. */
export function startResizing() {
  const win = currentWindow();
  if (win) win.startResizeDragging('SouthEast').catch(() => {});
}

/** Opens the Windows "Open file" dialog. Returns the chosen path or null. */
export async function pickFile(name, extensions) {
  if (!T || !T.dialog) return null;
  const result = await T.dialog.open({
    multiple: false,
    directory: false,
    filters: [{ name, extensions }],
  });
  return typeof result === 'string' ? result : null;
}

/** Opens the Windows "Save as" dialog. Returns the chosen path or null. */
export async function pickSavePath(defaultName, name, extensions) {
  if (!T || !T.dialog) return null;
  const result = await T.dialog.save({ defaultPath: defaultName, filters: [{ name, extensions }] });
  return typeof result === 'string' ? result : null;
}

export function log(level, message) {
  const text = message instanceof Error ? `${message.message} ${message.stack || ''}` : String(message);
  if (level === 'error') console.error(text);
  invoke('write_log', { level, message: text }).catch(() => {});
}
