//! Taskbar meters: live CPU / RAM / GPU on the Windows taskbar, in two ways the user can switch on:
//!
//! * **Tray numbers** — one small icon per value in the notification area (next to the clock),
//!   drawn here as a number on a coloured tile that fills up with the load. Hovering shows the
//!   details; a click opens the System monitor page.
//! * **Taskbar strip** — a small transparent window (`widget.html`, label `meter-taskbar`) that is
//!   placed ON the taskbar, just left of the notification area, like TrafficMonitor. It keeps
//!   itself above the taskbar, hides while a full-screen program (game, video) runs or while an
//!   auto-hidden taskbar is hidden, and is not placed on a vertical taskbar.
//!
//! The interface sends the settings with `taskbar_configure`; a background thread does the rest.
//! Measurements come from `systools::current()`, shared with the monitor page and widgets.

use std::sync::Mutex;
use std::thread;
use std::time::Duration;

use serde::Deserialize;
use serde_json::Value;
use tauri::image::Image;
use tauri::tray::{MouseButton, MouseButtonState, TrayIconBuilder, TrayIconEvent};
use tauri::{AppHandle, Emitter, Manager, WebviewUrl, WebviewWindowBuilder};

use crate::{logging, systools, tray};

pub const STRIP_LABEL: &str = "meter-taskbar";

#[derive(Clone, Debug, Deserialize, PartialEq)]
#[serde(default, rename_all = "camelCase")]
pub struct Config {
    /// Tray numbers on/off, and which values get one.
    pub icons: bool,
    pub cpu: bool,
    pub ram: bool,
    pub gpu: bool,
    /// The strip on the taskbar on/off.
    pub strip: bool,
    /// Width of the strip in logical pixels (the interface knows its content).
    pub width: f64,
    /// Seconds between two updates of the tray numbers.
    pub interval: u64,
}

impl Default for Config {
    fn default() -> Self {
        Config { icons: false, cpu: true, ram: true, gpu: true, strip: false, width: 240.0, interval: 2 }
    }
}

static CONFIG: Mutex<Option<Config>> = Mutex::new(None);

struct Meter {
    id: &'static str,
    label: &'static str,
    color: [u8; 3],
}

static METERS: [Meter; 3] = [
    Meter { id: "meter-cpu", label: "CPU", color: [0x41, 0x69, 0xE1] },
    Meter { id: "meter-ram", label: "RAM", color: [0xA8, 0x74, 0x24] },
    Meter { id: "meter-gpu", label: "GPU", color: [0x1F, 0x8A, 0x5B] },
];

const WARN_COLOR: [u8; 3] = [0xD9, 0x36, 0x3E];

/// Settings from the interface (called at start and whenever they change).
#[tauri::command]
pub fn taskbar_configure(config: Config) {
    let mut config = config;
    config.interval = config.interval.clamp(1, 10);
    if !config.width.is_finite() {
        config.width = 240.0;
    }
    config.width = config.width.clamp(60.0, 640.0);
    *CONFIG.lock().unwrap_or_else(|e| e.into_inner()) = Some(config);
}

/// "light" or "dark": the colour of the Windows taskbar (not of apps), for the strip's text.
#[tauri::command]
pub fn taskbar_theme() -> String {
    #[cfg(windows)]
    {
        use winreg::enums::HKEY_CURRENT_USER;
        let light = winreg::RegKey::predef(HKEY_CURRENT_USER)
            .open_subkey("Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize")
            .and_then(|key| key.get_value::<u32, _>("SystemUsesLightTheme"))
            .unwrap_or(0);
        if light != 0 {
            return "light".into();
        }
    }
    "dark".into()
}

pub fn start(app: &AppHandle) {
    let app = app.clone();
    thread::spawn(move || {
        let mut tick: u64 = 0;
        let mut icons_on = [false; 3];
        let mut strip_open = false;
        loop {
            thread::sleep(Duration::from_millis(500));
            tick = tick.wrapping_add(1);
            let config = CONFIG.lock().unwrap_or_else(|e| e.into_inner()).clone();
            let Some(config) = config else { continue };

            // ---- tray numbers
            let wanted = [config.icons && config.cpu, config.icons && config.ram, config.icons && config.gpu];
            let any = wanted.iter().any(|w| *w);
            let due = tick % (config.interval * 2) == 0;
            if wanted != icons_on || (due && any) {
                let sample = if any { Some(systools::current()) } else { None };
                update_icons(&app, wanted, sample);
                icons_on = wanted;
            }

            // ---- strip on the taskbar
            if config.strip != strip_open {
                if config.strip {
                    strip_open = open_strip(&app);
                } else {
                    if let Some(window) = app.get_webview_window(STRIP_LABEL) {
                        let _ = window.destroy();
                    }
                    strip_open = false;
                }
            }
            if strip_open {
                if app.get_webview_window(STRIP_LABEL).is_none() {
                    strip_open = false; // closed from outside; opened again on the next round
                } else {
                    dock(&app, &config);
                }
            }
        }
    });
}

fn open_strip(app: &AppHandle) -> bool {
    if app.get_webview_window(STRIP_LABEL).is_some() {
        return true;
    }
    match WebviewWindowBuilder::new(app, STRIP_LABEL, WebviewUrl::App("widget.html".into()))
        .title("Patheyo Taskbar Meter")
        .inner_size(240.0, 40.0)
        .decorations(false)
        .transparent(true)
        .shadow(false)
        .skip_taskbar(true)
        .resizable(false)
        .maximizable(false)
        .minimizable(false)
        .always_on_top(true)
        .focused(false)
        .visible(false)
        .build()
    {
        Ok(_) => {
            logging::write("INFO", "Taskbar strip opened");
            true
        }
        Err(e) => {
            logging::write("WARN", &format!("Taskbar strip could not be opened: {}", e));
            false
        }
    }
}

/// Click on a tray number or on the strip: show the System monitor page.
pub fn open_monitor(app: &AppHandle) {
    tray::show_main_window(app);
    let _ = app.emit("open-page", "monitor");
}

/// Opens the monitor page; called by the strip window when it is clicked.
#[tauri::command]
pub fn taskbar_open_monitor(app: AppHandle) {
    open_monitor(&app);
}

// ================================================================ tray numbers

fn gb(bytes: f64) -> String {
    format!("{:.1} GB", bytes / 1_073_741_824.0)
}

/// Value (0–100) and tooltip text of one meter.
fn reading(index: usize, sample: Option<&Value>) -> (Option<f64>, String) {
    let meter = &METERS[index];
    let value = sample.and_then(|s| match index {
        0 => s["cpu"].as_f64(),
        1 => s["memory"]["percent"].as_f64(),
        _ => s["gpu"]["percent"].as_f64(),
    });
    let mut tip = match value {
        Some(v) => format!("{} {:.0}%", meter.label, v),
        None => format!("{} —", meter.label),
    };
    if let Some(s) = sample {
        if index == 1 {
            if let (Some(used), Some(total)) = (s["memory"]["used"].as_f64(), s["memory"]["total"].as_f64()) {
                tip.push_str(&format!(" · {} / {}", gb(used), gb(total)));
            }
        }
        if index == 2 {
            if let Some(memory) = s["gpu"]["memory"].as_f64() {
                tip.push_str(&format!(" · VRAM {}", gb(memory)));
            }
            if value.is_none() {
                tip.push_str(" (not available on this PC)");
            }
        }
    }
    tip.push_str(" — Patheyo");
    (value, tip)
}

fn update_icons(app: &AppHandle, wanted: [bool; 3], sample: Option<Value>) {
    let size = icon_size();
    let handle = app.clone();
    let result = app.run_on_main_thread(move || {
        for (index, meter) in METERS.iter().enumerate() {
            if !wanted[index] {
                if let Some(icon) = handle.remove_tray_by_id(meter.id) {
                    let _ = icon.set_visible(false);
                }
                continue;
            }
            let (value, tip) = reading(index, sample.as_ref());
            let image = Image::new_owned(render(value, meter.color, size), size, size);
            match handle.tray_by_id(meter.id) {
                Some(icon) => {
                    let _ = icon.set_icon(Some(image));
                    let _ = icon.set_tooltip(Some(tip));
                }
                None => {
                    let built = TrayIconBuilder::with_id(meter.id)
                        .icon(image)
                        .tooltip(tip)
                        .show_menu_on_left_click(false)
                        .on_tray_icon_event(|tray, event| {
                            if let TrayIconEvent::Click {
                                button: MouseButton::Left,
                                button_state: MouseButtonState::Up,
                                ..
                            } = event
                            {
                                open_monitor(tray.app_handle());
                            }
                        })
                        .build(&handle);
                    if let Err(e) = built {
                        logging::write("WARN", &format!("Tray meter {}: {}", meter.id, e));
                    }
                }
            }
        }
    });
    if let Err(e) = result {
        logging::write("WARN", &format!("Tray meters: {}", e));
    }
}

/// 5×7 pixel digits (each row: 5 bits, left bit first); index 10 is a dash.
const GLYPHS: [[u8; 7]; 11] = [
    [0x0E, 0x11, 0x11, 0x11, 0x11, 0x11, 0x0E],
    [0x04, 0x0C, 0x04, 0x04, 0x04, 0x04, 0x0E],
    [0x0E, 0x11, 0x01, 0x02, 0x04, 0x08, 0x1F],
    [0x1F, 0x02, 0x04, 0x02, 0x01, 0x11, 0x0E],
    [0x02, 0x06, 0x0A, 0x12, 0x1F, 0x02, 0x02],
    [0x1F, 0x10, 0x1E, 0x01, 0x01, 0x11, 0x0E],
    [0x06, 0x08, 0x10, 0x1E, 0x11, 0x11, 0x0E],
    [0x1F, 0x01, 0x02, 0x04, 0x08, 0x08, 0x08],
    [0x0E, 0x11, 0x11, 0x0E, 0x11, 0x11, 0x0E],
    [0x0E, 0x11, 0x11, 0x0F, 0x01, 0x02, 0x0C],
    [0x00, 0x00, 0x00, 0x1F, 0x00, 0x00, 0x00],
];

/// Draws one tray number as RGBA pixels (size × size), anti-aliased by 4×4 supersampling.
/// Digits are drawn a little bold (each stroke widened to the right) to stay readable at 16 px.
/// The tile is dark-tinted in the meter colour and fills up from the bottom with the load.
fn render(value: Option<f64>, color: [u8; 3], size: u32) -> Vec<u8> {
    const D: f64 = 64.0; // design space
    let percent = value.map(|v| v.clamp(0.0, 100.0));
    let text: Vec<usize> = match percent {
        Some(p) => (p.round() as u32).to_string().bytes().map(|b| b.saturating_sub(b'0').min(9) as usize).collect(),
        None => vec![10],
    };
    let fill_color = if percent.unwrap_or(0.0) >= 90.0 { WARN_COLOR } else { color };
    let dark = [0x0F_u8, 0x17, 0x2A];
    let base: [f64; 3] = [0usize, 1, 2].map(|i| color[i] as f64 * 0.30 + dark[i] as f64 * 0.70);
    let fill_top = D - D * percent.unwrap_or(0.0) / 100.0;

    // digit layout
    let count = text.len() as f64;
    let (cell, gap) = if text.len() >= 3 { (3.9, 2.4) } else { (5.6, 3.2) };
    let char_w = 5.0 * cell;
    let total_w = count * char_w + (count - 1.0) * gap;
    let x0 = (D - total_w) / 2.0;
    let y0 = (D - 7.0 * cell) / 2.0;

    let radius = 14.0;
    let inside = |x: f64, y: f64| -> bool {
        let cx = x.clamp(radius, D - radius);
        let cy = y.clamp(radius, D - radius);
        let (dx, dy) = (x - cx, y - cy);
        dx * dx + dy * dy <= radius * radius
    };
    let on_digit = |x: f64, y: f64| -> bool {
        if y < y0 || y >= y0 + 7.0 * cell || x < x0 || x >= x0 + total_w {
            return false;
        }
        let rel = x - x0;
        let slot = (rel / (char_w + gap)).floor();
        let within = rel - slot * (char_w + gap);
        if within >= char_w || slot < 0.0 || slot as usize >= text.len() {
            return false;
        }
        let col = (within / cell).floor() as usize;
        let row = ((y - y0) / cell).floor() as usize;
        if col > 4 || row > 6 {
            return false;
        }
        GLYPHS[text[slot as usize]][row] & (0x10 >> col) != 0
    };

    let n = size as usize;
    let mut out = vec![0u8; n * n * 4];
    const SS: usize = 4;
    for py in 0..n {
        for px in 0..n {
            let (mut r, mut g, mut b, mut a) = (0.0, 0.0, 0.0, 0.0);
            for sy in 0..SS {
                for sx in 0..SS {
                    let x = (px as f64 + (sx as f64 + 0.5) / SS as f64) * D / n as f64;
                    let y = (py as f64 + (sy as f64 + 0.5) / SS as f64) * D / n as f64;
                    if !inside(x, y) {
                        continue;
                    }
                    let c: [f64; 3] = if on_digit(x, y) || on_digit(x - cell * 0.35, y) {
                        [255.0, 255.0, 255.0]
                    } else if y >= fill_top {
                        [fill_color[0] as f64, fill_color[1] as f64, fill_color[2] as f64]
                    } else {
                        base
                    };
                    r += c[0];
                    g += c[1];
                    b += c[2];
                    a += 1.0;
                }
            }
            let i = (py * n + px) * 4;
            if a > 0.0 {
                out[i] = (r / a).round() as u8;
                out[i + 1] = (g / a).round() as u8;
                out[i + 2] = (b / a).round() as u8;
                out[i + 3] = (a / (SS * SS) as f64 * 255.0).round() as u8;
            }
        }
    }
    out
}

// ================================================================ Windows: sizes and docking

#[cfg(windows)]
mod win {
    #[repr(C)]
    #[derive(Default, Clone, Copy)]
    pub struct Rect {
        pub l: i32,
        pub t: i32,
        pub r: i32,
        pub b: i32,
    }

    #[link(name = "user32")]
    extern "system" {
        pub fn GetSystemMetrics(index: i32) -> i32;
        pub fn FindWindowW(class: *const u16, name: *const u16) -> isize;
        pub fn FindWindowExW(parent: isize, after: isize, class: *const u16, name: *const u16) -> isize;
        pub fn GetWindowRect(hwnd: isize, rect: *mut Rect) -> i32;
        pub fn GetForegroundWindow() -> isize;
        pub fn GetClassNameW(hwnd: isize, buffer: *mut u16, max: i32) -> i32;
        pub fn SetWindowPos(hwnd: isize, after: isize, x: i32, y: i32, cx: i32, cy: i32, flags: u32) -> i32;
        pub fn ShowWindow(hwnd: isize, command: i32) -> i32;
        pub fn IsWindowVisible(hwnd: isize) -> i32;
    }
}

#[cfg(windows)]
fn icon_size() -> u32 {
    const SM_CXSMICON: i32 = 49;
    (unsafe { win::GetSystemMetrics(SM_CXSMICON) }).clamp(16, 64) as u32
}

#[cfg(not(windows))]
fn icon_size() -> u32 {
    32
}

#[cfg(windows)]
fn wide(text: &str) -> Vec<u16> {
    text.encode_utf16().chain(Some(0)).collect()
}

#[cfg(windows)]
fn rect_of(hwnd: isize) -> Option<win::Rect> {
    let mut rect = win::Rect::default();
    if hwnd == 0 || unsafe { win::GetWindowRect(hwnd, &mut rect) } == 0 {
        return None;
    }
    Some(rect)
}

/// A full-screen program (game, video, presentation) is in front: the strip must not cover it.
#[cfg(windows)]
fn fullscreen_in_front(taskbar: isize, screen_w: i32, screen_h: i32) -> bool {
    let front = unsafe { win::GetForegroundWindow() };
    if front == 0 || front == taskbar {
        return false;
    }
    let mut buffer = [0u16; 64];
    let length = unsafe { win::GetClassNameW(front, buffer.as_mut_ptr(), buffer.len() as i32) };
    let class = String::from_utf16_lossy(&buffer[..length.max(0) as usize]);
    if matches!(class.as_str(), "Progman" | "WorkerW" | "Shell_TrayWnd" | "Shell_SecondaryTrayWnd") {
        return false;
    }
    match rect_of(front) {
        Some(r) => r.l <= 0 && r.t <= 0 && r.r >= screen_w && r.b >= screen_h,
        None => false,
    }
}

/// Where the strip goes (physical pixels), or None when it must be hidden.
#[cfg(windows)]
fn place(width_logical: f64, scale: f64) -> Option<(i32, i32, i32, i32)> {
    let taskbar = unsafe { win::FindWindowW(wide("Shell_TrayWnd").as_ptr(), std::ptr::null()) };
    let bar = rect_of(taskbar)?;
    let screen_w = unsafe { win::GetSystemMetrics(0) };
    let screen_h = unsafe { win::GetSystemMetrics(1) };
    let (bar_w, bar_h) = (bar.r - bar.l, bar.b - bar.t);
    if bar_w <= bar_h || bar_h < 20 {
        return None; // vertical taskbar
    }
    let visible = bar.b.min(screen_h) - bar.t.max(0);
    if visible < bar_h * 2 / 3 {
        return None; // auto-hidden taskbar is hidden right now
    }
    if fullscreen_in_front(taskbar, screen_w, screen_h) {
        return None;
    }
    let pad = ((bar_h as f64) * 0.12).round() as i32;
    let height = bar_h - 2 * pad;
    let width = (width_logical * scale).round() as i32;
    let notify = unsafe {
        win::FindWindowExW(taskbar, 0, wide("TrayNotifyWnd").as_ptr(), std::ptr::null())
    };
    let right = match rect_of(notify) {
        Some(n) if n.r > n.l && n.l > bar.l + width && n.l <= bar.r => n.l - (6.0 * scale).round() as i32,
        _ => bar.r - (330.0 * scale).round() as i32,
    };
    Some((right - width, bar.t + pad, width, height))
}

#[cfg(windows)]
fn dock(app: &AppHandle, config: &Config) {
    const HWND_TOPMOST: isize = -1;
    const SWP_NOACTIVATE: u32 = 0x0010;
    const SWP_SHOWWINDOW: u32 = 0x0040;
    const SW_HIDE: i32 = 0;
    let Some(window) = app.get_webview_window(STRIP_LABEL) else { return };
    let Ok(hwnd) = window.hwnd() else { return };
    let hwnd = hwnd.0 as isize;
    let scale = window.scale_factor().unwrap_or(1.0);
    match place(config.width, scale) {
        Some((x, y, w, h)) => unsafe {
            win::SetWindowPos(hwnd, HWND_TOPMOST, x, y, w, h, SWP_NOACTIVATE | SWP_SHOWWINDOW);
        },
        None => unsafe {
            if win::IsWindowVisible(hwnd) != 0 {
                win::ShowWindow(hwnd, SW_HIDE);
            }
        },
    }
}

#[cfg(not(windows))]
fn dock(_app: &AppHandle, _config: &Config) {}
