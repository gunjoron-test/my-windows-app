# পাথেয় বাই গুঞ্জরণ — পিসি সংস্করণ / Patheyo by Gunjoron — PC edition (1.2.0)

"চিরস্থায়ী সফরের পরম সঙ্গী" — পাথেয় মোবাইল অ্যাপের Windows 10/11 সংস্করণ। বাংলা (প্রধান) ও ইংরেজি।
The Windows 10/11 edition of the Patheyo mobile app. Bengali (primary) and English.
(আগের নাম / former name: NoorDesk)

## নথি / Documents

- [ব্যবহারকারী গাইড (বাংলা)](docs/USER_GUIDE_BN.md) · [User guide (English)](docs/USER_GUIDE_EN.md)
- [পরীক্ষার পূর্ণ তালিকা / Testing checklist](docs/TESTING_CHECKLIST.md)
- [সীমাবদ্ধতা / Known limitations](docs/KNOWN_LIMITATIONS.md)
- [চূড়ান্ত পর্যালোচনা / Final review (integration, security, performance)](docs/REVIEW.md)

## ধাপে ধাপে যা যোগ হয়েছে / What each step added

**Step 1**
- ভিত্তি: সিস্টেম ট্রে, সেটিংস (JSON), দুই ভাষা, হালকা/গাঢ় থিম, প্রথমবারের সেটআপ, লগ ফাইল, single instance।
- মডিউল B: অফলাইনে নামাজের সময়ের হিসাব, পাঁচ ওয়াক্তের অ্যালার্ম, আগাম রিমাইন্ডার, স্নুজ, মিস হওয়া অ্যালার্মের নোটিশ, রমজান মোড (সেহরি/ইফতার)।

**Step 2**
- মডিউল A: ডেস্কটপ উইজেট (নামাজের সময়, ঘড়ি ও তারিখ, পরবর্তী ওয়াক্তের ছোট উইজেট); টেনে সরানো, আকার বদল, লক, স্বচ্ছতা, ৪টি ডিজাইন, "সবার ওপরে" ও "ডেস্কটপে আটকানো" মোড; জায়গা ও আকার মনে থাকে। বাংলা তারিখ (বঙ্গাব্দ)।
- নতুন ফাইল: `src/widget.html`, `src/js/widget.js`, `src/css/widget.css`, `src/js/modules/widgets/`, `src/js/core/bangla-date.js`, `src-tauri/src/widgets.rs`, `src-tauri/capabilities/widgets.json`।

**Step 3**
- মডিউল C: পুরো পিসির জন্য অ্যাড ও ট্র্যাকার ব্লকার। অ্যাপের ভেতরে একটি স্থানীয় DNS ফিল্টার (127.0.0.1:53) চলে; ব্লক তালিকা StevenBlack, AdGuard DNS filter, EasyList ও EasyPrivacy-র ডোমেইন অংশ; অনুমোদিত তালিকা, নিজের ব্লক তালিকা, কাউন্টার, ব্লক হওয়া ঠিকানার তালিকা, বিরতি, স্বয়ংক্রিয় আপডেট, "ইন্টারনেট মেরামত"।
- নিরাপত্তা: DNS বদলানোর আগে ব্যাকআপ (`dns-backup.json`); প্রতিটি অ্যাডাপ্টারে 127.0.0.1-এর পরে আগের সার্ভার ও একটি নিরাপত্তা সার্ভার রাখা হয়, তাই অ্যাপ বন্ধ থাকলেও ইন্টারনেট চলে। HTTPS খোলা হয় না, কোনো সার্টিফিকেট বসানো হয় না।
- নতুন ফাইল: `src-tauri/src/blocker/` (`mod.rs`, `dns.rs`, `lists.rs`, `netcfg.rs`), `src/js/modules/blocker/index.js`। নতুন dependency: `winreg` (রেজিস্ট্রি পড়া)।
- অ্যাপের ডেটা ফোল্ডারে `Repair-Internet.cmd` রাখা হয়: অ্যাপ না খুললেও এটি চালিয়ে DNS স্বয়ংক্রিয় করা যায়।

**Step 4**
- মডিউল D: প্রাইভেসি ও ট্র্যাকিং ইন্সপেক্টর। "স্ক্যান" বোতাম Windows-এর প্রাইভেসি সেটিংস, অ্যাপের অনুমতি (ক্যামেরা, মাইক্রোফোন, লোকেশন, কন্টাক্ট), স্টার্টআপ ও ভারী ব্যাকগ্রাউন্ড প্রোগ্রাম, পরিচিত টেলিমেট্রি-প্রোগ্রাম এবং খোলা ইন্টারনেট সংযোগ পরীক্ষা করে; প্রতিটি বিষয়ে গুরুত্ব (উচ্চ/মাঝারি/কম), ব্যাখ্যা, "বন্ধ করুন" বোতাম বা নিজে করার ধাপ; প্রতিটি পরিবর্তন ফিরিয়ে আনা যায়।
- তথ্যভাণ্ডার (সহজে সম্পাদনযোগ্য JSON): `src/data/privacy-checks.json`, `tracking-programs.json`, `tracker-domains.json`।
- নতুন ফাইল: `src-tauri/src/inspector.rs`, `src-tauri/scripts/inspector-scan.ps1` (শুধু পড়ে), `src-tauri/scripts/inspector-fix.ps1` (শুধু HKCU, undo-সহ), `src/js/modules/inspector/`।

**Step 5**
- মডিউল E: এনক্রিপ্টেড DNS (DoH: Cloudflare / Quad9 / Google; ব্যর্থ হলে সাধারণ DNS-এ ফেরে), বাড়তি ফিল্টার বিভাগ (ম্যালওয়্যার, ফিশিং, প্রাপ্তবয়স্ক, জুয়া), Windows Firewall নিয়ম ব্যবস্থাপনা (দেখা, প্রোগ্রাম ব্লক, নিজের নিয়ম মোছা, অন্য নিয়ম চালু/বন্ধ, undo), নতুন প্রোগ্রামের নেটওয়ার্ক-সতর্কতা, প্রাইভেসি স্কোর (০–১০০, হিসাবের ব্যাখ্যাসহ), ব্রাউজার ও ক্লিপবোর্ড ক্লিনার (প্রিভিউ ও নিশ্চিতকরণসহ)।
- নতুন ফাইল: `src-tauri/src/psrun.rs`, `security.rs`, `netwatch.rs`; `src-tauri/scripts/firewall-list.ps1`, `firewall-apply.ps1`, `cleaner.ps1`; `src/js/modules/security/index.js`, `src/js/modules/inspector/score.js`। নতুন dependency: `ureq` (HTTPS, DoH-এর জন্য)।

**Step 6**
- মডিউল F: Pomodoro টাইমার, ফোকাস মোড (সাইট ব্লক ব্লকারের মাধ্যমে, প্রোগ্রাম সতর্ক/বন্ধ, হাতে বা সময়সূচিতে), চোখের বিশ্রাম (২০-২০-২০) ও পানির রিমাইন্ডার, স্ক্রিন টাইম (শুধু প্রোগ্রামের নাম ও সময়, পিসিতেই), টাস্ক ও নোট, আবহাওয়া (Open-Meteo, অনুমতি নিয়ে)। নতুন উইজেট: নোট, টাস্ক, ক্যালেন্ডার, আবহাওয়া।
- নতুন ফাইল: `src-tauri/src/focus.rs`, `screentime.rs`, `winproc.rs`; `src/js/modules/productivity/` (`index.js`, `weather.js`)। অ্যালার্ম শিডিউলারে অন্য মডিউলের রিমাইন্ডার ("x-..." ধরন) রাখার ব্যবস্থা।

**Step 7**
- মডিউল G: সিস্টেম মনিটর (CPU, RAM, ডিস্ক, নেটওয়ার্ক গতি; শুধু পেজ বা উইজেট খোলা থাকলে মাপা হয়), ব্যাটারি রিপোর্ট (চার্জ, স্বাস্থ্য, সাইকেল, Windows-এর পূর্ণ রিপোর্ট), স্টার্টআপ ম্যানেজার (Task Manager-এর মতো চালু/বন্ধ, আনুমানিক প্রভাবসহ), জাঙ্ক ফাইল ক্লিনার (শুধু AppData\Local-এর নির্দিষ্ট Temp/ক্যাশ ফোল্ডার, প্রিভিউ ও নিশ্চিতকরণসহ)। নতুন উইজেট: সিস্টেম মনিটর।
- নতুন ফাইল: `src-tauri/src/systools.rs`; `src-tauri/scripts/startup-list.ps1`, `startup-set.ps1`, `junk.ps1`, `battery.ps1`; `src/js/modules/system/` (`index.js`, `format.js`)।

**Step 8**
- আনইনস্টলের সময় পরিষ্কার (`src-tauri/windows/hooks.nsh`): "Windows-এর সাথে চালু" এন্ট্রি মোছা; DNS বা ফায়ারওয়াল বদলানো থাকলে একবার অনুমতি নিয়ে DNS স্বয়ংক্রিয় করা ও অ্যাপের ফায়ারওয়াল নিয়ম মোছা।
- নিরাপত্তা: অ্যাডমিন অনুমতিতে চলা স্ক্রিপ্ট এখন ফাইল থেকে নয়, এনকোড করা কমান্ড হিসেবে চলে; DNS ব্যাকআপের মান যাচাই।
- সংস্করণ ১.০.০, অ্যাপে "সাহায্য ও প্রায়ই জিজ্ঞাসিত প্রশ্ন", `docs/` ফোল্ডারে গাইড, পরীক্ষার তালিকা, সীমাবদ্ধতা ও পর্যালোচনা।

৮টি ধাপই শেষ। / All 8 steps are complete.

## GitHub দিয়ে বিল্ড (পিসিতে কিছু ইনস্টল করতে হয় না)

1. একবারই: `.github/workflows/build-windows.yml` ফাইলটি আপনার GitHub repository-তে একই পথে (path) রাখুন।
2. প্রতিটি ধাপের zip (`Patheyo_Step0N.zip`) repository-তে আপলোড করে **Commit changes** চাপুন।
3. **Actions** ট্যাবে বিল্ড শেষ হলে **Artifacts** থেকে ইনস্টলার (`.exe`) ডাউনলোড করুন।

## Build on your own PC (optional, for developers)

Requirements: Node.js LTS, Rust (stable, MSVC toolchain), Microsoft C++ Build Tools, WebView2.

```
npm install
npx tauri dev      # run in development mode
npx tauri build    # create the installer in src-tauri/target/release/bundle/nsis
```

## ফোল্ডারের গঠন / Project layout

```
src/                     user interface (plain HTML/CSS/JS, no bundler)
  index.html
  css/app.css
  js/app.js              shell: navigation, rendering, auto-saving controls
  js/core/               bridge (backend calls), store (settings), i18n, module registry, UI helpers, wizard
  js/locales/            bn.js, en.js
  js/modules/core/       Settings and About pages
  js/modules/prayer/     Module B: engine (calculation), service, alarms, sounds, location
src-tauri/               Rust backend (Tauri 2)
  src/main.rs            startup, plugins, window handling
  src/alarm.rs           generic alarm scheduler (clock thread, missed alarms, snooze)
  src/wake.rs            optional wake-from-sleep timer
  src/tray.rs            tray icon and menu
  src/settings.rs        settings.json load/save with backup
  src/logging.rs         local log file
  src/commands.rs        other commands (autostart, logs, audio file)
  src/paths.rs           data folder locations
  tauri.conf.json        app name, window, installer
tools/make-icons.ps1     regenerates the icons (optional)
```

নতুন মডিউল যোগ করতে: `src/js/modules/<name>/index.js` লিখে `src/js/app.js`-এ `registerModule(...)` করুন; সেটিংসের জন্য `src/js/core/store.js`-এর `DEFAULTS`-এ একটি অংশ যোগ করুন।

## অ্যাপের নাম বদলাতে / To rename the app

- `src-tauri/tauri.conf.json`: `productName`, `identifier`, window `title`
- `src/js/locales/bn.js` ও `en.js`: `app.name`
- `src/index.html`: `<title>` ও brand name
- `src-tauri/Cargo.toml` ও `package.json`: `name` (ঐচ্ছিক)

## গোপনীয়তা / Privacy

কোনো analytics বা telemetry নেই। ইন্টারনেট ব্যবহার হয় শুধু ব্যবহারকারী নিজে "আমার লোকেশন খুঁজুন" চাপলে।
No analytics or telemetry. The network is used only when the user presses "Find my location".

**Step 9 — পাথেয় ব্র্যান্ডিং / Patheyo branding**
- নাম, লোগো, আইকন, স্লোগান, ফন্ট (Noto Serif by Gunjoron), রং ও থিম মোবাইল অ্যাপ Patheyo v341 থেকে; অ্যাপের পরিচয় `com.gunjoron.patheyo.desktop`, সংস্করণ 1.1.0।
- মোবাইলের ডিজাইন সিস্টেম হুবহু (`src/css/patheyo-ds.css`), আইকন (`src/js/vendor/pt-icons.js`) ও নামাজের হিসাব (`prayer-calc.js`, `if-bd-times.js`: ইসলামিক ফাউন্ডেশন বাংলাদেশের সময়সূচি, ১৪টি পদ্ধতি)।
- হোম পেজ মোবাইলের মতো: সালাম ক্যালিগ্রাফি, ঘড়ি, হিজরি-ইংরেজি-বাংলা তারিখ, ৫ ওয়াক্ত, মেহরাব-অগ্রগতি, নিষিদ্ধ সময়, নফল নামাজ; শুক্রবারে "জুম’আ"।
- আজান: মোবাইলের আজান (`src/audio/azan.mp3`) ও ফুল-স্ক্রিন আজান পপআপ; প্রতি ওয়াক্তে সর্বোচ্চ ৩ বার, ১০ মিনিট পরপর।
- উইজেট: মোবাইলের হোম-স্ক্রিন উইজেট (ক্লাসিক, এসেনশিয়াল, মিনিমাল) × ৪ রূপ, ক্যানভাসে হুবহু আঁকা (`src/js/widgets/designs.js`)।
- সব নিশ্চিতকরণ পপআপ মোবাইলের মতো মাঝখানে; আমাদের সম্পর্কে, দায়মুক্তি ও ওয়েবসাইট।
- পুরোনো NoorDesk-এর সেটিংস প্রথমবার নিজে থেকে কপি হয়; ফায়ারওয়াল নিয়মের পুরোনো "NoorDesk" গ্রুপও চেনে।
- **হালনাগাদের নিয়ম:** NoorDesk-এর অ্যাড ব্লকার "পুরোপুরি বন্ধ" করুন → NoorDesk আনইনস্টল করুন ("Delete the application data" টিক দেবেন না) → Patheyo ইনস্টল করুন।

**Step 10 — টাস্কবারে লাইভ মিটার ও প্রিমিয়াম সিস্টেম মনিটর / Taskbar meters and premium system monitor**
- টাস্কবারে মিটার স্ট্রিপ: ঘড়ির বাঁ পাশে টাস্কবারের ওপরেই সিপিইউ, র‍্যাম, জিপিইউ ও নেট স্পিড (`src-tauri/src/taskbar.rs`, জানালা `meter-taskbar`); গেম/ফুল-স্ক্রিন বা লুকানো টাস্কবারে নিজে লুকায়।
- ট্রে-তে সংখ্যা আইকন: প্রতিটি মানের জন্য একটি রঙিন সংখ্যা, লোড অনুযায়ী ভরে ওঠে; ক্লিক করলে সিস্টেম মনিটর খোলে।
- জিপিইউ লোড ও ভিডিও মেমরি Windows পারফরম্যান্স কাউন্টার (PDH) থেকে, টাস্ক ম্যানেজারের মতোই; প্রসেসর ও গ্রাফিক্স কার্ডের নাম, চালু থাকার সময়।
- সিস্টেম মনিটর পেজ নতুন: রিং গেজ, লাইভ চার্ট (CPU/RAM/GPU), নেটওয়ার্ক চার্ট, "এই পিসি" তথ্য, টাস্কবার মিটারের সেটিংস ও প্রিভিউ। পুরো অ্যাপে মসৃণ পেজ-অ্যানিমেশন ও আধুনিক ছোঁয়া।
- সংস্করণ 1.2.0।

