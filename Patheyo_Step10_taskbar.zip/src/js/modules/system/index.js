// Module G: system tools.
//   * "System monitor" page: ring gauges and a live chart of CPU, RAM and GPU, network, disks,
//     system facts, the battery, and the settings of the taskbar meters (src-tauri/src/taskbar.rs).
//   * "Startup programs" page: switch programs that start with Windows on or off.
//   * "Junk files" page: preview and delete temporary and cache files.

import { invoke, listen, log } from '../../core/bridge.js';
import { num, t } from '../../core/i18n.js';
import { isEnabled } from '../../core/modules.js';
import * as store from '../../core/store.js';
import { ask, button, card, flash, notice, row, section, select, toggle } from '../../core/ui.js';
import { esc } from '../../core/util.js';
import { fmtBytes, fmtPercent, fmtRate } from './format.js';

const HISTORY = 60; // samples kept for the live chart (about 2 minutes)

let app = null;

// ---- monitor state
let sampleData = null;
let lastSample = 0;
const history = { cpu: [], ram: [], gpu: [], down: [], up: [] };
let battery = null;
let batteryLoading = false;

// ---- startup state
let startupItems = null;
let startupLoading = false;
let startupError = '';
let startupWorking = '';

// ---- junk state
let junk = null;
let junkLoading = false;
let junkWorking = false;
let junkError = '';
let junkResult = null;
const junkSelected = new Set();

const JUNK_IDS = ['temp', 'inetcache', 'thumbs', 'wer', 'dumps', 'shader'];

function errorText(error) {
  const raw = String(error && error.message ? error.message : error);
  if (raw === 'cancelled') return t('sys.cancelled');
  if (raw === 'no-result') return t('sys.noResult');
  return `${t('sys.failed')} ${raw.slice(0, 200)}`;
}

// ================================================================ taskbar meters

/** What the backend needs to draw the taskbar meters (see src-tauri/src/taskbar.rs). */
export function taskbarConfig(s, moduleOn = true) {
  const tb = (s.system && s.system.taskbar) || {};
  const shown = ['cpu', 'ram', 'gpu'].filter((k) => tb[k]).length;
  return {
    icons: moduleOn && !!tb.icons,
    cpu: !!tb.cpu,
    ram: !!tb.ram,
    gpu: !!tb.gpu,
    strip: moduleOn && !!tb.strip && (shown > 0 || !!tb.net),
    width: 14 + shown * 64 + (tb.net ? 96 : 0),
    interval: Number(tb.interval) || 2,
  };
}

function syncTaskbar() {
  invoke('taskbar_configure', { config: taskbarConfig(store.get(), isEnabled(systemModule)) }).catch((e) => log('warn', e));
}

// ================================================================ monitor

const push = (list, value) => {
  list.push(value === null || value === undefined || !Number.isFinite(Number(value)) ? null : Number(value));
  while (list.length > HISTORY) list.shift();
};

async function takeSample() {
  lastSample = Date.now();
  try {
    sampleData = await invoke('sysmon_sample');
  } catch (e) {
    log('warn', e);
    return;
  }
  const s = sampleData || {};
  push(history.cpu, s.cpu);
  push(history.ram, s.memory && s.memory.percent);
  push(history.gpu, s.gpu && s.gpu.percent);
  push(history.down, s.net && s.net.down);
  push(history.up, s.net && s.net.up);
}

async function loadBattery() {
  if (batteryLoading) return;
  batteryLoading = true;
  try {
    battery = await invoke('battery_info');
  } catch (e) {
    log('warn', e);
    battery = { hasBattery: false, error: true };
  }
  batteryLoading = false;
  app.render();
}

const barHtml = (id, percent, level) =>
  `<span class="bar big ${level || ''}"><span id="${id}" style="width:${Math.max(0, Math.min(100, Number(percent) || 0))}%"></span></span>`;

const levelOf = (percent) => (percent >= 90 ? 'danger' : percent >= 75 ? 'warn' : '');

function uptimeText(seconds) {
  const s = Number(seconds) || 0;
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  return d ? t('sm.uptimeD', { d: num(d), h: num(h) }) : t('sm.uptimeH', { h: num(h), m: num(m) });
}

/** The four ring gauges at the top: CPU, RAM, GPU, system drive. */
function gaugeData(s) {
  const mem = s.memory || null;
  const gpu = s.gpu || null;
  const disks = s.disks || [];
  const sys = disks.find((d) => d.drive === 'C:') || disks[0] || null;
  const diskPct = sys && sys.total ? ((sys.total - sys.free) / sys.total) * 100 : null;
  const gpuName = gpu && gpu.names && gpu.names.length ? gpu.names[0] : '';
  return [
    { id: 'cpu', label: t('sys.cpu'), value: s.cpu, sub: s.cores ? t('sm.cores', { n: num(s.cores) }) : '' },
    { id: 'ram', label: t('sm.ram'), value: mem ? mem.percent : null, sub: mem ? t('sys.usedOf', { used: fmtBytes(mem.used), total: fmtBytes(mem.total) }) : '' },
    {
      id: 'gpu',
      label: t('sm.gpu'),
      value: gpu ? gpu.percent : null,
      sub: gpu && gpu.memory ? t('sm.vram', { size: fmtBytes(gpu.memory) }) : gpuName ? '' : t('sm.gpuNone'),
    },
    { id: 'disk', label: sys ? t('sm.drive', { d: sys.drive }) : t('sys.disk'), value: diskPct, sub: sys ? t('sys.freeShort', { free: fmtBytes(sys.free) }) : '' },
  ];
}

function gaugeHtml(g) {
  const v = g.value === null || g.value === undefined ? null : Math.max(0, Math.min(100, Number(g.value)));
  return `<div class="sm-gauge sm-${g.id} ${v !== null && v >= 90 ? 'is-hot' : ''}" data-gauge="${g.id}">
    <div class="sm-ring">
      <svg viewBox="0 0 100 100" aria-hidden="true">
        <circle class="sm-ring__track" cx="50" cy="50" r="42" pathLength="100"></circle>
        <circle class="sm-ring__value" cx="50" cy="50" r="42" pathLength="100" stroke-dasharray="${v === null ? 0 : v.toFixed(1)} 100"></circle>
      </svg>
      <div class="sm-ring__center"><b data-v>${esc(v === null ? '—' : num(Math.round(v)))}</b>${v === null ? '' : '<small>%</small>'}</div>
    </div>
    <div class="sm-gauge__label">${esc(g.label)}</div>
    <div class="sm-gauge__sub" data-sub>${esc(g.sub || ' ')}</div>
  </div>`;
}

/** Live chart of CPU, RAM and GPU (percent) over the last two minutes. */
function chartSvg() {
  const w = 600;
  const h = 170;
  const step = w / (HISTORY - 1);
  const line = (list) => {
    const start = HISTORY - list.length;
    const pts = [];
    list.forEach((v, i) => {
      if (v !== null) pts.push(`${((start + i) * step).toFixed(1)},${(h - (Math.max(0, Math.min(100, v)) / 100) * h).toFixed(1)}`);
    });
    return pts;
  };
  const cpu = line(history.cpu);
  const area = cpu.length > 1 ? `M${cpu[0].split(',')[0]},${h} L${cpu.join(' L')} L${cpu[cpu.length - 1].split(',')[0]},${h} Z` : '';
  const poly = (pts, cls) => (pts.length > 1 ? `<polyline class="${cls}" points="${pts.join(' ')}"></polyline>` : '');
  return `<svg class="sm-chart" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-hidden="true">
    <defs><linearGradient id="smArea" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--pt-primary)" stop-opacity=".35"></stop><stop offset="1" stop-color="var(--pt-primary)" stop-opacity="0"></stop></linearGradient></defs>
    <line class="sm-grid" x1="0" x2="${w}" y1="${h * 0.25}" y2="${h * 0.25}"></line>
    <line class="sm-grid" x1="0" x2="${w}" y1="${h * 0.5}" y2="${h * 0.5}"></line>
    <line class="sm-grid" x1="0" x2="${w}" y1="${h * 0.75}" y2="${h * 0.75}"></line>
    ${area ? `<path class="sm-area" d="${area}"></path>` : ''}
    ${poly(line(history.gpu), 'sm-line sm-line--gpu')}
    ${poly(line(history.ram), 'sm-line sm-line--ram')}
    ${poly(cpu, 'sm-line sm-line--cpu')}
  </svg>`;
}

/** Small network chart (download and upload, scaled to the largest value seen). */
function netSvg() {
  const w = 300;
  const h = 70;
  const max = Math.max(1, ...history.down.filter((v) => v !== null), ...history.up.filter((v) => v !== null));
  const step = w / (HISTORY - 1);
  const pts = (list) => {
    const start = HISTORY - list.length;
    return list
      .map((v, i) => (v === null ? null : `${((start + i) * step).toFixed(1)},${(h - 2 - (v / max) * (h - 6)).toFixed(1)}`))
      .filter(Boolean)
      .join(' ');
  };
  return `<svg class="sm-net-chart" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-hidden="true">
    <polyline class="sm-line sm-line--down" points="${pts(history.down)}"></polyline>
    <polyline class="sm-line sm-line--up" points="${pts(history.up)}"></polyline>
  </svg>`;
}

function monitorBody() {
  const s = sampleData || {};
  const disks = s.disks || [];
  const net = s.net || {};
  const gpu = s.gpu || {};

  const gauges = `<div class="sm-gauges">${gaugeData(s).map(gaugeHtml).join('')}</div>`;

  const legend = `<div class="sm-legend">
      <span class="sm-key sm-key--cpu">${esc(t('sys.cpu'))} <b data-live="cpu">${esc(fmtPercent(s.cpu))}</b></span>
      <span class="sm-key sm-key--ram">${esc(t('sm.ram'))} <b data-live="ram">${esc(fmtPercent(s.memory && s.memory.percent))}</b></span>
      <span class="sm-key sm-key--gpu">${esc(t('sm.gpu'))} <b data-live="gpu">${esc(fmtPercent(gpu.percent))}</b></span>
    </div>`;
  const chart = `<div class="ds-block">${section(t('sm.liveTitle'))}<section class="pt-card card sm-chart-card">${legend}<div id="sm-chart">${chartSvg()}</div><p class="fine">${esc(t('sm.liveHint'))}</p></section></div>`;

  const network = `<div class="ds-block">${section(t('sys.network'))}<section class="pt-card card sm-net">
      <div class="sm-net__row">
        <div><div class="small-label"><i class="sm-dot sm-dot--down"></i>${esc(t('sys.download'))}</div><div class="big-value" id="mon-down">${esc(fmtRate(net.down))}</div></div>
        <div><div class="small-label"><i class="sm-dot sm-dot--up"></i>${esc(t('sys.upload'))}</div><div class="big-value" id="mon-up">${esc(fmtRate(net.up))}</div></div>
      </div>
      <div id="sm-net-chart">${netSvg()}</div>
      <p class="fine">${esc(t('sys.networkHint'))}</p>
    </section></div>`;

  const facts = [
    [t('sm.processor'), s.cpuName || '—'],
    [t('sm.threads'), s.cores ? num(s.cores) : '—'],
    [t('sm.graphics'), (gpu.names && gpu.names.length ? gpu.names.join(', ') : '—')],
    [t('sm.memoryTotal'), s.memory ? fmtBytes(s.memory.total) : '—'],
    [t('sm.uptime'), s.uptime ? uptimeText(s.uptime) : '—'],
  ];
  const info = card(
    t('sm.infoTitle'),
    `<dl class="sm-facts">${facts.map(([k, v]) => `<div><dt>${esc(k)}</dt><dd ${k === t('sm.uptime') ? 'id="sm-uptime"' : ''}>${esc(v)}</dd></div>`).join('')}</dl>`,
  );

  const diskRows = disks.length
    ? disks
        .map((d) => {
          const used = d.total - d.free;
          const percent = d.total ? (used / d.total) * 100 : 0;
          return `<div class="disk-row">
            <div class="mon-head"><b>${esc(d.drive)}</b><span class="fine">${esc(t('sys.freeOf', { free: fmtBytes(d.free), total: fmtBytes(d.total) }))}</span></div>
            ${barHtml(`mon-disk-${esc(d.drive[0])}`, percent, levelOf(percent))}
          </div>`;
        })
        .join('')
    : `<p class="fine">—</p>`;

  return `${gauges}<div class="sm-grid">${chart}${network}</div><div class="sm-grid">${info}${card(t('sys.disks'), `${diskRows}<p class="fine">${esc(t('sys.disksHint'))}</p>`)}</div>`;
}

/** Settings and a live preview of the taskbar meters. */
function taskbarCard() {
  const s = store.get();
  const tb = s.system.taskbar;
  const chip = (key, label) =>
    `<label class="sm-pick"><input type="checkbox" data-bind="system.taskbar.${key}" data-type="bool" ${tb[key] ? 'checked' : ''}><span>${esc(label)}</span></label>`;
  const preview = `<div class="sm-tb-preview" aria-hidden="true">
      <div class="sm-tb-preview__bar">
        <span class="sm-tb-preview__apps"><i></i><i></i><i></i><i></i></span>
        <span class="sm-tb-preview__strip ${tb.strip ? '' : 'is-off'}">${meterPreview(tb)}</span>
        <span class="sm-tb-preview__tray">${tb.icons ? ['cpu', 'ram', 'gpu'].filter((k) => tb[k]).map((k) => `<b class="sm-tray sm-tray--${k}" data-tray="${k}"></b>`).join('') : ''}<em>${esc(clockNow())}</em></span>
      </div>
    </div>`;
  return `<div class="ds-block">${section(t('sm.tbTitle'))}<section class="pt-card card sm-tb">
      ${preview}
      ${row(t('sm.tbStrip'), toggle('system.taskbar.strip', tb.strip), t('sm.tbStripHint'))}
      ${row(t('sm.tbIcons'), toggle('system.taskbar.icons', tb.icons), t('sm.tbIconsHint'))}
      <div class="row"><div class="row-text"><div class="row-label">${esc(t('sm.tbWhat'))}</div><div class="row-hint">${esc(t('sm.tbWhatHint'))}</div></div>
        <div class="row-ctl sm-picks">${chip('cpu', t('sys.cpu'))}${chip('ram', t('sm.ram'))}${chip('gpu', t('sm.gpu'))}${chip('net', t('sm.net'))}</div></div>
      ${row(t('sm.tbInterval'), select('system.taskbar.interval', [1, 2, 3, 5].map((v) => [v, t('sm.seconds', { n: num(v) })]), tb.interval, 'int'))}
      ${row(t('sm.tbHidden'), button('openTaskbarSettings', t('sm.tbHiddenBtn')), t('sm.tbHiddenHint'))}
    </section></div>`;
}

function clockNow() {
  const d = new Date();
  return `${d.getHours() % 12 || 12}:${String(d.getMinutes()).padStart(2, '0')}`;
}

/** Same layout as the real strip (js/widget.js, "meter"). */
export function meterItems(s, tb) {
  const items = [];
  if (tb.cpu) items.push({ id: 'cpu', label: 'CPU', value: fmtPercent(s.cpu), pct: s.cpu });
  if (tb.ram) items.push({ id: 'ram', label: 'RAM', value: fmtPercent(s.memory && s.memory.percent), pct: s.memory && s.memory.percent });
  if (tb.gpu) items.push({ id: 'gpu', label: 'GPU', value: fmtPercent(s.gpu && s.gpu.percent), pct: s.gpu && s.gpu.percent });
  return items;
}

function meterPreview(tb) {
  const s = sampleData || {};
  const net = s.net || {};
  return `${meterItems(s, tb)
    .map((m) => `<span class="mtr mtr--${m.id}"><small>${m.label}</small><b>${esc(m.value)}</b><i style="width:${Math.max(0, Math.min(100, Number(m.pct) || 0))}%"></i></span>`)
    .join('')}${tb.net ? `<span class="mtr mtr--net"><small>↓ ${esc(fmtRate(net.down))}</small><small>↑ ${esc(fmtRate(net.up))}</small></span>` : ''}`;
}

function batteryCard() {
  if (!battery) return card(t('bat.title'), `<p class="fine">${esc(t('bat.loading'))}</p>`);
  if (!battery.hasBattery) {
    return card(t('bat.title'), `<p class="fine">${esc(t(battery.error ? 'bat.failed' : 'bat.none'))}</p>`);
  }
  const statusKey = [2, 6, 7, 8, 9].includes(Number(battery.status)) ? 'bat.charging' : 'bat.onBattery';
  const runtime = battery.runtime
    ? t('bat.runtime', { h: num(Math.floor(battery.runtime / 60)), m: num(battery.runtime % 60) })
    : '';
  const packs = (battery.batteries || [])
    .map((b) => {
      const health = b.design > 0 ? Math.round((b.full / b.design) * 100) : null;
      const level = health === null ? '' : health >= 80 ? 'good' : health >= 60 ? 'fair' : 'poor';
      return `<div class="bat-pack">
        <div class="mon-head"><b>${esc([b.manufacturer, b.id].filter(Boolean).join(' '))}</b>${b.chemistry ? `<span class="fine">${esc(b.chemistry)}</span>` : ''}</div>
        <table class="times log-table"><tbody>
          <tr><th scope="row">${esc(t('bat.health'))}</th><td class="bat-${level}">${esc(health === null ? '—' : `${num(health)}%`)}${level ? ` · ${esc(t(`bat.level.${level}`))}` : ''}</td></tr>
          <tr><th scope="row">${esc(t('bat.design'))}</th><td>${esc(`${num(b.design)} mWh`)}</td></tr>
          <tr><th scope="row">${esc(t('bat.full'))}</th><td>${esc(`${num(b.full)} mWh`)}</td></tr>
          <tr><th scope="row">${esc(t('bat.cycles'))}</th><td>${esc(b.cycles > 0 ? num(b.cycles) : t('bat.unknown'))}</td></tr>
        </tbody></table>
      </div>`;
    })
    .join('');
  return card(
    t('bat.title'),
    `<div class="mon-head"><span class="mon-value">${esc(fmtPercent(battery.charge))}</span><span class="fine">${esc(t(statusKey))}${runtime ? ` · ${esc(runtime)}` : ''}</span></div>
     ${barHtml('bat-bar', battery.charge, Number(battery.charge) <= 20 ? 'danger' : '')}
     ${packs}
     <p class="fine">${esc(t('bat.healthHint'))}</p>
     ${button('batteryReport', t('bat.reportBtn'))}`,
  );
}

function renderMonitor() {
  if (!sampleData) takeSample().then(() => app.render());
  if (!battery && !batteryLoading) loadBattery();
  return `<div id="mon-body">${monitorBody()}</div>${taskbarCard()}${batteryCard()}`;
}

function setText(id, text) {
  const el = document.getElementById(id);
  if (el && el.textContent !== text) el.textContent = text;
}

function tickMonitor(now) {
  if (now - lastSample < 2000) return;
  takeSample().then(() => {
    const s = sampleData || {};
    if (!document.getElementById('mon-body')) return;
    for (const g of gaugeData(s)) {
      const box = document.querySelector(`[data-gauge="${g.id}"]`);
      if (!box) continue;
      const v = g.value === null || g.value === undefined ? null : Math.max(0, Math.min(100, Number(g.value)));
      box.querySelector('.sm-ring__value').setAttribute('stroke-dasharray', `${v === null ? 0 : v.toFixed(1)} 100`);
      box.querySelector('[data-v]').textContent = v === null ? '—' : num(Math.round(v));
      box.querySelector('[data-sub]').textContent = g.sub || ' ';
      box.classList.toggle('is-hot', v !== null && v >= 90);
    }
    const chart = document.getElementById('sm-chart');
    if (chart) chart.innerHTML = chartSvg();
    const netChart = document.getElementById('sm-net-chart');
    if (netChart) netChart.innerHTML = netSvg();
    const live = (k, v) => {
      const el = document.querySelector(`[data-live="${k}"]`);
      if (el) el.textContent = fmtPercent(v);
    };
    live('cpu', s.cpu);
    live('ram', s.memory && s.memory.percent);
    live('gpu', s.gpu && s.gpu.percent);
    const net = s.net || {};
    setText('mon-down', fmtRate(net.down));
    setText('mon-up', fmtRate(net.up));
    if (s.uptime) setText('sm-uptime', uptimeText(s.uptime));
    const strip = document.querySelector('.sm-tb-preview__strip');
    if (strip) strip.innerHTML = meterPreview(store.get().system.taskbar);
  });
}

// ================================================================ startup programs

async function loadStartup() {
  if (startupLoading) return;
  startupLoading = true;
  startupError = '';
  app.render();
  try {
    const result = await invoke('startup_list');
    startupItems = (result && result.items) || [];
  } catch (e) {
    log('error', e);
    startupItems = [];
    startupError = errorText(e);
  }
  startupLoading = false;
  app.render();
}

const itemKey = (item) => `${item.scope}|${item.approvedKey}|${item.name}`;

function displayName(item) {
  const fromPath = String(item.path || '').split(/[\\/]/).pop();
  const name = String(item.name || '').replace(/\.lnk$/i, '');
  // Long generated names (for example "...AutoLaunch_894324F1...") read better as the file name.
  return /_[0-9A-F]{16,}$/i.test(name) && fromPath ? fromPath : name;
}

function startupRow(item) {
  const key = itemKey(item);
  const busy = startupWorking === key;
  const impact = item.enabled ? item.impact : 'off';
  const button_ = `<button type="button" class="btn small ${item.enabled ? '' : 'primary'}" data-action="startupToggle" data-key="${esc(key)}" ${startupWorking ? 'disabled' : ''}>${esc(t(busy ? 'sys.working' : item.enabled ? 'su.disable' : 'su.enable'))}</button>`;
  return `<tr class="${item.enabled ? '' : 'muted-row'}">
    <td><b>${esc(displayName(item))}</b><div class="fine">${esc(item.publisher || t('su.noPublisher'))}${item.exists ? '' : ` · ${esc(t('su.missing'))}`}</div></td>
    <td>${esc(t(`su.source.${item.source}`))}</td>
    <td><span class="impact impact-${impact}">${esc(t(`su.impact.${impact}`))}</span></td>
    <td>${esc(t(item.enabled ? 'su.on' : 'su.off'))}</td>
    <td>${button_}</td>
  </tr>`;
}

function renderStartup() {
  if (startupItems === null && !startupLoading) loadStartup();
  const items = [...(startupItems || [])].sort((a, b) => Number(b.enabled) - Number(a.enabled) || displayName(a).localeCompare(displayName(b)));
  const on = items.filter((i) => i.enabled).length;
  const table = items.length
    ? `<table class="times log-table startup-table">
        <thead><tr><th scope="col">${esc(t('su.colName'))}</th><th scope="col">${esc(t('su.colFor'))}</th><th scope="col">${esc(t('su.colImpact'))}</th><th scope="col">${esc(t('su.colState'))}</th><th scope="col"></th></tr></thead>
        <tbody>${items.map(startupRow).join('')}</tbody>
      </table>`
    : `<p class="fine">${esc(t(startupLoading ? 'su.loading' : 'su.empty'))}</p>`;
  return `
    ${notice(t('su.intro'))}
    ${startupError ? notice(startupError, 'warn') : ''}
    ${card(
      t('su.title', { on: num(on), total: num(items.length) }),
      `${table}
       <div class="finding-actions">${button('startupRefresh', t('su.refresh'))}</div>
       <p class="fine">${esc(t('su.impactHint'))}</p>`,
    )}`;
}

// ================================================================ junk files

async function scanJunk() {
  if (junkLoading) return;
  junkLoading = true;
  junkError = '';
  app.render();
  try {
    junk = await invoke('junk_scan');
    junkSelected.clear();
    for (const c of junk.categories || []) if (c.available && c.files > 0 && c.id !== 'thumbs') junkSelected.add(c.id);
  } catch (e) {
    log('error', e);
    junkError = errorText(e);
  }
  junkLoading = false;
  app.render();
}

function selectedJunkBytes() {
  return ((junk && junk.categories) || []).filter((c) => junkSelected.has(c.id)).reduce((sum, c) => sum + (Number(c.bytes) || 0), 0);
}

function junkRow(c) {
  const disabled = !c.available || !c.files;
  const samples = (c.samples || []).length
    ? `<details><summary>${esc(t('junk.examples'))}</summary><ul class="plain-list detail-list">${c.samples.map((s) => `<li class="mono">${esc(s)}</li>`).join('')}</ul></details>`
    : '';
  return `<div class="junk-row">
    <label class="check"><input type="checkbox" data-action="junkToggle" data-id="${esc(c.id)}" ${junkSelected.has(c.id) ? 'checked' : ''} ${disabled ? 'disabled' : ''}>
      <span><b>${esc(t(`junk.cat.${c.id}`))}</b><span class="fine"> · ${esc(c.available ? t('junk.size', { n: num(c.files), size: fmtBytes(c.bytes) }) : t('junk.notFound'))}</span></span></label>
    <p class="fine">${esc(t(`junk.cat.${c.id}.desc`))}</p>
    ${samples}
  </div>`;
}

function junkResultCard() {
  if (!junkResult) return '';
  const rows = (junkResult.categories || [])
    .map((c) => `<tr><td>${esc(t(`junk.cat.${c.id}`))}</td><td>${esc(t('junk.resultLine', { deleted: num(c.deleted), size: fmtBytes(c.freed), failed: num(c.failed) }))}</td></tr>`)
    .join('');
  return card(t('junk.resultTitle'), `<table class="times log-table"><tbody>${rows}</tbody></table><p class="fine">${esc(t('junk.inUse'))}</p>`);
}

function renderJunk() {
  const categories = (junk && junk.categories) || [];
  const busy = junkLoading || junkWorking;
  return `
    ${notice(t('junk.safety'), 'warn')}
    <section class="card">
      <div class="blocker-head">
        <div>
          <div class="blocker-state">${esc(t('junk.title'))}</div>
          <div class="row-hint">${esc(t(junk ? 'junk.scanned' : 'junk.notScanned'))}</div>
        </div>
        <div class="blocker-controls"><button type="button" class="btn primary big" data-action="junkScan" ${busy ? 'disabled' : ''}>${esc(t(junkLoading ? 'junk.scanning' : junk ? 'junk.scanAgain' : 'junk.scanBtn'))}</button></div>
      </div>
    </section>
    ${junkError ? notice(junkError, 'warn') : ''}
    ${junkResultCard()}
    ${categories.length ? card(t('junk.found'), categories.map(junkRow).join('')) : ''}
    ${
      categories.length
        ? `<section class="card"><div class="blocker-head">
            <div><div class="row-label">${esc(t('junk.selected', { n: num(junkSelected.size), size: fmtBytes(selectedJunkBytes()) }))}</div><div class="row-hint">${esc(t('junk.selectedHint'))}</div></div>
            <div class="blocker-controls"><button type="button" class="btn danger big" data-action="junkClean" ${busy || !junkSelected.size ? 'disabled' : ''}>${esc(t(junkWorking ? 'junk.cleaning' : 'junk.cleanBtn'))}</button></div>
          </div></section>`
        : ''
    }
    ${card(
      t('junk.moreTitle'),
      `<p class="fine">${esc(t('junk.moreText'))}</p>
       <div class="finding-actions">${button('junkStorageSense', t('junk.storageSense'))} ${button('junkBrowsers', t('junk.browsers'))}</div>`,
    )}`;
}

// ================================================================ module

const systemModule = {
  id: 'system',
  titleKey: 'module.system',
  canDisable: true,

  pages: [
    { id: 'monitor', icon: 'chart', titleKey: 'nav.monitor', subKey: 'sub.monitor', render: renderMonitor, tick: tickMonitor },
    { id: 'startup', icon: 'play', titleKey: 'nav.startup', subKey: 'sub.startup', render: renderStartup },
    { id: 'junk', icon: 'trash', titleKey: 'nav.junk', subKey: 'sub.junk', render: renderJunk },
  ],

  actions: {
    // ---- taskbar meters
    async openTaskbarSettings() {
      await invoke('open_windows_settings', { uri: 'ms-settings:taskbar' }).catch((e) => log('warn', e));
    },

    // ---- battery
    async batteryReport() {
      flash(t('bat.reportMaking'));
      try {
        await invoke('battery_report_open');
      } catch (e) {
        flash(errorText(e), 'warn');
      }
    },

    // ---- startup
    startupRefresh() {
      return loadStartup();
    },
    async startupToggle(el) {
      const item = (startupItems || []).find((i) => itemKey(i) === el.dataset.key);
      if (!item || startupWorking) return;
      const enable = !item.enabled;
      const name = displayName(item);
      const question = t(enable ? 'su.confirmEnable' : 'su.confirmDisable', { name }) + (item.scope === 'HKLM' ? `\n\n${t('su.needsAdmin')}` : '');
      if (!await ask(question)) return;
      startupWorking = itemKey(item);
      app.render();
      try {
        await invoke('startup_set', { scope: item.scope, approvedKey: item.approvedKey, name: item.name, enable });
        flash(t(enable ? 'su.enabled' : 'su.disabled', { name }));
      } catch (e) {
        flash(errorText(e), 'warn');
      }
      startupWorking = '';
      await loadStartup();
    },

    // ---- junk
    junkScan() {
      junkResult = null;
      return scanJunk();
    },
    junkToggle(el) {
      if (el.checked) junkSelected.add(el.dataset.id);
      else junkSelected.delete(el.dataset.id);
      app.render();
    },
    async junkClean() {
      if (!junkSelected.size || junkWorking) return;
      if (!await ask(t('junk.confirm', { n: num(junkSelected.size), size: fmtBytes(selectedJunkBytes()) }))) return;
      junkWorking = true;
      app.render();
      try {
        junkResult = await invoke('junk_clean', { categories: [...junkSelected].filter((id) => JUNK_IDS.includes(id)) });
        flash(t('junk.done'));
      } catch (e) {
        flash(errorText(e), 'warn');
      }
      junkWorking = false;
      await scanJunk();
    },
    async junkStorageSense() {
      await invoke('open_windows_settings', { uri: 'ms-settings:storagesense' }).catch((e) => log('warn', e));
    },
    junkBrowsers() {
      app.navigate('cleaner');
    },
  },

  async init(appContext) {
    app = appContext;
    syncTaskbar();
    // A click on a taskbar meter opens this page.
    await listen('open-page', (page) => {
      if (typeof page === 'string') app.navigate(page);
    });
  },

  onSettingsChanged(path) {
    if (path === '*' || path.startsWith('system.') || path.startsWith('modules.')) syncTaskbar();
  },
};

export default systemModule;
