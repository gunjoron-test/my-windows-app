// Settings: one JSON document saved by the backend.
// Every module owns one top-level section, so later modules only add a section here.

import { invoke, log } from './bridge.js';
import { LEGACY_METHODS, METHOD_IDS } from '../modules/prayer/methods.js';
import { clone, deepMerge, getPath, setPath } from './util.js';

export const SCHEMA_VERSION = 2; // 2 = Patheyo (mobile methods, adhan, mobile widget looks)

export const DEFAULTS = {
  schemaVersion: SCHEMA_VERSION,
  onboarded: false,

  general: {
    language: 'bn', // 'bn' | 'en'
    theme: 'dark', // 'system' | 'light' | 'dark' (dark first, like the mobile app)
    timeFormat: '12h', // '12h' | '24h'
    startWithWindows: false,
  },

  // Module on/off switches. A module that is not listed counts as "on".
  modules: {
    prayer: true,
    widgets: true,
    blocker: true,
    inspector: true,
    security: true,
    productivity: true,
    system: true,
  },

  // Productivity (Step 6).
  productivity: {
    pomodoro: { work: 25, short: 5, long: 15, longEvery: 4 },
    eye: { enabled: false, interval: 20 },
    water: { enabled: false, interval: 60, from: '08:00', to: '22:00' },
    reminderSound: true,
    focus: {
      sites: '', // one site per line, blocked while focus mode is on
      apps: '', // one program (.exe) per line
      appMode: 'warn', // 'warn' | 'close' | 'off'
      manualUntil: 0, // focus started by hand lasts until this time (ms)
      schedule: {
        enabled: false,
        from: '09:00',
        to: '17:00',
        days: { sun: true, mon: true, tue: true, wed: true, thu: true, fri: false, sat: false },
      },
    },
    tasks: [], // { id, text, done, due: 'YYYY-MM-DD' | '' }
    notes: '',
    screenTime: false,
    weather: { enabled: false, unit: 'c', cache: null },
  },

  // System tools: live meters on the Windows taskbar (Step 10, src-tauri/src/taskbar.rs).
  system: {
    taskbar: {
      strip: true, // small meter strip placed on the taskbar, left of the clock
      icons: false, // one live number per value in the notification area
      cpu: true,
      ram: true,
      gpu: true,
      net: true, // download/upload speed (strip only)
      interval: 2, // seconds between updates of the tray numbers
    },
  },

  // Extra privacy and security tools (Step 5).
  security: {
    newProgramAlert: false, // tell me when a never-seen program uses the network
  },

  // Ad and tracker blocker (Step 3). Whether it is on or off is kept by the backend,
  // because that state must match the Windows network setting.
  blocker: {
    sources: {
      stevenblack: true, adguard: true, easylist: false, easyprivacy: false,
      // optional categories (Step 5)
      malware: false, phishing: false, adult: false, gambling: false,
    },
    doh: 'off', // encrypted DNS: 'off' | 'cloudflare' | 'quad9' | 'google'
    customSources: '', // one https address per line
    allowList: '', // one name per line
    blockList: '', // one name per line
    updateDays: 3, // 0 = never update automatically
    fallback: 'cloudflare', // 'cloudflare' | 'quad9' | 'google'
  },

  // Desktop widgets (Step 2). Window position and size are kept separately by the backend.
  widgets: {
    prayer: { enabled: false, style: 'glass', design: 'classic', opacity: 100, mode: 'normal', locked: false },
    clock: { enabled: false, style: 'glass', opacity: 100, mode: 'normal', locked: false },
    next: { enabled: false, style: 'glass', opacity: 100, mode: 'normal', locked: false },
    // Step 6
    notes: { enabled: false, style: 'light', opacity: 100, mode: 'normal', locked: false },
    tasks: { enabled: false, style: 'light', opacity: 100, mode: 'normal', locked: false },
    calendar: { enabled: false, style: 'glass', opacity: 100, mode: 'normal', locked: false },
    weather: { enabled: false, style: 'glass', opacity: 100, mode: 'normal', locked: false },
    // Step 7
    sysmon: { enabled: false, style: 'glass', opacity: 100, mode: 'normal', locked: false },
  },

  location: {
    mode: 'city', // 'city' | 'manual'
    cityId: 'dhaka',
    name: '',
    lat: 23.8103,
    lng: 90.4125,
  },

  prayer: {
    method: 'auto', // see modules/prayer/methods.js (mobile app ids)
    asr: 'hanafi', // 'hanafi' | 'shafi'
    adjust: { fajr: 0, sunrise: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 },
    hijriAdjust: 0,
  },

  alarms: {
    enabled: true,
    waqt: {
      fajr: { enabled: true, pre: 0 },
      dhuhr: { enabled: true, pre: 0 },
      asr: { enabled: true, pre: 0 },
      maghrib: { enabled: true, pre: 0 },
      isha: { enabled: true, pre: 0 },
    },
    sound: 'azan', // 'azan' | 'chime' | 'bell' | 'beep' | 'custom'
    customPath: '',
    volume: 80,
    snoozeMinutes: 10, // mobile: the adhan repeats after 10 minutes
    wakeFromSleep: false,
  },

  ramadan: {
    mode: 'auto', // 'auto' | 'on' | 'off'
    sehriAlarm: true,
    sehriBefore: 30,
    iftarAlarm: true,
  },
};

let settings = clone(DEFAULTS);
let saveTimer = null;
const listeners = new Set();

const LEGACY_STYLES = { green: 'glass', dark: 'glass', glass: 'glass', light: 'light' };

function migrate(data) {
  // Schema changes, one version at a time.
  if ((Number(data.schemaVersion) || 1) < 2) {
    // NoorDesk → Patheyo: mobile calculation ids, the adhan sound, the mobile widget looks.
    const m = data.prayer.method;
    if (!METHOD_IDS.includes(m)) data.prayer.method = LEGACY_METHODS[m] || 'auto';
    if (data.alarms.sound === 'chime') data.alarms.sound = 'azan';
    if (data.alarms.snoozeMinutes === 5 || data.alarms.snoozeMinutes === 3) data.alarms.snoozeMinutes = 10;
    for (const w of Object.values(data.widgets || {})) {
      if (w && typeof w === 'object' && LEGACY_STYLES[w.style]) w.style = LEGACY_STYLES[w.style];
    }
  }
  if (!METHOD_IDS.includes(data.prayer.method)) data.prayer.method = 'auto';
  data.schemaVersion = SCHEMA_VERSION;
  return data;
}

export async function load() {
  let saved = null;
  try {
    saved = await invoke('load_settings');
  } catch (e) {
    log('error', e);
  }
  settings = migrate(deepMerge(clone(DEFAULTS), saved || {}));
  return settings;
}

export const get = () => settings;

export const read = (path) => getPath(settings, path);

function persist() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    invoke('save_settings', { settings }).catch((e) => log('error', e));
  }, 250);
}

/** Changes one value, saves, and tells everyone who subscribed. */
export function set(path, value) {
  setPath(settings, path, value);
  persist();
  for (const fn of listeners) {
    try {
      fn(path, value);
    } catch (e) {
      log('error', e);
    }
  }
}

export async function reset() {
  settings = clone(DEFAULTS);
  persist();
  for (const fn of listeners) fn('*', null);
}

export function subscribe(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}
