// Runs inside every desktop widget window. The window label ("widget-prayer", "widget-clock",
// "widget-next", ... and "meter-taskbar" for the strip on the taskbar) decides what is drawn. Widgets only read settings; changes are sent
// to the main window, which is the single place that saves them.

import { fmtBanglaDate } from './core/bangla-date.js';
import { currentWindowLabel, emit, invoke, listen, log, startDragging, startResizing } from './core/bridge.js';
import { fmtCountdown, fmtDate, fmtTime, lang, num, setLang, t } from './core/i18n.js';
import * as store from './core/store.js';
import { esc, pad2, ymd } from './core/util.js';
import { computeState, fmtHijri, hijri, locationName, waqtName } from './modules/prayer/service.js';
import { draw, snapshot } from './widgets/designs.js';
import { WEATHER_ICONS, weatherKind } from './modules/productivity/weather.js';
import { fmtBytes, fmtPercent, fmtRate } from './modules/system/format.js';
import { WIDGET_TYPES, widgetConfig } from './modules/widgets/types.js';

const root = document.getElementById('widget');

function detectId() {
  const label = currentWindowLabel();
  if (label === 'meter-taskbar') return 'meter'; // the strip on the Windows taskbar (taskbar.rs)
  if (new URLSearchParams(location.search).get('type') === 'meter') return 'meter'; // browser preview
  const fromLabel = label && label.startsWith('widget-') ? label.slice(7) : null;
  const fromQuery = new URLSearchParams(location.search).get('type'); // browser preview only
  const id = fromLabel || fromQuery || 'prayer';
  return WIDGET_TYPES[id] ? id : 'prayer';
}

const id = detectId();
let renderKey = '';

// ---------------------------------------------------------------- prayer, clock, next

const ic = (name, cls = '') => (window.PT && window.PT.icon ? window.PT.icon(name, cls) : '');
let drawing = false;

/** The mobile home-screen widget, drawn on a canvas (js/widgets/designs.js). */
function prayerWidget() {
  return '<canvas id="w-canvas" aria-label="Patheyo"></canvas>';
}

function drawPrayer(s, st, now, cfg) {
  const canvas = document.getElementById('w-canvas');
  if (!canvas || drawing) return;
  drawing = true;
  draw(canvas, cfg.design, cfg.style, snapshot(s, st, now), window.innerWidth, window.innerHeight)
    .catch((e) => log('warn', e))
    .finally(() => {
      drawing = false;
    });
}

function clockParts(s, now) {
  const d = new Date(now);
  if (s.general.timeFormat === '24h') {
    return { main: `${pad2(d.getHours())}:${pad2(d.getMinutes())}`, seconds: pad2(d.getSeconds()), suffix: '' };
  }
  const h12 = d.getHours() % 12 === 0 ? 12 : d.getHours() % 12;
  return { main: `${pad2(h12)}:${pad2(d.getMinutes())}`, seconds: pad2(d.getSeconds()), suffix: d.getHours() < 12 ? 'AM' : 'PM' };
}

function clockWidget(s, st, now) {
  const c = clockParts(s, now);
  return `
    <div class="w-brand"><img src="img/logo.png" alt=""><span>${esc(t('app.short'))}</span></div>
    <div class="w-clock"><span id="w-clock-main">${esc(c.main)}</span><span class="w-sec"><span class="w-mer">${esc(c.suffix)}</span><span id="w-clock-sec">${esc(c.seconds)}</span></span></div>
    <div class="w-dates">
      <span>${esc(st.hijri ? fmtHijri(st.hijri) : '')}</span><i></i>
      <span>${esc(fmtDate(st.date))}</span><i></i>
      <span>${esc(fmtBanglaDate(st.date))}</span>
    </div>`;
}

function nextWidget(s, st, now) {
  return `
    <div class="w-mini-label">${ic('mosque', 'pt-ic--sm')}${esc(t('dash.next'))}</div>
    <div class="w-mini-row">
      <div><div class="w-mini-name">${esc(waqtName(st.next.key, new Date(st.next.at)))}</div><div class="w-mini-time">${esc(fmtTime(st.next.at, s.general.timeFormat))}</div></div>
      <b class="w-count big" id="w-count">${esc(fmtCountdown(st.next.at - now))}</b>
    </div>`;
}

// ---------------------------------------------------------------- Step 6 widgets

function notesWidget(s) {
  return `<div class="w-title">${ic('edit', 'pt-ic--sm')}${esc(t('notes.title'))}</div>
    <textarea class="w-notes" id="w-notes" spellcheck="false" maxlength="20000" aria-label="${esc(t('notes.title'))}" placeholder="${esc(t('notes.placeholder'))}">${esc(s.productivity.notes)}</textarea>`;
}

function shortDate(text) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(text || ''));
  if (!match) return '';
  const d = new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
  return new Intl.DateTimeFormat(lang() === 'bn' ? 'bn-BD' : 'en-GB', { day: 'numeric', month: 'short' }).format(d);
}

function tasksWidget(s) {
  const all = s.productivity.tasks || [];
  const open = all.filter((x) => !x.done).sort((a, b) => String(a.due || '9999').localeCompare(String(b.due || '9999')));
  const today = ymd(new Date());
  const items = open
    .slice(0, 30)
    .map(
      (task) => `<li><label><input type="checkbox" data-task="${esc(task.id)}"> <span>${esc(task.text)}</span></label>${
        task.due ? `<small class="${task.due < today ? 'late' : ''}">${esc(shortDate(task.due))}</small>` : ''
      }</li>`,
    )
    .join('');
  const doneCount = all.length - open.length;
  return `<div class="w-title">${ic('check-circle', 'pt-ic--sm')}${esc(t('tasks.title'))}${doneCount ? ` <small>· ${esc(t('tasks.doneCount', { n: num(doneCount) }))}</small>` : ''}</div>
    <ul class="w-tasks">${items || `<li class="w-empty">${esc(t('tasks.allDone'))}</li>`}</ul>
    <input class="w-add" id="w-add" maxlength="200" placeholder="${esc(t('tasks.addPlaceholder'))}" aria-label="${esc(t('tasks.addPlaceholder'))}">`;
}

function calendarWidget(s, st) {
  const today = st.date;
  const year = today.getFullYear();
  const month = today.getMonth();
  const first = new Date(year, month, 1).getDay();
  const days = new Date(year, month + 1, 0).getDate();
  const dueDays = new Set((s.productivity.tasks || []).filter((x) => !x.done && x.due).map((x) => x.due));
  const title0 = new Intl.DateTimeFormat(lang() === 'bn' ? 'bn-BD' : 'en-GB', { month: 'long', year: 'numeric' }).format(today);
  const heads = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'].map((k) => `<span class="w-cal-head">${esc(t(`dayShort.${k}`))}</span>`).join('');
  let cells = '';
  for (let i = 0; i < first; i++) cells += '<span></span>';
  for (let d = 1; d <= days; d++) {
    const key = `${year}-${pad2(month + 1)}-${pad2(d)}`;
    const classes = [d === today.getDate() ? 'today' : '', dueDays.has(key) ? 'due' : ''].join(' ');
    cells += `<span class="w-cal-day ${classes}">${esc(num(d))}</span>`;
  }
  return `<div class="w-title">${ic('calendar', 'pt-ic--sm')}${esc(title0)}</div>
    <div class="w-cal">${heads}${cells}</div>
    <div class="w-cal-foot">${esc(st.hijri ? fmtHijri(st.hijri) : fmtHijri(hijri(today, s.prayer.hijriAdjust)))}</div>`;
}

function weatherWidget(s) {
  const w = s.productivity.weather;
  if (!w.enabled) return `<div class="w-title">${ic('cloud', 'pt-ic--sm')}${esc(t('weather.title'))}</div><p class="w-empty">${esc(t('weather.offWidget'))}</p>`;
  const c = w.cache;
  if (!c) return `<div class="w-title">${ic('cloud', 'pt-ic--sm')}${esc(t('weather.title'))}</div><p class="w-empty">${esc(t('weather.loading'))}</p>`;
  const kind = weatherKind(c.code);
  const unit = c.unit === 'f' ? '°F' : '°C';
  const extra = [
    c.max !== null && c.min !== null ? `↑${num(c.max)}° ↓${num(c.min)}°` : '',
    c.humidity !== null ? `💧 ${num(c.humidity)}%` : '',
    c.wind !== null ? `🌬 ${num(c.wind)} km/h` : '',
  ].filter(Boolean).join(' · ');
  return `<div class="w-head"><span>${ic('location', 'pt-ic--sm')}${esc(c.place || '')}</span><span>${esc(fmtTime(c.at, s.general.timeFormat))}</span></div>
    <div class="w-weather"><span class="w-weather-icon">${WEATHER_ICONS[kind]}</span><span class="w-weather-temp">${esc(num(c.temp))}${unit}</span></div>
    <div class="w-weather-text">${esc(t(`weather.kind.${kind}`))}</div>
    <div class="w-dates">${esc(extra)}</div>`;
}

// ---------------------------------------------------------------- Step 7: system monitor

let sysData = null;

function sysBar(label, percent, text) {
  const p = Math.max(0, Math.min(100, Number(percent) || 0));
  const level = p >= 90 ? 'danger' : p >= 75 ? 'warn' : '';
  return `<div class="w-sys-row">
    <div class="w-sys-label"><span>${esc(label)}</span><b>${esc(text)}</b></div>
    <div class="w-sys-bar ${level}"><span style="width:${p}%"></span></div>
  </div>`;
}

function sysmonWidget() {
  const s = sysData || {};
  const mem = s.memory;
  const disk = (s.disks || []).find((d) => d.drive === 'C:') || (s.disks || [])[0];
  const diskUsed = disk && disk.total ? ((disk.total - disk.free) / disk.total) * 100 : null;
  const net = s.net || {};
  return `<div class="w-title">${ic('chart', 'pt-ic--sm')}${esc(t('widgets.type.sysmonShort'))}</div>
    ${sysBar(t('sys.cpu'), s.cpu, fmtPercent(s.cpu))}
    ${sysBar(t('sys.memory'), mem ? mem.percent : 0, mem ? fmtPercent(mem.percent) : '—')}
    ${s.gpu && s.gpu.percent !== null && s.gpu.percent !== undefined ? sysBar(t('sm.gpu'), s.gpu.percent, fmtPercent(s.gpu.percent)) : ''}
    ${disk ? sysBar(`${t('sys.disk')} ${disk.drive}`, diskUsed, t('sys.freeShort', { free: fmtBytes(disk.free) })) : ''}
    <div class="w-sys-net"><span>⬇ ${esc(fmtRate(net.down))}</span><span>⬆ ${esc(fmtRate(net.up))}</span></div>`;
}

async function sampleSystem() {
  try {
    sysData = await invoke('sysmon_sample');
  } catch (e) {
    log('warn', e);
  }
}

// ---------------------------------------------------------------- Step 10: taskbar strip

let taskbarTheme = 'dark';

async function loadTaskbarTheme() {
  try {
    taskbarTheme = (await invoke('taskbar_theme')) === 'light' ? 'light' : 'dark';
  } catch {
    taskbarTheme = 'dark';
  }
}

/** CPU / RAM / GPU / network in one row, sized to the taskbar height (like TrafficMonitor). */
function meterWidget(s) {
  const tb = (s.system && s.system.taskbar) || {};
  const d = sysData || {};
  const items = [];
  if (tb.cpu) items.push(['cpu', 'CPU', d.cpu]);
  if (tb.ram) items.push(['ram', 'RAM', d.memory && d.memory.percent]);
  if (tb.gpu) items.push(['gpu', 'GPU', d.gpu && d.gpu.percent]);
  const net = d.net || {};
  const cells = items
    .map(([key, label, value]) => {
      const p = value === null || value === undefined ? 0 : Math.max(0, Math.min(100, Number(value)));
      const hot = p >= 90 ? ' is-hot' : '';
      return `<span class="mtr mtr--${key}${hot}"><small>${label}</small><b>${esc(fmtPercent(value))}</b><i style="width:${p}%"></i></span>`;
    })
    .join('');
  const netCell = tb.net
    ? `<span class="mtr mtr--net"><small>↓ ${esc(fmtRate(net.down))}</small><small>↑ ${esc(fmtRate(net.up))}</small></span>`
    : '';
  return `<div class="mtr-row" title="Patheyo">${cells}${netCell}</div>`;
}

const RENDERERS = {
  meter: meterWidget,
  sysmon: sysmonWidget,
  prayer: prayerWidget,
  clock: clockWidget,
  next: nextWidget,
  notes: notesWidget,
  tasks: tasksWidget,
  calendar: calendarWidget,
  weather: weatherWidget,
};

/** True while the user is typing inside this widget (then it must not be redrawn). */
const isEditing = () => {
  const el = document.activeElement;
  return !!el && root.contains(el) && (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT');
};
let redrawAfterEditing = false;

// ---------------------------------------------------------------- drawing

function toolbar(cfg) {
  if (id === 'meter') return '';
  return `<div class="w-tools">
    <button type="button" data-act="toggleLock" title="${esc(t(cfg.locked ? 'widgets.unlock' : 'widgets.lock'))}" aria-label="${esc(t(cfg.locked ? 'widgets.unlock' : 'widgets.lock'))}">${ic(cfg.locked ? 'lock' : 'key')}</button>
    <button type="button" data-act="settings" title="${esc(t('widgets.openSettings'))}" aria-label="${esc(t('widgets.openSettings'))}">${ic('gear')}</button>
    <button type="button" data-act="hide" title="${esc(t('widgets.hide'))}" aria-label="${esc(t('widgets.hide'))}">${ic('close')}</button>
  </div>`;
}

function keyFor(s, st, cfg) {
  const d = st.date;
  const p = s.productivity;
  const own =
    {
      notes: p.notes,
      tasks: JSON.stringify(p.tasks),
      calendar: JSON.stringify(p.tasks),
      weather: JSON.stringify(p.weather),
      sysmon: JSON.stringify(sysData),
      meter: `${JSON.stringify(sysData)}|${taskbarTheme}|${JSON.stringify(s.system && s.system.taskbar)}`,
    }[id] || '';
  return [id, s.general.language, s.general.timeFormat, cfg.style, cfg.design, cfg.locked, st.next.key, st.next.at, st.current, d.getDate(), d.getMinutes(), locationName(s), own].join('|');
}

function render(force) {
  const s = store.get();
  const now = Date.now();
  const st = computeState(s, now);
  const cfg = widgetConfig(s, id);
  const key = keyFor(s, st, cfg);

  root.style.opacity = String(cfg.opacity / 100);

  if ((force || key !== renderKey) && isEditing()) {
    // Redrawing now would throw away what the user is typing; do it when they leave the box.
    redrawAfterEditing = true;
    return;
  }
  if (force || key !== renderKey) {
    renderKey = key;
    if (id === 'meter') {
      root.className = `widget type-meter theme-${taskbarTheme}`;
      root.innerHTML = meterWidget(s);
      return;
    }
    root.className = `widget type-${id} style-${cfg.style} ${cfg.locked ? 'locked' : ''}`;
    root.innerHTML = `${RENDERERS[id](s, st, now)}${toolbar(cfg)}${cfg.locked ? '' : '<div class="w-grip" data-grip="1" aria-hidden="true"></div>'}`;
    if (id === 'prayer') drawPrayer(s, st, now, cfg);
    return;
  }
  if (id === 'prayer') drawPrayer(s, st, now, cfg); // the canvas is redrawn every second (clock, countdown)

  // Nothing changed except the running numbers: update only those.
  const count = document.getElementById('w-count');
  if (count) count.textContent = fmtCountdown(st.next.at - now);
  const sec = document.getElementById('w-clock-sec');
  if (sec) sec.textContent = clockParts(s, now).seconds;
}

window.addEventListener('resize', () => {
  if (id === 'prayer') render(false);
});

async function reload() {
  await store.load();
  setLang(store.get().general.language);
  render(true);
}

// ---------------------------------------------------------------- interaction

root.addEventListener('mousedown', (event) => {
  if (event.button !== 0 || id === 'meter') return;
  if (event.target.closest('button, input, textarea, label, select, a')) return;
  if (widgetConfig(store.get(), id).locked) return;
  if (event.target.closest('[data-grip]')) startResizing();
  else startDragging();
});

root.addEventListener('click', (event) => {
  if (id === 'meter') {
    invoke('taskbar_open_monitor').catch((e) => log('warn', e));
    return;
  }
  const button = event.target.closest('[data-act]');
  if (!button) return;
  emit('widget-action', { id, action: button.dataset.act }).catch((e) => log('warn', e));
});

// ---- notes and tasks widgets: changes are sent to the main window, which saves them.

const send = (payload) => emit('widget-action', { id, ...payload }).catch((e) => log('warn', e));
let notesTimer = null;

root.addEventListener('input', (event) => {
  if (event.target.id !== 'w-notes') return;
  clearTimeout(notesTimer);
  const text = event.target.value;
  notesTimer = setTimeout(() => send({ action: 'notes', text }), 700);
});

root.addEventListener('change', (event) => {
  const box = event.target.closest('input[data-task]');
  if (box) send({ action: 'taskToggle', taskId: box.dataset.task });
});

root.addEventListener('keydown', (event) => {
  if (event.key !== 'Enter' || event.target.id !== 'w-add') return;
  const text = event.target.value.trim();
  if (text) send({ action: 'taskAdd', text });
  event.target.value = '';
});

root.addEventListener('focusout', (event) => {
  if (event.target.id === 'w-notes') {
    clearTimeout(notesTimer);
    send({ action: 'notes', text: event.target.value });
  }
  // Redraw once the user has left the box (the next tick does it).
  setTimeout(() => {
    if (redrawAfterEditing && !isEditing()) {
      redrawAfterEditing = false;
      render(true);
    }
  }, 50);
});

document.addEventListener('contextmenu', (event) => {
  // The normal right-click menu (copy/paste) stays available in the notes and the task box.
  if (!event.target.closest('textarea, input')) event.preventDefault();
});

async function boot() {
  if (id === 'sysmon' || id === 'meter') {
    // Measured only while this widget is open, every 2 seconds (shared with the app's other meters).
    await sampleSystem();
    setInterval(sampleSystem, 2000);
  }
  if (id === 'meter') {
    root.style.opacity = '1';
    await loadTaskbarTheme();
    setInterval(() => loadTaskbarTheme().catch(() => {}), 30000);
  }
  await reload();
  await listen('settings-changed', () => reload().catch((e) => log('error', e)));
  setInterval(() => {
    try {
      render(false);
    } catch (e) {
      log('error', e);
    }
  }, 1000);
}

boot().catch((e) => log('error', e));
