// Turns the raw facts of a scan into report items, using the JSON databases in src/data.
// Pure functions: no access to the PC here, which keeps the rules easy to check and change.

const SEVERITY_ORDER = { high: 0, medium: 1, low: 2 };

const CAPABILITIES = [
  { id: 'webcam', settings: 'ms-settings:privacy-webcam' },
  { id: 'microphone', settings: 'ms-settings:privacy-microphone' },
  { id: 'location', settings: 'ms-settings:privacy-location' },
  { id: 'contacts', settings: 'ms-settings:privacy-contacts' },
];

/** Windows parts that are always running; they are not "heavy background apps". */
const SYSTEM_PROCESSES = new Set([
  'system', 'idle', 'registry', 'memory compression', 'secure system', 'svchost', 'msmpeng', 'dwm', 'explorer',
  'searchhost', 'searchindexer', 'csrss', 'lsass', 'services', 'wininit', 'winlogon', 'fontdrvhost', 'smss',
  'startmenuexperiencehost', 'shellexperiencehost', 'runtimebroker', 'textinputhost', 'securityhealthservice',
  'vmmem', 'vmmemwsl', 'msedgewebview2', 'noordesk', 'sihost', 'ctfmon', 'taskhostw', 'audiodg', 'spoolsv',
  'wmiprvse', 'dllhost', 'conhost', 'applicationframehost', 'systemsettings', 'widgets', 'lockapp',
]);

const HEAVY_BYTES = 400 * 1024 * 1024;
const MANY_STARTUP = 10;

const asList = (value) => (Array.isArray(value) ? value : value ? [value] : []);

function isPrivateAddress(ip) {
  return (
    /^(10\.|192\.168\.|169\.254\.|127\.)/.test(ip) ||
    /^172\.(1[6-9]|2\d|3[01])\./.test(ip) ||
    /^(fe80|fc|fd)/i.test(ip) ||
    ip === '::1'
  );
}

function domainMatches(name, list) {
  const lower = String(name).toLowerCase();
  return list.find((entry) => lower === entry.domain || lower.endsWith(`.${entry.domain}`)) || null;
}

/** State of one database check: 'on' (finding), 'off' (fine) or 'unknown'. */
export function checkState(check, reg) {
  if (!reg || !reg.exists) return check.missing || 'unknown';
  if (check.on) return check.on.includes(reg.value) ? 'on' : 'off';
  if (check.off) return check.off.includes(reg.value) ? 'off' : 'on';
  return 'unknown';
}

function appDisplayName(app) {
  if (app.packaged) return String(app.name).split('_')[0];
  return String(app.name).replace(/#/g, '\\').split('\\').pop();
}

/** Every domain name seen in the scan's connections (so the blocklists can be asked about them). */
export function connectionDomains(scan) {
  const ipNames = new Map();
  for (const entry of asList(scan.dns)) {
    if (!entry.ip || !entry.name) continue;
    if (!ipNames.has(entry.ip)) ipNames.set(entry.ip, new Set());
    ipNames.get(entry.ip).add(String(entry.name).toLowerCase());
  }
  const names = new Set();
  for (const conn of asList(scan.connections)) {
    for (const name of ipNames.get(conn.remote) || []) names.add(name);
  }
  return { ipNames, names: [...names] };
}

/**
 * @param scan     raw result of the scan script
 * @param db       { checks, programs, domains } from src/data
 * @param ctx      { lang, t, num, blocked: Map<domain, boolean>, ownBlockList: string[] }
 * @returns {{ findings: object[], ok: object[], network: object[], counts: object }}
 */
export function evaluate(scan, db, ctx) {
  const { t, num } = ctx;
  const L = (text) => (text && (text[ctx.lang] || text.en)) || '';
  const findings = [];
  const ok = [];

  // ---- 1. Windows privacy settings
  for (const check of db.checks) {
    const state = checkState(check, (scan.registry || {})[check.id]);
    if (state === 'on') {
      findings.push({
        id: `reg:${check.id}`,
        group: 'windows',
        severity: check.severity,
        title: L(check.title),
        what: L(check.what),
        why: L(check.why),
        manual: L(check.manual),
        settings: check.settings || '',
        fix: check.fix && check.hive === 'HKCU' ? { type: 'registry', id: check.id } : null,
        details: [],
      });
    } else {
      ok.push({ group: 'windows', text: `${L(check.label)}: ${t(state === 'off' ? 'insp.stateOff' : 'insp.stateUnknown')}` });
    }
  }

  // ---- 2. App permissions
  for (const cap of CAPABILITIES) {
    const info = (scan.permissions || {})[cap.id];
    if (!info) continue;
    const capName = t(`insp.cap.${cap.id}`);
    if (info.user === 'Deny' || info.device === 'Deny') {
      ok.push({ group: 'permissions', text: t('insp.perm.denied', { cap: capName }) });
      continue;
    }
    const apps = asList(info.apps).filter((a) => a.value === 'Allow' || (!a.packaged && (a.lastUsed > 0 || a.inUse)));
    const inUse = apps.filter((a) => a.inUse);
    if (inUse.length && (cap.id === 'webcam' || cap.id === 'microphone')) {
      findings.push({
        id: `perm:${cap.id}:inuse`,
        group: 'permissions',
        severity: 'high',
        title: t('insp.perm.inUseTitle', { cap: capName }),
        what: t('insp.perm.inUseWhat', { apps: inUse.map(appDisplayName).join(', ') }),
        why: t('insp.perm.inUseWhy'),
        manual: t('insp.perm.manual', { cap: capName }),
        settings: cap.settings,
        fix: null,
        details: [],
      });
    }
    if (apps.length) {
      findings.push({
        id: `perm:${cap.id}`,
        group: 'permissions',
        severity: 'low',
        title: t('insp.perm.title', { cap: capName, n: num(apps.length) }),
        what: t('insp.perm.what', { cap: capName }),
        why: t(`insp.perm.why.${cap.id}`),
        manual: t('insp.perm.manual', { cap: capName }),
        settings: cap.settings,
        fix: null,
        details: apps.slice(0, 20).map(appDisplayName),
      });
    } else {
      ok.push({ group: 'permissions', text: t('insp.perm.none', { cap: capName }) });
    }
  }

  // ---- 3. Startup programs and heavy background apps
  const startup = asList(scan.startup);
  for (const entry of startup) {
    const command = ` ${String(entry.command || '')} `;
    const fromTemp = /\\(temp|tmp|downloads)\\/i.test(command);
    const viaScript = /[\\\s"](wscript|cscript|mshta|powershell|pwsh|cmd)(\.exe)?["\s]/i.test(command);
    if (!fromTemp && !viaScript) continue;
    findings.push({
      id: `startup:${entry.name}`,
      group: 'startup',
      severity: fromTemp ? 'high' : 'medium',
      title: t('insp.startup.oddTitle', { name: entry.name }),
      what: t(fromTemp ? 'insp.startup.oddTemp' : 'insp.startup.oddScript'),
      why: t('insp.startup.oddWhy'),
      manual: t('insp.startup.manual'),
      settings: 'ms-settings:startupapps',
      fix: null,
      details: [String(entry.command || '').slice(0, 300)],
    });
  }
  if (startup.length > MANY_STARTUP) {
    findings.push({
      id: 'startup:many',
      group: 'startup',
      severity: 'low',
      title: t('insp.startup.manyTitle', { n: num(startup.length) }),
      what: t('insp.startup.manyWhat'),
      why: t('insp.startup.manyWhy'),
      manual: t('insp.startup.manual'),
      settings: 'ms-settings:startupapps',
      fix: null,
      details: startup.slice(0, 30).map((e) => e.name),
    });
  } else {
    ok.push({ group: 'startup', text: t('insp.startup.count', { n: num(startup.length) }) });
  }

  const groups = new Map();
  for (const proc of asList(scan.processes)) {
    const key = String(proc.name || '').toLowerCase();
    if (!key || SYSTEM_PROCESSES.has(key)) continue;
    const group = groups.get(key) || { name: proc.name, bytes: 0, window: false };
    group.bytes += Number(proc.ws) || 0;
    group.window = group.window || !!proc.window;
    groups.set(key, group);
  }
  const heavy = [...groups.values()]
    .filter((g) => !g.window && g.bytes > HEAVY_BYTES)
    .sort((a, b) => b.bytes - a.bytes)
    .slice(0, 6);
  if (heavy.length) {
    findings.push({
      id: 'startup:heavy',
      group: 'startup',
      severity: 'low',
      title: t('insp.heavy.title', { n: num(heavy.length) }),
      what: t('insp.heavy.what'),
      why: t('insp.heavy.why'),
      manual: t('insp.heavy.manual'),
      settings: '',
      fix: null,
      details: heavy.map((g) => `${g.name} — ${num(Math.round(g.bytes / 1048576))} MB`),
    });
  } else {
    ok.push({ group: 'startup', text: t('insp.heavy.none') });
  }

  // ---- 4. Installed programs listed in the database
  const installed = [
    ...asList(scan.programs).map((p) => String(p.name || '').toLowerCase()),
    ...asList(scan.appx).map((name) => String(name || '').toLowerCase()),
  ];
  let programHits = 0;
  for (const program of db.programs) {
    if (!installed.some((name) => program.match.some((m) => name.includes(m)))) continue;
    programHits += 1;
    findings.push({
      id: `prog:${program.id}`,
      group: 'programs',
      severity: program.severity,
      title: t('insp.prog.title', { name: program.name }),
      what: L(program.what),
      why: t('insp.prog.why'),
      manual: L(program.how),
      settings: '',
      fix: null,
      details: [],
    });
  }
  ok.push({ group: 'programs', text: t('insp.prog.checked', { n: num(asList(scan.programs).length), hits: num(programHits) }) });

  // ---- 5. Open internet connections
  const processNames = new Map(asList(scan.processes).map((p) => [p.id, p.name]));
  const { ipNames } = connectionDomains(scan);
  const byProcess = new Map();
  for (const conn of asList(scan.connections)) {
    if (isPrivateAddress(String(conn.remote))) continue;
    const name = processNames.get(conn.pid) || `PID ${conn.pid}`;
    const entry = byProcess.get(name) || { name, remotes: new Set(), domains: new Set() };
    entry.remotes.add(conn.remote);
    for (const domain of ipNames.get(conn.remote) || []) entry.domains.add(domain);
    byProcess.set(name, entry);
  }
  const network = [...byProcess.values()]
    .map((e) => ({ name: e.name, count: e.remotes.size, domains: [...e.domains].slice(0, 8) }))
    .sort((a, b) => b.count - a.count);

  const ownBlocked = new Set((ctx.ownBlockList || []).map((d) => d.toLowerCase()));
  let trackerHits = 0;
  for (const entry of byProcess.values()) {
    for (const domain of entry.domains) {
      const known = domainMatches(domain, db.domains);
      const listed = ctx.blocked && ctx.blocked.get(domain);
      if (!known && !listed) continue;
      if (trackerHits >= 15) break;
      trackerHits += 1;
      const target = known ? known.domain : domain;
      findings.push({
        id: `net:${entry.name}:${domain}`,
        group: 'network',
        severity: 'medium',
        title: t('insp.net.title', { proc: entry.name, domain }),
        what: known
          ? t('insp.net.whatKnown', { owner: known.owner, category: t(`insp.net.cat.${known.category}`) })
          : t('insp.net.whatListed'),
        why: t('insp.net.why'),
        manual: t('insp.net.manual'),
        settings: '',
        fix: ownBlocked.has(target) ? null : { type: 'block', domain: target },
        details: [],
      });
    }
  }
  if (!trackerHits) ok.push({ group: 'network', text: t('insp.net.none') });

  findings.sort((a, b) => SEVERITY_ORDER[a.severity] - SEVERITY_ORDER[b.severity]);
  const counts = { high: 0, medium: 0, low: 0 };
  for (const finding of findings) counts[finding.severity] += 1;

  return { findings, ok, network, counts };
}
