// Module D: privacy and tracking inspector (report page).

import { invoke, log } from '../../core/bridge.js';
import { fmtTime, lang, num, t } from '../../core/i18n.js';
import * as store from '../../core/store.js';
import { button, card, flash, notice } from '../../core/ui.js';
import { esc } from '../../core/util.js';
import { connectionDomains, evaluate } from './evaluate.js';

const GROUPS = ['windows', 'permissions', 'startup', 'programs', 'network'];

let app = null;
let db = null; // { checks, programs, domains }
let scan = null; // raw facts of the last scan (kept in memory only)
let blocked = new Map();
let report = null;
let history = [];
let scanning = false;
let scanError = '';

async function loadJson(path) {
  const response = await fetch(path, { cache: 'no-store' });
  if (!response.ok) throw new Error(`${path}: HTTP ${response.status}`);
  return response.json();
}

async function loadDatabases() {
  if (db) return db;
  const [checks, programs, domains] = await Promise.all([
    loadJson('data/privacy-checks.json'),
    loadJson('data/tracking-programs.json'),
    loadJson('data/tracker-domains.json'),
  ]);
  db = { checks, programs, domains };
  return db;
}

const ownBlockList = () =>
  String(store.get().blocker.blockList || '')
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);

function buildReport() {
  if (!scan || !db) {
    report = null;
    return;
  }
  report = evaluate(scan, db, { lang: lang(), t, num, blocked, ownBlockList: ownBlockList() });
}

async function runScan() {
  if (scanning) return;
  scanning = true;
  scanError = '';
  app.render();
  try {
    await loadDatabases();
    scan = await invoke('inspector_scan');
    // Ask the ad blocker's lists which of the contacted names are known ad/tracker addresses.
    blocked = new Map();
    const names = connectionDomains(scan).names;
    if (names.length) {
      try {
        const flags = (await invoke('blocker_check', { names })) || [];
        names.forEach((name, i) => blocked.set(name, !!flags[i]));
      } catch (e) {
        log('warn', e);
      }
    }
    buildReport();
  } catch (e) {
    log('error', e);
    scanError = String(e && e.message ? e.message : e).slice(0, 300);
  }
  scanning = false;
  app.render();
}

// ---------------------------------------------------------------- page

function findingCard(f) {
  const details = f.details.length
    ? `<ul class="plain-list detail-list">${f.details.map((d) => `<li>${esc(d)}</li>`).join('')}</ul>`
    : '';
  let actions = '';
  if (f.fix && f.fix.type === 'registry') {
    actions += `<button type="button" class="btn primary" data-action="inspFix" data-id="${esc(f.fix.id)}">${esc(t('insp.fixBtn'))}</button>`;
  }
  if (f.fix && f.fix.type === 'block') {
    actions += `<button type="button" class="btn primary" data-action="inspBlock" data-domain="${esc(f.fix.domain)}">${esc(t('insp.blockBtn'))}</button>`;
  }
  if (f.settings) {
    actions += `<button type="button" class="btn" data-action="inspOpenSettings" data-uri="${esc(f.settings)}">${esc(t('insp.openSettings'))}</button>`;
  }
  return `<div class="finding sev-${f.severity}">
    <div class="finding-head"><span class="sev">${esc(t(`insp.sev.${f.severity}`))}</span><h3>${esc(f.title)}</h3></div>
    <p>${esc(f.what)}</p>
    ${details}
    <p class="fine"><b>${esc(t('insp.whyLabel'))}</b> ${esc(f.why)}</p>
    ${actions ? `<div class="finding-actions">${actions}</div>` : ''}
    <details><summary>${esc(t(f.fix ? 'insp.manualAlso' : 'insp.manualLabel'))}</summary><p>${esc(f.manual)}</p></details>
  </div>`;
}

function networkTable() {
  if (!report.network.length) return `<p class="fine">${esc(t('insp.net.noConnections'))}</p>`;
  const rows = report.network
    .slice(0, 25)
    .map(
      (n) => `<tr><td>${esc(n.name)}</td><td>${esc(num(n.count))}</td><td class="mono">${esc(n.domains.join(', ') || '—')}</td></tr>`,
    )
    .join('');
  return `<table class="times log-table">
    <thead><tr><th scope="col">${esc(t('insp.net.colProgram'))}</th><th scope="col">${esc(t('insp.net.colCount'))}</th><th scope="col">${esc(t('insp.net.colNames'))}</th></tr></thead>
    <tbody>${rows}</tbody>
  </table>
  <p class="fine">${esc(t('insp.net.tableNote'))}</p>`;
}

function groupCard(group) {
  const items = report.findings.filter((f) => f.group === group);
  const fine = report.ok.filter((o) => o.group === group);
  const body = `
    ${items.length ? items.map(findingCard).join('') : `<p class="fine">${esc(t('insp.groupClean'))}</p>`}
    ${group === 'network' ? networkTable() : ''}
    ${fine.length ? `<details class="ok-list"><summary>${esc(t('insp.okLabel', { n: num(fine.length) }))}</summary><ul class="plain-list">${fine.map((o) => `<li>${esc(o.text)}</li>`).join('')}</ul></details>` : ''}`;
  return card(t(`insp.group.${group}`), body);
}

function fmtWhen(ms) {
  if (!ms) return '';
  const date = new Intl.DateTimeFormat(lang() === 'bn' ? 'bn-BD' : 'en-GB', { day: 'numeric', month: 'short' }).format(new Date(ms));
  return `${date}, ${fmtTime(ms, store.get().general.timeFormat)}`;
}

function historyCard() {
  if (!history.length) return card(t('insp.historyTitle'), `<p class="fine">${esc(t('insp.historyEmpty'))}</p>`);
  const L = (text) => (text && (text[lang()] || text.en)) || '';
  const rows = [...history]
    .reverse()
    .slice(0, 40)
    .map((entry) => {
      const check = db && db.checks.find((c) => c.id === entry.checkId);
      const name = check ? L(check.label) : entry.checkId;
      const state = entry.undone
        ? `<span class="fine">${esc(t('insp.historyUndone'))}</span>`
        : `<button type="button" class="btn small" data-action="inspUndo" data-entry="${esc(entry.entryId)}">${esc(t('insp.undoBtn'))}</button>`;
      return `<tr><td>${esc(name)}</td><td>${esc(fmtWhen(entry.at))}</td><td>${state}</td></tr>`;
    })
    .join('');
  return card(
    t('insp.historyTitle'),
    `<p class="fine">${esc(t('insp.historyHint'))}</p>
     <table class="times log-table"><thead><tr><th scope="col">${esc(t('insp.historyWhat'))}</th><th scope="col">${esc(t('insp.historyWhen'))}</th><th scope="col"></th></tr></thead><tbody>${rows}</tbody></table>`,
  );
}

function renderInspector() {
  const head = `<section class="card">
    <div class="blocker-head">
      <div>
        <div class="blocker-state">${esc(t('insp.title'))}</div>
        <div class="row-hint">${esc(scan ? `${t('insp.lastScan')}: ${fmtWhen(scan.scannedAt)}` : t('insp.neverScanned'))}</div>
      </div>
      <div class="blocker-controls"><button type="button" class="btn primary big" data-action="inspScan" ${scanning ? 'disabled' : ''}>${esc(t(scanning ? 'insp.scanning' : scan ? 'insp.scanAgain' : 'insp.scanBtn'))}</button></div>
    </div>
    ${
      report
        ? `<div class="stat-grid">
            <div><div class="small-label">${esc(t('insp.sev.high'))}</div><div class="big-value sev-text-high">${esc(num(report.counts.high))}</div></div>
            <div><div class="small-label">${esc(t('insp.sev.medium'))}</div><div class="big-value sev-text-medium">${esc(num(report.counts.medium))}</div></div>
            <div><div class="small-label">${esc(t('insp.sev.low'))}</div><div class="big-value">${esc(num(report.counts.low))}</div></div>
          </div>`
        : ''
    }
    <p class="fine">${esc(t('insp.intro'))}</p>
  </section>`;

  const errors = scan && Array.isArray(scan.errors) && scan.errors.length ? notice(`${t('insp.partial')} ${scan.errors.join(' | ').slice(0, 400)}`, 'warn') : '';

  return `
    ${head}
    ${notice(t('insp.disclaimer'), 'warn')}
    ${scanError ? notice(`${t('insp.scanFailed')} ${scanError}`, 'warn') : ''}
    ${errors}
    ${report ? GROUPS.map(groupCard).join('') : ''}
    ${historyCard()}`;
}

const inspectorModule = {
  id: 'inspector',
  titleKey: 'module.inspector',
  canDisable: true,

  pages: [{ id: 'inspector', icon: '🔍', titleKey: 'nav.inspector', render: renderInspector }],

  actions: {
    inspScan() {
      return runScan();
    },
    async inspFix(el) {
      const id = el.dataset.id;
      const check = db && db.checks.find((c) => c.id === id);
      if (!check) return;
      const title = (check.title && (check.title[lang()] || check.title.en)) || id;
      if (!window.confirm(t('insp.confirmFix', { title }))) return;
      try {
        history = (await invoke('inspector_fix', { id })) || history;
        flash(t('insp.fixed'));
      } catch (e) {
        log('error', e);
        flash(`${t('insp.fixFailed')} ${String(e && e.message ? e.message : e).slice(0, 200)}`, 'warn');
      }
      await runScan();
    },
    async inspUndo(el) {
      if (!window.confirm(t('insp.confirmUndo'))) return;
      try {
        history = (await invoke('inspector_undo', { entryId: el.dataset.entry })) || history;
        flash(t('insp.undone'));
      } catch (e) {
        log('error', e);
        flash(`${t('insp.fixFailed')} ${String(e && e.message ? e.message : e).slice(0, 200)}`, 'warn');
      }
      if (scan) await runScan();
      else app.render();
    },
    async inspOpenSettings(el) {
      await invoke('open_windows_settings', { uri: el.dataset.uri }).catch((e) => log('warn', e));
    },
    inspBlock(el) {
      const domain = el.dataset.domain;
      if (!domain || !window.confirm(t('insp.confirmBlock', { domain }))) return;
      const current = ownBlockList();
      if (!current.includes(domain)) store.set('blocker.blockList', [...current, domain].join('\n'));
      flash(t('insp.blockedMsg', { domain }));
    },
  },

  async init(appContext) {
    app = appContext;
    try {
      await loadDatabases();
      history = (await invoke('inspector_history')) || [];
    } catch (e) {
      log('error', e);
    }
  },

  onSettingsChanged(path) {
    // Language or own block list changed: rebuild the report text from the same scan.
    if (path === '*' || path === 'general.language' || path === 'blocker.blockList') buildReport();
  },
};

export default inspectorModule;
