# NoorDesk (সাময়িক নাম / placeholder name)

Windows 10/11-এর জন্য একটি হালকা all-in-one অ্যাপ। বাংলা (প্রধান) ও ইংরেজি।
A lightweight all-in-one utility for Windows 10/11. Bengali (primary) and English.

## এখন পর্যন্ত যা আছে / What is included so far

**Step 1**
- ভিত্তি: সিস্টেম ট্রে, সেটিংস (JSON), দুই ভাষা, হালকা/গাঢ় থিম, প্রথমবারের সেটআপ, লগ ফাইল, single instance।
- মডিউল B: অফলাইনে নামাজের সময়ের হিসাব, পাঁচ ওয়াক্তের অ্যালার্ম, আগাম রিমাইন্ডার, স্নুজ, মিস হওয়া অ্যালার্মের নোটিশ, রমজান মোড (সেহরি/ইফতার)।

**Step 2**
- মডিউল A: ডেস্কটপ উইজেট (নামাজের সময়, ঘড়ি ও তারিখ, পরবর্তী ওয়াক্তের ছোট উইজেট); টেনে সরানো, আকার বদল, লক, স্বচ্ছতা, ৪টি ডিজাইন, "সবার ওপরে" ও "ডেস্কটপে আটকানো" মোড; জায়গা ও আকার মনে থাকে। বাংলা তারিখ (বঙ্গাব্দ)।
- নতুন ফাইল: `src/widget.html`, `src/js/widget.js`, `src/css/widget.css`, `src/js/modules/widgets/`, `src/js/core/bangla-date.js`, `src-tauri/src/widgets.rs`, `src-tauri/capabilities/widgets.json`।

**Step 3**
- মডিউল C: পুরো পিসির জন্য অ্যাড ও ট্র্যাকার ব্লকার। অ্যাপের ভেতরে একটি স্থানীয় DNS ফিল্টার (127.0.0.1:53) চলে; ব্লক তালিকা StevenBlack, AdGuard DNS filter, EasyList ও EasyPrivacy-র ডোমেইন অংশ; অনুমোদিত তালিকা, নিজের ব্লক তালিকা, কাউন্টার, ব্লক হওয়া ঠিকানার তালিকা, বিরতি, স্বয়ংক্রিয় আপডেট, "ইন্টারনেট মেরামত"।
- নিরাপত্তা: DNS বদলানোর আগে ব্যাকআপ (`dns-backup.json`); প্রতিটি অ্যাডাপ্টারে 127.0.0.1-এর পরে আগের সার্ভার ও একটি নিরাপত্তা সার্ভার রাখা হয়, তাই অ্যাপ বন্ধ থাকলেও ইন্টারনেট চলে। HTTPS খোলা হয় না, কোনো সার্টিফিকেট বসানো হয় না।
- নতুন ফাইল: `src-tauri/src/blocker/` (`mod.rs`, `dns.rs`, `lists.rs`, `netcfg.rs`), `src/js/modules/blocker/index.js`। নতুন dependency: `winreg` (রেজিস্ট্রি পড়া)।
- অ্যাপের ডেটা ফোল্ডারে `Repair-Internet.cmd` রাখা হয়: অ্যাপ না খুললেও এটি চালিয়ে DNS স্বয়ংক্রিয় করা যায়।

পরের ধাপ / next steps: 4 privacy inspector · 5 extra privacy & security · 6 productivity · 7 system tools · 8 final polish & installer.

## GitHub দিয়ে বিল্ড (পিসিতে কিছু ইনস্টল করতে হয় না)

1. একবারই: `.github/workflows/build-windows.yml` ফাইলটি আপনার GitHub repository-তে একই পথে (path) রাখুন।
2. প্রতিটি ধাপের zip (`NoorDesk_Step0N.zip`) repository-তে আপলোড করে **Commit changes** চাপুন।
3. **Actions** ট্যাবে বিল্ড শেষ হলে **Artifacts** থেকে ইনস্টলার (`.exe`) ডাউনলোড করুন।

## Build on your own PC (optional, for developers)

Requirements: Node.js LTS, Rust (stable, MSVC toolchain), Microsoft C++ Build Tools, WebView2.

```
npm install
npx tauri dev      # run in development mode
npx tauri build    # create the installer in src-tauri/target/release/bundle/nsis
```

## ফোল্ডারের গঠন / Project layout

```
src/                     user interface (plain HTML/CSS/JS, no bundler)
  index.html
  css/app.css
  js/app.js              shell: navigation, rendering, auto-saving controls
  js/core/               bridge (backend calls), store (settings), i18n, module registry, UI helpers, wizard
  js/locales/            bn.js, en.js
  js/modules/core/       Settings and About pages
  js/modules/prayer/     Module B: engine (calculation), service, alarms, sounds, location
src-tauri/               Rust backend (Tauri 2)
  src/main.rs            startup, plugins, window handling
  src/alarm.rs           generic alarm scheduler (clock thread, missed alarms, snooze)
  src/wake.rs            optional wake-from-sleep timer
  src/tray.rs            tray icon and menu
  src/settings.rs        settings.json load/save with backup
  src/logging.rs         local log file
  src/commands.rs        other commands (autostart, logs, audio file)
  src/paths.rs           data folder locations
  tauri.conf.json        app name, window, installer
tools/make-icons.ps1     regenerates the icons (optional)
```

নতুন মডিউল যোগ করতে: `src/js/modules/<name>/index.js` লিখে `src/js/app.js`-এ `registerModule(...)` করুন; সেটিংসের জন্য `src/js/core/store.js`-এর `DEFAULTS`-এ একটি অংশ যোগ করুন।

## অ্যাপের নাম বদলাতে / To rename the app

- `src-tauri/tauri.conf.json`: `productName`, `identifier`, window `title`
- `src/js/locales/bn.js` ও `en.js`: `app.name`
- `src/index.html`: `<title>` ও brand name
- `src-tauri/Cargo.toml` ও `package.json`: `name` (ঐচ্ছিক)

## গোপনীয়তা / Privacy

কোনো analytics বা telemetry নেই। ইন্টারনেট ব্যবহার হয় শুধু ব্যবহারকারী নিজে "আমার লোকেশন খুঁজুন" চাপলে।
No analytics or telemetry. The network is used only when the user presses "Find my location".
