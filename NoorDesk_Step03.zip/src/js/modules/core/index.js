// Core module: Settings page, About page and general app actions.

import { invoke, isTauri, log, pickSavePath } from '../../core/bridge.js';
import { t } from '../../core/i18n.js';
import { allModules, enabledModules } from '../../core/modules.js';
import * as onboarding from '../../core/onboarding.js';
import * as store from '../../core/store.js';
import { button, card, flash, notice, row, select, toggle } from '../../core/ui.js';
import { esc } from '../../core/util.js';

let app = null;
let info = { version: '', dataDir: '', logFile: '', uncleanPreviousExit: false };

function renderSettings() {
  const s = store.get();

  const general = card(
    t('set.general'),
    `${row(t('set.language'), select('general.language', onboarding.languageOptions(), s.general.language))}
     ${row(t('set.theme'), select('general.theme', onboarding.themeOptions(), s.general.theme))}
     ${row(t('set.timeFormat'), select('general.timeFormat', [['12h', t('set.time12')], ['24h', t('set.time24')]], s.general.timeFormat))}
     ${row(t('set.autostart'), toggle('general.startWithWindows', s.general.startWithWindows), t('set.autostartHint'))}`,
  );

  const moduleSections = enabledModules()
    .map((m) => (m.settingsSections ? m.settingsSections() : ''))
    .join('');

  const moduleToggles = allModules()
    .filter((m) => m.canDisable)
    .map((m) => row(t(m.titleKey), toggle(`modules.${m.id}`, s.modules[m.id] !== false)))
    .join('');

  const modules = card(t('set.modules'), `${moduleToggles}<p class="fine">${esc(t('set.modulesHint'))}</p>`);

  const data = card(
    t('set.data'),
    `${row(t('set.exportLogs'), button('exportLogs', t('set.exportLogsBtn')), t('set.exportLogsHint'))}
     ${row(t('set.wizard'), button('rerunWizard', t('set.wizardBtn')))}
     ${row(t('set.reset'), button('resetSettings', t('set.resetBtn'), 'danger'), t('set.resetHint'))}`,
  );

  return general + moduleSections + modules + data;
}

function renderAbout() {
  const list = (keys) => `<ul class="plain-list">${keys.map((k) => `<li>${esc(t(k))}</li>`).join('')}</ul>`;
  return `
    ${card(
      t('app.name'),
      `<p>${esc(t('about.intro'))}</p>
       <p class="fine">${esc(t('about.version'))}: ${esc(info.version || '—')}</p>
       ${isTauri ? '' : notice(t('about.preview'), 'warn')}`,
    )}
    ${card(t('about.privacyTitle'), list(['about.privacy1', 'about.privacy2', 'about.privacy3']))}
    ${card(t('about.limitsTitle'), list(['about.limit1', 'about.limit2', 'about.limit3', 'about.limit4', 'about.limit5']))}
    ${card(
      t('about.dataTitle'),
      `<p class="fine path">${esc(info.dataDir || '—')}</p>
       ${row(t('about.quit'), button('quitApp', t('about.quitBtn'), 'danger'), t('about.quitHint'))}`,
    )}`;
}

async function syncAutostart(wanted) {
  try {
    const actual = await invoke('set_autostart', { enabled: !!wanted });
    if (actual !== !!wanted) {
      store.set('general.startWithWindows', !!actual);
      flash(t('set.autostartFail'), 'warn');
    }
  } catch (e) {
    log('error', e);
    store.set('general.startWithWindows', false);
    flash(t('set.autostartFail'), 'warn');
  }
}

const coreModule = {
  id: 'core',
  titleKey: 'module.core',
  canDisable: false,

  pages: [
    { id: 'settings', icon: '⚙️', titleKey: 'nav.settings', render: renderSettings },
    { id: 'about', icon: 'ℹ️', titleKey: 'nav.about', render: renderAbout },
  ],

  actions: {
    async exportLogs() {
      const path = await pickSavePath('noordesk-log.txt', t('set.logFiles'), ['txt', 'log']);
      if (!path) return;
      try {
        await invoke('export_logs', { destination: path });
        flash(t('set.exportLogsOk'));
      } catch (e) {
        log('error', e);
        flash(t('set.exportLogsFail'), 'warn');
      }
    },
    rerunWizard() {
      onboarding.start();
      app.render();
    },
    async resetSettings() {
      if (!window.confirm(t('set.resetConfirm'))) return;
      await store.reset();
      await syncAutostart(false);
      flash(t('set.resetDone'));
    },
    async quitApp() {
      if (!window.confirm(t('about.quitConfirm'))) return;
      await invoke('quit_app').catch((e) => log('error', e));
    },
    obNext() {
      onboarding.next();
      app.render();
    },
    obBack() {
      onboarding.back();
      app.render();
    },
    obFinish() {
      onboarding.finish();
    },
  },

  async init(appContext) {
    app = appContext;
    try {
      info = (await invoke('app_info')) || info;
    } catch (e) {
      log('error', e);
    }
    if (info.uncleanPreviousExit) flash(t('notice.recovered'), 'warn');

    // Make the switch show what Windows really has (the user may have changed it elsewhere).
    try {
      const actual = await invoke('get_autostart');
      if (!!actual !== !!store.get().general.startWithWindows) store.set('general.startWithWindows', !!actual);
    } catch (e) {
      log('warn', e);
    }
  },

  onSettingsChanged(path) {
    if (path === 'general.startWithWindows') syncAutostart(store.get().general.startWithWindows);
  },
};

export default coreModule;
