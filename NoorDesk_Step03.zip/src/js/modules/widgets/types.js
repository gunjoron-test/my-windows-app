// The desktop widgets that exist, their starting size, and the available looks.
// To add a widget later (system monitor, weather, notes, tasks): add it here, add its
// defaults in core/store.js, and add a renderer in js/widget.js.

export const WIDGET_TYPES = {
  prayer: { titleKey: 'widgets.type.prayer', descKey: 'widgets.desc.prayer', width: 300, height: 380 },
  clock: { titleKey: 'widgets.type.clock', descKey: 'widgets.desc.clock', width: 330, height: 200 },
  next: { titleKey: 'widgets.type.next', descKey: 'widgets.desc.next', width: 270, height: 120 },
};

export const WIDGET_IDS = Object.keys(WIDGET_TYPES);

export const WIDGET_STYLES = ['green', 'light', 'dark', 'glass'];

export const WIDGET_MODES = ['normal', 'top', 'desktop'];

export const WIDGET_DEFAULT = { enabled: false, style: 'green', opacity: 100, mode: 'normal', locked: false };

/** Settings of one widget with safe fall-backs. */
export function widgetConfig(settings, id) {
  const saved = (settings.widgets && settings.widgets[id]) || {};
  const cfg = { ...WIDGET_DEFAULT, ...saved };
  if (!WIDGET_STYLES.includes(cfg.style)) cfg.style = 'green';
  if (!WIDGET_MODES.includes(cfg.mode)) cfg.mode = 'normal';
  cfg.opacity = Math.min(100, Math.max(30, Number(cfg.opacity) || 100));
  return cfg;
}
