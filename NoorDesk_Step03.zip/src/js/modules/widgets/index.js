// Module A: desktop widgets. This file is the control page inside the main window and keeps
// the real widget windows in step with the settings. The widgets themselves are drawn by
// js/widget.js inside their own small windows.

import { invoke, listen, log } from '../../core/bridge.js';
import { num, t } from '../../core/i18n.js';
import { isEnabled } from '../../core/modules.js';
import * as store from '../../core/store.js';
import { button, card, flash, notice, row, select, toggle } from '../../core/ui.js';
import { esc } from '../../core/util.js';
import { WIDGET_IDS, WIDGET_MODES, WIDGET_STYLES, WIDGET_TYPES, widgetConfig } from './types.js';

let app = null;
let syncTimer = null;

/** Opens/closes the widget windows and applies layer mode and lock, according to settings. */
async function syncWindows() {
  const s = store.get();
  const moduleOn = isEnabled(widgetsModule);
  for (const id of WIDGET_IDS) {
    const cfg = widgetConfig(s, id);
    const type = WIDGET_TYPES[id];
    try {
      await invoke('widget_sync', {
        id,
        open: moduleOn && cfg.enabled,
        mode: cfg.mode,
        locked: cfg.locked,
        width: type.width,
        height: type.height,
      });
    } catch (e) {
      log('error', `Widget ${id}: ${e && e.message ? e.message : e}`);
    }
  }
}

function syncSoon() {
  clearTimeout(syncTimer);
  syncTimer = setTimeout(syncWindows, 150);
}

function widgetCard(s, id) {
  const cfg = widgetConfig(s, id);
  const type = WIDGET_TYPES[id];
  const base = `widgets.${id}`;
  const styleOptions = WIDGET_STYLES.map((v) => [v, t(`widgets.style.${v}`)]);
  const modeOptions = WIDGET_MODES.map((v) => [v, t(`widgets.mode.${v}`)]);

  let body = row(t('widgets.show'), toggle(`${base}.enabled`, cfg.enabled), t(type.descKey));
  if (cfg.enabled) {
    body += `
      ${row(t('widgets.styleLabel'), select(`${base}.style`, styleOptions, cfg.style))}
      ${row(t('widgets.opacity'), `<input type="range" class="range" min="30" max="100" step="5" data-bind="${base}.opacity" data-type="int" value="${esc(cfg.opacity)}"> <span class="range-value">${esc(num(cfg.opacity))}%</span>`)}
      ${row(t('widgets.modeLabel'), select(`${base}.mode`, modeOptions, cfg.mode), t('widgets.modeHint'))}
      ${row(t('widgets.lockLabel'), toggle(`${base}.locked`, cfg.locked), t('widgets.lockHint'))}
      ${row(t('widgets.reset'), `<button type="button" class="btn" data-action="widgetReset" data-id="${id}">${esc(t('widgets.resetBtn'))}</button>`)}`;
  }
  return card(t(type.titleKey), body);
}

function renderWidgets() {
  const s = store.get();
  return `
    ${notice(t('widgets.intro'))}
    ${WIDGET_IDS.map((id) => widgetCard(s, id)).join('')}
    ${notice(t('widgets.limits'), 'warn')}`;
}

const widgetsModule = {
  id: 'widgets',
  titleKey: 'module.widgets',
  canDisable: true,

  pages: [{ id: 'widgets', icon: '🧩', titleKey: 'nav.widgets', render: renderWidgets }],

  actions: {
    async widgetReset(el) {
      const id = el.dataset.id;
      const type = WIDGET_TYPES[id];
      if (!type) return;
      try {
        await invoke('widget_reset', { id, width: type.width, height: type.height });
        flash(t('widgets.resetDone'));
      } catch (e) {
        log('error', e);
      }
    },
  },

  async init(appContext) {
    app = appContext;

    // Buttons on a widget (lock, settings, hide) arrive here; the main window saves the change.
    await listen('widget-action', (payload) => {
      const id = payload && payload.id;
      if (!WIDGET_TYPES[id]) return;
      const cfg = widgetConfig(store.get(), id);
      if (payload.action === 'toggleLock') {
        store.set(`widgets.${id}.locked`, !cfg.locked);
      } else if (payload.action === 'hide') {
        store.set(`widgets.${id}.enabled`, false);
      } else if (payload.action === 'settings') {
        invoke('show_main').catch((e) => log('warn', e));
        app.navigate('widgets');
      }
    });

    await syncWindows();
  },

  onSettingsChanged(path) {
    if (path === '*' || path.startsWith('widgets.') || path.startsWith('modules.')) syncSoon();
  },
};

export default widgetsModule;
