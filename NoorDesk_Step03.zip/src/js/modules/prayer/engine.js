// Offline prayer-time calculation (no internet needed).
// Standard astronomical algorithm (as described at praytimes.org): the position of the sun is
// calculated for the date and place, and each prayer time is the moment the sun reaches a
// given angle.

import { METHODS } from './methods.js';

const RAD = Math.PI / 180;
const sin = (d) => Math.sin(d * RAD);
const cos = (d) => Math.cos(d * RAD);
const tan = (d) => Math.tan(d * RAD);
const arcsin = (x) => Math.asin(x) / RAD;
const arccos = (x) => Math.acos(x) / RAD;
const arctan2 = (y, x) => Math.atan2(y, x) / RAD;
const arccot = (x) => Math.atan(1 / x) / RAD;
const fix = (a, b) => a - b * Math.floor(a / b);
const fixHour = (h) => fix(h, 24);
const fixAngle = (a) => fix(a, 360);

/** Sun altitude at sunrise/sunset, allowing for refraction and the sun's radius. */
const HORIZON_ANGLE = 0.833;

function julian(year, month, day) {
  if (month <= 2) {
    year -= 1;
    month += 12;
  }
  const a = Math.floor(year / 100);
  const b = 2 - a + Math.floor(a / 4);
  return Math.floor(365.25 * (year + 4716)) + Math.floor(30.6001 * (month + 1)) + day + b - 1524.5;
}

/** Declination of the sun and the equation of time for a Julian date. */
function sunPosition(jd) {
  const d = jd - 2451545.0;
  const g = fixAngle(357.529 + 0.98560028 * d);
  const q = fixAngle(280.459 + 0.98564736 * d);
  const l = fixAngle(q + 1.915 * sin(g) + 0.02 * sin(2 * g));
  const e = 23.439 - 0.00000036 * d;
  const ra = arctan2(cos(e) * sin(l), cos(l)) / 15;
  return { decl: arcsin(sin(e) * sin(l)), eqt: q / 15 - fixHour(ra) };
}

function midDay(jd, time) {
  return fixHour(12 - sunPosition(jd + time).eqt);
}

/** Hour at which the sun is `angle` degrees below the horizon (before noon if `before`). */
function sunAngleTime(jd, lat, angle, time, before) {
  const decl = sunPosition(jd + time).decl;
  const noon = midDay(jd, time);
  const t = arccos((-sin(angle) - sin(decl) * sin(lat)) / (cos(decl) * cos(lat))) / 15;
  return noon + (before ? -t : t);
}

/** Asr: when an object's shadow is `factor` times its length (plus its noon shadow). */
function asrTime(jd, lat, factor, time) {
  const decl = sunPosition(jd + time).decl;
  const angle = -arccot(factor + tan(Math.abs(lat - decl)));
  return sunAngleTime(jd, lat, angle, time, false);
}

/** In far-northern/southern places the sun may never reach the angle; use half the night. */
function adjustHighLatitude(time, base, night, before) {
  const portion = night / 2;
  const diff = before ? fixHour(base - time) : fixHour(time - base);
  if (Number.isNaN(time) || diff > portion) return base + (before ? -portion : portion);
  return time;
}

/**
 * Prayer times for one calendar day.
 *
 * @param {{year:number, month:number, day:number}} date  calendar date (month 1-12)
 * @param {number} lat  latitude  (-90..90, north positive)
 * @param {number} lng  longitude (-180..180, east positive)
 * @param {{method:string, asr:string, adjust?:object, ramadan?:boolean}} options
 * @returns {{fajr:number, sunrise:number, dhuhr:number, asr:number, maghrib:number, isha:number}}
 *          each value is an exact moment (Unix time in milliseconds), rounded to the minute.
 */
export function computeTimes(date, lat, lng, options) {
  const method = METHODS[options.method] || METHODS.karachi;
  const asrFactor = options.asr === 'shafi' ? 1 : 2;
  const adjust = options.adjust || {};
  const jd = julian(date.year, date.month, date.day) - lng / (15 * 24);

  let fajr = sunAngleTime(jd, lat, method.fajr, 5 / 24, true);
  const sunrise = sunAngleTime(jd, lat, HORIZON_ANGLE, 6 / 24, true);
  const dhuhr = midDay(jd, 12 / 24);
  const asr = asrTime(jd, lat, asrFactor, 13 / 24);
  const sunset = sunAngleTime(jd, lat, HORIZON_ANGLE, 18 / 24, false);
  const maghrib = sunset;
  let isha;
  if (method.ishaMinutes) {
    const minutes = options.ramadan && method.ishaMinutesRamadan ? method.ishaMinutesRamadan : method.ishaMinutes;
    isha = maghrib + minutes / 60;
  } else {
    isha = sunAngleTime(jd, lat, method.isha, 18 / 24, false);
  }

  const night = fixHour(sunrise - sunset);
  fajr = adjustHighLatitude(fajr, sunrise, night, true);
  if (!method.ishaMinutes) isha = adjustHighLatitude(isha, sunset, night, false);

  // The hours above are local solar hours; subtracting longitude/15 gives UTC hours.
  const midnightUtc = Date.UTC(date.year, date.month - 1, date.day);
  const toMs = (hours, key) =>
    midnightUtc + Math.round((hours - lng / 15) * 60) * 60000 + (Number(adjust[key]) || 0) * 60000;

  return {
    fajr: toMs(fajr, 'fajr'),
    sunrise: toMs(sunrise, 'sunrise'),
    dhuhr: toMs(dhuhr, 'dhuhr'),
    asr: toMs(asr, 'asr'),
    maghrib: toMs(maghrib, 'maghrib'),
    isha: toMs(isha, 'isha'),
  };
}
