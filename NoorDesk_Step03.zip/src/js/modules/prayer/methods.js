// Calculation methods: the sun's angle below the horizon for Fajr and Isha.
// Sources: the published conventions of each authority (same values used by praytimes.org).
//
// Bangladesh Islamic Foundation: this app uses the 18 / 18 degree angles that are the usual
// convention in South Asia. Printed local timetables can differ by a few minutes; use the
// per-waqt "minute adjustment" in Settings to match your local timetable exactly.

export const METHODS = {
  karachi: { fajr: 18, isha: 18 },
  mwl: { fajr: 18, isha: 17 },
  ummalqura: { fajr: 18.5, ishaMinutes: 90, ishaMinutesRamadan: 120 },
  isna: { fajr: 15, isha: 15 },
  egypt: { fajr: 19.5, isha: 17.5 },
  bangladesh: { fajr: 18, isha: 18 },
};

export const METHOD_IDS = Object.keys(METHODS);

/** The five daily prayers, in order. */
export const PRAYERS = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];

/** Everything shown in the timetable, in order. */
export const TIMETABLE = ['fajr', 'sunrise', 'dhuhr', 'asr', 'maghrib', 'isha'];
