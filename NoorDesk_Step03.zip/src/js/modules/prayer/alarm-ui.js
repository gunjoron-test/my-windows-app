// The in-app alarm popup (Stop / Snooze).

import { invoke, log } from '../../core/bridge.js';
import { num, t } from '../../core/i18n.js';
import * as store from '../../core/store.js';
import { esc } from '../../core/util.js';
import * as sound from './sound.js';

/** The popup closes by itself after this long. */
const AUTO_CLOSE_MS = 10 * 60 * 1000;

let activeItem = null;
let closeTimer = null;

const root = () => document.getElementById('alarm-root');

export const isOpen = () => !!activeItem;

export async function open(item) {
  activeItem = item;
  const s = store.get();
  const icon = item.kind === 'sehri' || item.kind === 'iftar' ? '🌙' : '🕌';

  root().innerHTML = `
    <div class="alarm-backdrop" role="alertdialog" aria-modal="true" aria-labelledby="alarm-title" aria-describedby="alarm-body">
      <div class="alarm-box">
        <div class="alarm-icon" aria-hidden="true">${icon}</div>
        <h1 id="alarm-title">${esc(item.title)}</h1>
        <p id="alarm-body">${esc(item.body)}</p>
        <p class="alarm-note" id="alarm-note"></p>
        <div class="alarm-actions">
          <button type="button" class="btn primary big" data-action="alarmStop">${esc(t('alarm.stop'))}</button>
          <button type="button" class="btn big" data-action="alarmSnooze">${esc(t('alarm.snooze', { n: num(s.alarms.snoozeMinutes) }))}</button>
        </div>
      </div>
    </div>`;
  const stopButton = root().querySelector('[data-action="alarmStop"]');
  if (stopButton) stopButton.focus();

  clearTimeout(closeTimer);
  closeTimer = setTimeout(close, AUTO_CLOSE_MS);

  const result = await sound.startAlarm(s.alarms);
  if (result.fallback) {
    const note = document.getElementById('alarm-note');
    if (note) note.textContent = t('alarm.customFailed');
  }
}

/** Stops the sound and closes the popup. */
export function close() {
  sound.stop();
  clearTimeout(closeTimer);
  activeItem = null;
  root().innerHTML = '';
  invoke('end_alarm').catch((e) => log('warn', e));
}

/** Closes the popup and rings again after the snooze time. */
export async function snooze() {
  const item = activeItem;
  const minutes = Number(store.get().alarms.snoozeMinutes) || 5;
  close();
  if (!item) return;
  const baseId = String(item.id).split(':snooze:')[0];
  try {
    await invoke('add_alarm', {
      item: { ...item, id: `${baseId}:snooze:${Date.now()}`, at: Date.now() + minutes * 60000, kind: 'snooze', silent: false },
    });
  } catch (e) {
    log('error', e);
  }
}
