// Location: built-in city list, manual latitude/longitude, or (only when the user
// presses the button) a one-time lookup of the approximate location from the internet address.

import { log } from '../../core/bridge.js';
import { lang, t } from '../../core/i18n.js';
import * as store from '../../core/store.js';
import { button, notice, number, row, select } from '../../core/ui.js';
import { clamp, esc } from '../../core/util.js';
import { CITIES } from './cities.js';

function citySelect(s) {
  const label = (c) => (lang() === 'bn' ? c.bn : c.en);
  const options = (group) =>
    CITIES.filter((c) => c.group === group)
      .map((c) => `<option value="${c.id}" ${c.id === s.location.cityId ? 'selected' : ''}>${esc(label(c))}</option>`)
      .join('');
  return `<select data-bind="location.cityId">
    <optgroup label="${esc(t('loc.groupBd'))}">${options('bd')}</optgroup>
    <optgroup label="${esc(t('loc.groupWorld'))}">${options('world')}</optgroup>
  </select>`;
}

/** The location controls, used both in Settings and in the first-run wizard. */
export function locationFields(s) {
  const mode = row(
    t('loc.mode'),
    select('location.mode', [['city', t('loc.modeCity')], ['manual', t('loc.modeManual')]], s.location.mode),
  );

  const detail =
    s.location.mode === 'city'
      ? row(t('loc.city'), citySelect(s))
      : row(
          t('loc.name'),
          `<input type="text" class="text" maxlength="60" data-bind="location.name" value="${esc(s.location.name)}">`,
        ) +
        row(t('loc.lat'), number('location.lat', s.location.lat, -90, 90, 0.0001, 'float'), t('loc.latHint')) +
        row(t('loc.lng'), number('location.lng', s.location.lng, -180, 180, 0.0001, 'float'), t('loc.lngHint'));

  return `${mode}${detail}
    ${row(t('loc.detect'), button('detectLocation', t('loc.detectBtn')), t('loc.detectHint'))}
    ${notice(t('loc.timezoneNote'))}`;
}

async function fetchJson(url) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);
  try {
    const response = await fetch(url, { signal: controller.signal, cache: 'no-store' });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return await response.json();
  } finally {
    clearTimeout(timer);
  }
}

const PROVIDERS = [
  {
    url: 'https://ipwho.is/',
    read: (d) => (d && d.success !== false ? { lat: d.latitude, lng: d.longitude, city: d.city, country: d.country } : null),
  },
  {
    url: 'https://ipapi.co/json/',
    read: (d) => (d && !d.error ? { lat: d.latitude, lng: d.longitude, city: d.city, country: d.country_name } : null),
  },
];

/**
 * Looks up the approximate location from the internet address. Runs ONLY when the user
 * presses the button. Returns true on success.
 */
export async function detectLocation() {
  for (const provider of PROVIDERS) {
    try {
      const found = provider.read(await fetchJson(provider.url));
      const lat = Number(found && found.lat);
      const lng = Number(found && found.lng);
      if (!found || !Number.isFinite(lat) || !Number.isFinite(lng)) continue;

      const name = [found.city, found.country].filter(Boolean).join(', ').slice(0, 60);
      store.set('location.lat', clamp(Math.round(lat * 10000) / 10000, -90, 90));
      store.set('location.lng', clamp(Math.round(lng * 10000) / 10000, -180, 180));
      store.set('location.name', name);
      store.set('location.mode', 'manual');
      return true;
    } catch (e) {
      log('warn', `Location lookup failed (${provider.url}): ${e && e.message ? e.message : e}`);
    }
  }
  return false;
}
