// Module B: five-time prayer times and alarms.

import { invoke, listen, log, pickFile } from '../../core/bridge.js';
import { fmtCountdown, fmtDate, fmtTime, num, t } from '../../core/i18n.js';
import { isEnabled } from '../../core/modules.js';
import * as store from '../../core/store.js';
import { button, card, flash, notice, number, row, select, toggle } from '../../core/ui.js';
import { esc, ymd } from '../../core/util.js';
import * as alarmUi from './alarm-ui.js';
import { detectLocation, locationFields } from './location.js';
import { METHOD_IDS, PRAYERS, TIMETABLE } from './methods.js';
import { buildAlarmItems, computeState, fmtHijri, hijri, locationName } from './service.js';
import * as sound from './sound.js';

/** The schedule is rebuilt at least this often even when nothing changes. */
const REFRESH_EVERY_MS = 3 * 60 * 60 * 1000;

let app = null;
let missed = [];
let dashboardKey = '';
let lastRefresh = 0;
let lastDay = '';
let refreshTimer = null;

const stateKey = (st) => `${st.next.key}:${st.next.at}:${st.current}:${st.ramadan}`;

// ---------------------------------------------------------------- schedule

async function refreshSchedule() {
  const s = store.get();
  const on = isEnabled(prayerModule);
  lastRefresh = Date.now();
  lastDay = ymd(new Date());
  try {
    await invoke('set_schedule', {
      items: on ? buildAlarmItems(s) : [],
      wake: on && s.alarms.enabled && s.alarms.wakeFromSleep,
    });
  } catch (e) {
    log('error', e);
  }
}

function refreshScheduleSoon() {
  clearTimeout(refreshTimer);
  refreshTimer = setTimeout(refreshSchedule, 300);
}

async function loadAlarmState() {
  try {
    const st = await invoke('get_alarm_state');
    missed = (st && st.missed) || [];
    return st;
  } catch (e) {
    log('error', e);
    return null;
  }
}

// ---------------------------------------------------------------- dashboard page

function missedBanner() {
  if (!missed.length) return '';
  const lines = missed
    .slice(-5)
    .map((m) => `<li>${esc(m.missedBody || m.title)}</li>`)
    .join('');
  return `<section class="card warn-card" role="status">
    <h2>${esc(t('dash.missedTitle'))}</h2>
    <ul class="plain-list">${lines}</ul>
    ${button('dismissMissed', t('dash.missedDismiss'))}
  </section>`;
}

function renderDashboard() {
  const s = store.get();
  const st = computeState(s);
  const tf = s.general.timeFormat;
  dashboardKey = stateKey(st);

  const rows = TIMETABLE.map((key) => {
    const isCurrent = key === st.current;
    const isNext = key === st.next.key && st.next.at === st.today[key];
    const hasAlarm = key !== 'sunrise' && s.alarms.enabled && s.alarms.waqt[key] && s.alarms.waqt[key].enabled;
    const bell = key === 'sunrise' ? '' : hasAlarm ? '🔔' : '🔕';
    const bellLabel = key === 'sunrise' ? '' : hasAlarm ? t('dash.alarmOn') : t('dash.alarmOff');
    return `<tr class="${isCurrent ? 'current' : ''} ${isNext ? 'next' : ''}">
      <th scope="row">${esc(t(`waqt.${key}`))}${isCurrent ? ` <span class="badge">${esc(t('dash.now'))}</span>` : ''}${isNext ? ` <span class="badge soft">${esc(t('dash.nextBadge'))}</span>` : ''}</th>
      <td class="time">${esc(fmtTime(st.today[key], tf))}</td>
      <td class="bell" title="${esc(bellLabel)}"><span aria-label="${esc(bellLabel)}">${bell}</span></td>
    </tr>`;
  }).join('');

  const hijriText = fmtHijri(hijri(st.date, s.prayer.hijriAdjust));
  const now = Date.now();
  const sehriEnd = now < st.today.fajr ? st.today.fajr : st.tomorrow.fajr;
  const iftar = now < st.today.maghrib ? st.today.maghrib : st.tomorrow.maghrib;

  const ramadanCard = st.ramadan
    ? `<section class="card ramadan-card">
        <h2>🌙 ${esc(t('ramadan.title'))}</h2>
        <div class="two-col">
          <div><div class="small-label">${esc(t('ramadan.sehriEnds'))}</div><div class="big-value">${esc(fmtTime(sehriEnd, tf))}</div></div>
          <div><div class="small-label">${esc(t('ramadan.iftar'))}</div><div class="big-value">${esc(fmtTime(iftar, tf))}</div></div>
        </div>
      </section>`
    : '';

  return `
    ${missedBanner()}
    <section class="hero" aria-live="off">
      <div>
        <div class="hero-label">${esc(t('dash.next'))}</div>
        <div class="hero-waqt">${esc(t(`waqt.${st.next.key}`))}</div>
        <div class="hero-time">${esc(fmtTime(st.next.at, tf))}</div>
      </div>
      <div class="hero-right">
        <div class="hero-label">${esc(t('dash.remaining'))}</div>
        <div class="hero-count" id="countdown">${esc(fmtCountdown(st.next.at - now))}</div>
      </div>
    </section>
    <div class="meta">
      <span>📍 ${esc(locationName(s))}</span>
      <span>📅 ${esc(fmtDate(st.date))}</span>
      ${hijriText ? `<span>☪ ${esc(hijriText)}</span>` : ''}
    </div>
    ${ramadanCard}
    <section class="card">
      <h2>${esc(t('dash.todayTitle'))}</h2>
      <table class="times">
        <thead><tr><th scope="col">${esc(t('dash.colWaqt'))}</th><th scope="col">${esc(t('dash.colTime'))}</th><th scope="col">${esc(t('dash.colAlarm'))}</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <p class="fine">${esc(t(`method.${s.prayer.method}`))} · ${esc(t(`asr.${s.prayer.asr}`))}</p>
    </section>
    ${s.alarms.enabled ? '' : notice(t('dash.alarmsOffNote'), 'warn')}
    ${notice(t('alarms.runningNote'))}`;
}

function tickDashboard() {
  const now = Date.now();
  const st = computeState(store.get(), now);
  if (stateKey(st) !== dashboardKey) {
    app.render();
    return;
  }
  const el = document.getElementById('countdown');
  if (el) el.textContent = fmtCountdown(st.next.at - now);
}

// ---------------------------------------------------------------- alarms page

const minutesOptions = (values, offLabel) =>
  values.map((v) => [v, v === 0 && offLabel ? offLabel : t('common.minutes', { n: num(v) })]);

function renderAlarms() {
  const s = store.get();
  const a = s.alarms;

  const waqtRows = PRAYERS.map(
    (key) => `<tr>
      <th scope="row">${esc(t(`waqt.${key}`))}</th>
      <td>${toggle(`alarms.waqt.${key}.enabled`, a.waqt[key].enabled).replace('<input', `<input aria-label="${esc(t('alarms.colAlarm'))}: ${esc(t(`waqt.${key}`))}"`)}</td>
      <td>${select(`alarms.waqt.${key}.pre`, minutesOptions([0, 5, 10, 15, 20, 30], t('alarms.preOff')), a.waqt[key].pre, 'int').replace('<select', `<select aria-label="${esc(t('alarms.colPre'))}: ${esc(t(`waqt.${key}`))}"`)}</td>
    </tr>`,
  ).join('');

  const soundOptions = [
    ['chime', t('sound.chime')],
    ['bell', t('sound.bell')],
    ['beep', t('sound.beep')],
    ['custom', t('sound.custom')],
  ];
  const fileName = a.customPath ? a.customPath.split(/[\\/]/).pop() : t('sound.noFile');

  return `
    ${notice(t('alarms.runningNote'), 'warn')}
    ${card(
      t('alarms.title'),
      `${row(t('alarms.master'), toggle('alarms.enabled', a.enabled), t('alarms.masterHint'))}
       <table class="times alarm-table">
         <thead><tr><th scope="col">${esc(t('dash.colWaqt'))}</th><th scope="col">${esc(t('alarms.colAlarm'))}</th><th scope="col">${esc(t('alarms.colPre'))}</th></tr></thead>
         <tbody>${waqtRows}</tbody>
       </table>
       <p class="fine">${esc(t('alarms.preHint'))}</p>`,
    )}
    ${card(
      t('sound.title'),
      `${row(t('sound.choose'), select('alarms.sound', soundOptions, a.sound), t('sound.builtinHint'))}
       ${row(t('sound.file'), `<span class="file-name" title="${esc(a.customPath)}">${esc(fileName)}</span> ${button('chooseSound', t('sound.pick'))}`, t('sound.fileHint'))}
       ${row(t('sound.volume'), `<input type="range" class="range" min="0" max="100" step="5" data-bind="alarms.volume" data-type="int" value="${esc(a.volume)}"> <span class="range-value">${esc(num(a.volume))}%</span>`)}
       ${row(t('sound.test'), `${button('testSound', t('sound.testBtn'))} ${button('stopSound', t('sound.stopBtn'))}`)}
       ${row(t('alarms.snooze'), select('alarms.snoozeMinutes', minutesOptions([3, 5, 10, 15]), a.snoozeMinutes, 'int'))}
       ${row(t('alarms.testNotif'), button('testNotification', t('alarms.testNotifBtn')), t('alarms.testNotifHint'))}`,
    )}
    ${card(
      `🌙 ${t('ramadan.title')}`,
      `${row(t('ramadan.mode'), select('ramadan.mode', [['auto', t('ramadan.modeAuto')], ['on', t('ramadan.modeOn')], ['off', t('ramadan.modeOff')]], s.ramadan.mode), t('ramadan.modeHint'))}
       ${row(t('ramadan.sehriAlarm'), toggle('ramadan.sehriAlarm', s.ramadan.sehriAlarm))}
       ${row(t('ramadan.sehriBefore'), select('ramadan.sehriBefore', minutesOptions([10, 15, 20, 30, 45, 60]), s.ramadan.sehriBefore, 'int'), t('ramadan.sehriBeforeHint'))}
       ${row(t('ramadan.iftarAlarm'), toggle('ramadan.iftarAlarm', s.ramadan.iftarAlarm), t('ramadan.iftarHint'))}`,
    )}
    ${card(
      t('wake.title'),
      `${row(t('wake.toggle'), toggle('alarms.wakeFromSleep', a.wakeFromSleep))}
       ${notice(t('wake.warning'), 'warn')}`,
    )}`;
}

// ---------------------------------------------------------------- settings + wizard parts

function calculationFields(s, withAdjust) {
  const methodOptions = METHOD_IDS.map((id) => [id, t(`method.${id}`)]);
  let html =
    row(t('calc.method'), select('prayer.method', methodOptions, s.prayer.method), t('calc.methodHint')) +
    row(t('calc.asr'), select('prayer.asr', [['hanafi', t('asr.hanafi')], ['shafi', t('asr.shafi')]], s.prayer.asr), t('calc.asrHint'));
  if (withAdjust) {
    const cells = TIMETABLE.map(
      (key) => `<label class="adjust-cell"><span>${esc(t(`waqt.${key}`))}</span>${number(`prayer.adjust.${key}`, s.prayer.adjust[key], -60, 60)}</label>`,
    ).join('');
    html += `<div class="row-label block">${esc(t('calc.adjust'))}</div>
      <div class="row-hint">${esc(t('calc.adjustHint'))}</div>
      <div class="adjust-grid">${cells}</div>
      ${row(t('calc.hijriAdjust'), select('prayer.hijriAdjust', [-2, -1, 0, 1, 2].map((v) => [v, num(v > 0 ? `+${v}` : v)]), s.prayer.hijriAdjust, 'int'), t('calc.hijriAdjustHint'))}
      ${notice(t('calc.bdNote'))}`;
  }
  return html;
}

// ---------------------------------------------------------------- module definition

const prayerModule = {
  id: 'prayer',
  titleKey: 'module.prayer',
  canDisable: true,

  pages: [
    { id: 'dashboard', icon: '🕌', titleKey: 'nav.dashboard', render: renderDashboard, tick: tickDashboard },
    { id: 'alarms', icon: '⏰', titleKey: 'nav.alarms', render: renderAlarms },
  ],

  settingsSections() {
    const s = store.get();
    return card(t('loc.title'), locationFields(s)) + card(t('calc.title'), calculationFields(s, true));
  },

  onboarding: [
    { titleKey: 'ob.locTitle', render: (s) => `<p>${esc(t('ob.locText'))}</p>${locationFields(s)}` },
    { titleKey: 'ob.calcTitle', render: (s) => `<p>${esc(t('ob.calcText'))}</p>${calculationFields(s, false)}` },
    {
      titleKey: 'ob.alarmTitle',
      render: (s) =>
        `<p>${esc(t('ob.alarmText'))}</p>${row(t('alarms.master'), toggle('alarms.enabled', s.alarms.enabled))}${notice(t('alarms.runningNote'), 'warn')}`,
    },
  ],

  actions: {
    async dismissMissed() {
      missed = [];
      await invoke('clear_missed').catch((e) => log('warn', e));
      app.render();
    },
    async testSound() {
      const result = await sound.startAlarm(store.get().alarms);
      if (result.fallback) flash(t('alarm.customFailed'), 'warn');
    },
    stopSound() {
      sound.stop();
    },
    async chooseSound() {
      const path = await pickFile(t('sound.audioFiles'), sound.AUDIO_EXTENSIONS);
      if (!path) return;
      store.set('alarms.customPath', path);
      store.set('alarms.sound', 'custom');
    },
    async testNotification() {
      await invoke('test_notification', { title: t('alarms.testNotifTitle'), body: t('alarms.testNotifBody') }).catch((e) => log('warn', e));
      flash(t('alarms.testNotifSent'));
    },
    async detectLocation() {
      flash(t('loc.detecting'));
      const ok = await detectLocation();
      flash(ok ? t('loc.detectOk') : t('loc.detectFail'), ok ? 'info' : 'warn');
    },
    alarmStop() {
      alarmUi.close();
    },
    alarmSnooze() {
      alarmUi.snooze();
    },
  },

  trayTooltip() {
    const s = store.get();
    const st = computeState(s);
    return `${t('app.name')} — ${t('dash.next')}: ${t(`waqt.${st.next.key}`)} ${fmtTime(st.next.at, s.general.timeFormat)}`;
  },

  async init(appContext) {
    app = appContext;

    await listen('alarm-fire', (item) => {
      if (!isEnabled(prayerModule)) return;
      if (item.silent) {
        sound.playOnce(store.get().alarms);
        flash(item.title);
      } else {
        alarmUi.open(item).catch((e) => log('error', e));
      }
      refreshScheduleSoon();
      app.updateTray();
    });
    await listen('alarm-missed', async () => {
      await loadAlarmState();
      app.render();
    });
    await listen('time-jump', () => {
      // The PC woke up or the clock/time zone changed: recalculate everything.
      refreshScheduleSoon();
      app.render();
      app.updateTray();
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && alarmUi.isOpen()) alarmUi.close();
    });

    await refreshSchedule();
    const st = await loadAlarmState();
    if (st && st.active && isEnabled(prayerModule)) alarmUi.open(st.active).catch((e) => log('error', e));
  },

  onSettingsChanged() {
    refreshScheduleSoon();
  },

  tick(now) {
    if (ymd(new Date(now)) !== lastDay || now - lastRefresh > REFRESH_EVERY_MS) {
      refreshSchedule().then(() => app.updateTray());
    }
  },
};

export default prayerModule;
