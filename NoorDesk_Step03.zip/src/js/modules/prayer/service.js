// Turns settings into prayer times, the Hijri date, the "what is next" state
// and the list of alarms handed to the backend scheduler.

import { fmtTime, lang, num, t } from '../../core/i18n.js';
import { ymd } from '../../core/util.js';
import { findCity } from './cities.js';
import { computeTimes } from './engine.js';
import { PRAYERS } from './methods.js';

const HIJRI_MONTHS = {
  en: ['Muharram', 'Safar', "Rabi' al-Awwal", "Rabi' al-Thani", 'Jumada al-Ula', 'Jumada al-Akhirah', 'Rajab', "Sha'ban", 'Ramadan', 'Shawwal', "Dhu al-Qi'dah", 'Dhu al-Hijjah'],
  bn: ['মুহাররম', 'সফর', 'রবিউল আউয়াল', 'রবিউস সানি', 'জমাদিউল আউয়াল', 'জমাদিউস সানি', 'রজব', 'শাবান', 'রমজান', 'শাওয়াল', 'জিলকদ', 'জিলহজ'],
};

/** How many days of alarms are handed to the scheduler at once. */
const DAYS_AHEAD = 7;

let hijriFormatter = null;

export function coords(s) {
  if (s.location.mode === 'city') {
    const city = findCity(s.location.cityId);
    if (city) return { lat: city.lat, lng: city.lng };
  }
  return { lat: Number(s.location.lat) || 0, lng: Number(s.location.lng) || 0 };
}

export function locationName(s) {
  if (s.location.mode === 'city') {
    const city = findCity(s.location.cityId);
    if (city) return lang() === 'bn' ? city.bn : city.en;
  }
  if (s.location.name) return s.location.name;
  const { lat, lng } = coords(s);
  return num(`${lat.toFixed(2)}, ${lng.toFixed(2)}`);
}

/** Hijri date (Umm al-Qura calendar) with the user's +/- day correction, or null. */
export function hijri(date, adjustDays = 0) {
  try {
    const shifted = new Date(date.getFullYear(), date.getMonth(), date.getDate() + adjustDays, 12);
    if (!hijriFormatter) {
      hijriFormatter = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura-nu-latn', {
        day: 'numeric',
        month: 'numeric',
        year: 'numeric',
      });
    }
    const parts = hijriFormatter.formatToParts(shifted);
    const pick = (type) => parseInt((parts.find((p) => p.type === type) || {}).value, 10);
    const result = { day: pick('day'), month: pick('month'), year: pick('year') };
    return result.month >= 1 && result.month <= 12 ? result : null;
  } catch {
    return null;
  }
}

export function fmtHijri(h) {
  if (!h) return '';
  return `${num(h.day)} ${HIJRI_MONTHS[lang()][h.month - 1]} ${num(h.year)} ${t('hijri.suffix')}`;
}

export function ramadanActive(s, date) {
  if (s.ramadan.mode === 'on') return true;
  if (s.ramadan.mode === 'off') return false;
  const h = hijri(date, s.prayer.hijriAdjust);
  return !!h && h.month === 9;
}

/** Prayer times for the calendar day of `date`. */
export function timesFor(s, date) {
  const { lat, lng } = coords(s);
  return computeTimes({ year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() }, lat, lng, {
    method: s.prayer.method,
    asr: s.prayer.asr,
    adjust: s.prayer.adjust,
    ramadan: ramadanActive(s, date),
  });
}

const dayOffset = (date, offset) => new Date(date.getFullYear(), date.getMonth(), date.getDate() + offset);

/** Everything the dashboard needs for "now". */
export function computeState(s, now = Date.now()) {
  const date = new Date(now);
  const today = timesFor(s, date);
  const tomorrow = timesFor(s, dayOffset(date, 1));

  const sequence = [...PRAYERS.map((key) => ({ key, at: today[key] })), { key: 'fajr', at: tomorrow.fajr }];
  const next = sequence.find((x) => x.at > now) || sequence[sequence.length - 1];

  let current = null;
  if (now < today.fajr) current = 'isha';
  else if (now < today.sunrise) current = 'fajr';
  else if (now < today.dhuhr) current = null; // between sunrise and Dhuhr no prayer is "current"
  else if (now < today.asr) current = 'dhuhr';
  else if (now < today.maghrib) current = 'asr';
  else if (now < today.isha) current = 'maghrib';
  else current = 'isha';

  return { date, today, tomorrow, next, current, ramadan: ramadanActive(s, date) };
}

/** The alarms for the next few days, with the notification text already translated. */
export function buildAlarmItems(s, now = Date.now()) {
  if (!s.alarms.enabled) return [];
  const place = locationName(s);
  const tf = s.general.timeFormat;
  const items = [];
  const base = new Date(now);

  for (let offset = 0; offset < DAYS_AHEAD; offset++) {
    const date = dayOffset(base, offset);
    const day = ymd(date);
    const times = timesFor(s, date);
    const ramadan = ramadanActive(s, date);

    for (const key of PRAYERS) {
      const cfg = s.alarms.waqt[key] || {};
      const at = times[key];
      const name = t(`waqt.${key}`);
      const body = t('alarm.body', { time: fmtTime(at, tf), place });
      const isIftar = ramadan && s.ramadan.iftarAlarm && key === 'maghrib';

      if (cfg.enabled || isIftar) {
        items.push({
          id: `${day}:${key}:main`,
          at,
          kind: isIftar ? 'iftar' : 'main',
          waqt: key,
          title: isIftar ? t('alarm.iftarTitle') : t('alarm.title', { waqt: name }),
          body,
          missedBody: t('alarm.missed', { waqt: isIftar ? t('ramadan.iftar') : name, time: fmtTime(at, tf) }),
          silent: false,
        });
      }

      const pre = Number(cfg.pre) || 0;
      if (cfg.enabled && pre > 0) {
        items.push({
          id: `${day}:${key}:pre`,
          at: at - pre * 60000,
          kind: 'pre',
          waqt: key,
          title: t('alarm.preTitle', { waqt: name, n: num(pre) }),
          body,
          missedBody: '',
          silent: true,
        });
      }

      if (ramadan && s.ramadan.sehriAlarm && key === 'fajr') {
        const before = Number(s.ramadan.sehriBefore) || 0;
        items.push({
          id: `${day}:sehri:main`,
          at: at - before * 60000,
          kind: 'sehri',
          waqt: 'sehri',
          title: t('alarm.sehriTitle', { n: num(before) }),
          body: t('alarm.sehriBody', { time: fmtTime(at, tf) }),
          missedBody: t('alarm.missed', { waqt: t('ramadan.sehri'), time: fmtTime(at - before * 60000, tf) }),
          silent: false,
        });
      }
    }
  }

  return items.filter((item) => item.at > now).sort((a, b) => a.at - b.at);
}
