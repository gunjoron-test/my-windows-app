// Application shell: navigation, rendering, automatic saving of settings controls.

import { invoke, log } from './core/bridge.js';
import { setLang, t } from './core/i18n.js';
import { allModules, enabledModules, enabledPages, findAction, registerModule } from './core/modules.js';
import * as onboarding from './core/onboarding.js';
import * as store from './core/store.js';
import { esc } from './core/util.js';
import blockerModule from './modules/blocker/index.js';
import coreModule from './modules/core/index.js';
import prayerModule from './modules/prayer/index.js';
import widgetsModule from './modules/widgets/index.js';

// The order here is the order in the side menu. Later steps register their modules here.
registerModule(prayerModule);
registerModule(widgetsModule);
registerModule(blockerModule);
registerModule(coreModule);

let currentPageId = null;
let lastTrayKey = '';
const darkQuery = window.matchMedia('(prefers-color-scheme: dark)');

function applyAppearance() {
  const general = store.get().general;
  setLang(general.language);
  const theme = general.theme === 'system' ? (darkQuery.matches ? 'dark' : 'light') : general.theme;
  document.documentElement.dataset.theme = theme;
  document.title = t('app.name');
}

function currentPage() {
  const pages = enabledPages();
  return pages.find((p) => p.id === currentPageId) || pages[0];
}

function render() {
  const pages = enabledPages();
  const page = currentPage();
  currentPageId = page.id;

  // Remember where the user was, so re-drawing after a change does not lose their place.
  const view = document.getElementById('view');
  const scroll = view.scrollTop;
  const active = document.activeElement;
  const focusSelector =
    active && active.dataset && active.dataset.bind
      ? `[data-bind="${active.dataset.bind}"]`
      : active && active.dataset && active.dataset.action
        ? `[data-action="${active.dataset.action}"]`
        : null;

  document.getElementById('brand-name').textContent = t('app.name');
  document.getElementById('nav').innerHTML = pages
    .map(
      (p) =>
        `<button type="button" class="nav-item ${p.id === page.id ? 'active' : ''}" data-nav="${p.id}" ${p.id === page.id ? 'aria-current="page"' : ''}>
          <span class="nav-icon" aria-hidden="true">${p.icon}</span><span>${esc(t(p.titleKey))}</span>
        </button>`,
    )
    .join('');
  document.getElementById('page-title').textContent = t(page.titleKey);

  try {
    view.innerHTML = page.render();
  } catch (e) {
    log('error', e);
    view.innerHTML = `<div class="notice warn">${esc(t('notice.pageError'))}</div>`;
  }
  document.getElementById('overlay-root').innerHTML = onboarding.render();

  view.scrollTop = scroll;
  if (focusSelector) {
    const again = document.querySelector(focusSelector);
    if (again) again.focus({ preventScroll: true });
  }
}

function updateTray() {
  let tooltip = t('app.name');
  for (const module of enabledModules()) {
    if (module.trayTooltip) {
      try {
        tooltip = module.trayTooltip();
        break;
      } catch (e) {
        log('warn', e);
      }
    }
  }
  const open = t('tray.open');
  const quit = t('tray.quit');
  const key = `${open}|${quit}|${tooltip}`;
  if (key === lastTrayKey) return; // nothing changed, do not rebuild the tray menu
  lastTrayKey = key;
  invoke('set_tray_text', { open, quit, tooltip }).catch((e) => log('warn', e));
}

/** Reads the value of a control marked with data-bind. Returns undefined if it is not valid. */
function readControl(el) {
  const type = el.dataset.type;
  if (type === 'bool') return el.checked;
  if (type === 'int' || type === 'float') {
    let value = type === 'int' ? parseInt(el.value, 10) : parseFloat(el.value);
    if (!Number.isFinite(value)) return undefined;
    if (el.min !== undefined && el.min !== '') value = Math.max(Number(el.min), value);
    if (el.max !== undefined && el.max !== '') value = Math.min(Number(el.max), value);
    return value;
  }
  if (type === 'multiline') return String(el.value).slice(0, 200000); // lists typed in a text box
  return String(el.value).slice(0, 200);
}

function wireEvents() {
  document.addEventListener('click', (event) => {
    const navButton = event.target.closest('[data-nav]');
    if (navButton) {
      currentPageId = navButton.dataset.nav;
      render();
      document.getElementById('view').scrollTop = 0;
      return;
    }
    const actionButton = event.target.closest('[data-action]');
    if (actionButton) {
      const action = findAction(actionButton.dataset.action);
      if (action) Promise.resolve(action(actionButton, event)).catch((e) => log('error', e));
    }
  });

  document.addEventListener('change', (event) => {
    const el = event.target;
    if (!el.dataset || !el.dataset.bind) return;
    const value = readControl(el);
    if (value === undefined) {
      render(); // put the previous valid value back
      return;
    }
    store.set(el.dataset.bind, value);
  });

  store.subscribe((path) => {
    applyAppearance();
    for (const module of allModules()) {
      if (module.onSettingsChanged) {
        try {
          module.onSettingsChanged(path);
        } catch (e) {
          log('error', e);
        }
      }
    }
    render();
    updateTray();
  });

  darkQuery.addEventListener('change', () => {
    applyAppearance();
  });

  window.addEventListener('error', (event) => log('error', `${event.message} @ ${event.filename}:${event.lineno}`));
  window.addEventListener('unhandledrejection', (event) => log('error', `Unhandled: ${event.reason && event.reason.message ? event.reason.message : event.reason}`));
}

function startClock() {
  let lastMinute = -1;
  setInterval(() => {
    const now = Date.now();
    try {
      const page = currentPage();
      if (page.tick && !onboarding.isOpen()) page.tick(now);
      for (const module of enabledModules()) if (module.tick) module.tick(now);
    } catch (e) {
      log('error', e);
    }
    const minute = Math.floor(now / 60000);
    if (minute !== lastMinute) {
      lastMinute = minute;
      updateTray();
    }
  }, 1000);
}

async function boot() {
  await store.load();
  applyAppearance();
  wireEvents();
  if (!store.get().onboarded) onboarding.start();
  render();

  const navigate = (pageId) => {
    currentPageId = pageId;
    render();
  };
  const appContext = { render, updateTray, navigate };
  for (const module of allModules()) {
    if (!module.init) continue;
    try {
      await module.init(appContext);
    } catch (e) {
      log('error', e);
    }
  }

  render();
  updateTray();
  startClock();
}

boot().catch((e) => {
  log('error', e);
  document.getElementById('view').textContent = 'Startup error. Please export the log from Settings.';
});
