// Module registry (plug-in style).
//
// A module is an object:
//   {
//     id: 'prayer',
//     titleKey: 'module.prayer',           // name shown in Settings > Modules
//     canDisable: true,
//     pages: [{ id, icon, titleKey, render(), tick?() }],
//     actions: { name(element, event) {} }, // handlers for data-action / data-onchange
//     init(app) {},                         // called once at startup
//     onSettingsChanged(path) {},           // called after any setting changes
//   }
// Later steps (widgets, blocker, inspector ...) only add a new folder and register here.

import * as store from './store.js';

const registry = [];

export function registerModule(module) {
  registry.push(module);
}

export const allModules = () => registry;

export const isEnabled = (module) => !module.canDisable || store.get().modules[module.id] !== false;

export const enabledModules = () => registry.filter(isEnabled);

export function enabledPages() {
  return enabledModules().flatMap((m) => m.pages || []);
}

export function findAction(name) {
  for (const module of enabledModules()) {
    if (module.actions && module.actions[name]) return module.actions[name];
  }
  return null;
}
