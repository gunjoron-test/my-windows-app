// Bengali / English text. To add another language later: add a file in ../locales and list it here.

import bn from '../locales/bn.js';
import en from '../locales/en.js';
import { pad2 } from './util.js';

const DICTS = { bn, en };
const BN_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];

let current = 'bn';

export function setLang(lang) {
  current = DICTS[lang] ? lang : 'bn';
  document.documentElement.lang = current;
}

export const lang = () => current;

/** Translated text. {name} placeholders are filled from vars. */
export function t(key, vars) {
  let text = DICTS[current][key] ?? DICTS.en[key] ?? key;
  if (vars) {
    for (const [name, value] of Object.entries(vars)) text = text.replaceAll(`{${name}}`, String(value));
  }
  return text;
}

/** Shows digits in Bengali numerals when the language is Bengali. */
export function num(value) {
  const text = String(value);
  return current === 'bn' ? text.replace(/[0-9]/g, (d) => BN_DIGITS[d]) : text;
}

/** Clock time such as "5:02 AM" or "17:02". */
export function fmtTime(ms, timeFormat) {
  if (!Number.isFinite(ms)) return '--:--';
  const d = new Date(ms);
  const h = d.getHours();
  const m = pad2(d.getMinutes());
  if (timeFormat === '24h') return num(`${pad2(h)}:${m}`);
  const h12 = h % 12 === 0 ? 12 : h % 12;
  return `${num(`${h12}:${m}`)} ${h < 12 ? 'AM' : 'PM'}`;
}

/** Remaining time as "01:22:10". */
export function fmtCountdown(ms) {
  const total = Math.max(0, Math.floor(ms / 1000));
  return num(`${pad2(Math.floor(total / 3600))}:${pad2(Math.floor((total % 3600) / 60))}:${pad2(total % 60)}`);
}

export function fmtDate(date) {
  try {
    return new Intl.DateTimeFormat(current === 'bn' ? 'bn-BD' : 'en-GB', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    }).format(date);
  } catch {
    return date.toDateString();
  }
}
