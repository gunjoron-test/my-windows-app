// Tiny HTML building blocks shared by all pages.
// Controls with data-bind="settings.path" are saved automatically by app.js.

import { esc } from './util.js';

export const card = (title, body, extraClass = '') =>
  `<section class="card ${extraClass}">${title ? `<h2>${esc(title)}</h2>` : ''}${body}</section>`;

/** One settings line: label (+ optional hint) on the left, control on the right. */
export function row(label, control, hint = '') {
  const aria = ` aria-label="${esc(label)}"`;
  const labelled = control.replace(/<(input|select)\b/, (m) => m + aria);
  return `<div class="row">
    <div class="row-text"><div class="row-label">${esc(label)}</div>${hint ? `<div class="row-hint">${esc(hint)}</div>` : ''}</div>
    <div class="row-ctl">${labelled}</div>
  </div>`;
}

export const toggle = (path, on) =>
  `<label class="switch"><input type="checkbox" data-bind="${path}" data-type="bool" ${on ? 'checked' : ''}><span class="slider"></span></label>`;

/** options: [[value, label], ...] */
export const select = (path, options, value, type = '') =>
  `<select data-bind="${path}" data-type="${type}">${options
    .map(([v, l]) => `<option value="${esc(v)}" ${String(v) === String(value) ? 'selected' : ''}>${esc(l)}</option>`)
    .join('')}</select>`;

export const number = (path, value, min, max, step = 1, type = 'int') =>
  `<input type="number" class="num" data-bind="${path}" data-type="${type}" value="${esc(value)}" min="${min}" max="${max}" step="${step}">`;

export const button = (action, label, kind = '') =>
  `<button type="button" class="btn ${kind}" data-action="${action}">${esc(label)}</button>`;

export const notice = (text, kind = 'info') => `<div class="notice ${kind}" role="note">${esc(text)}</div>`;

let toastTimer = null;

/** Short message at the bottom of the window. */
export function flash(text, kind = 'info') {
  const el = document.getElementById('flash');
  if (!el) return;
  el.textContent = text;
  el.className = `flash show ${kind}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    el.className = 'flash';
  }, 3500);
}
