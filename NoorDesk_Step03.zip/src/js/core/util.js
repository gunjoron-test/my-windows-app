// Small shared helpers.

const HTML_ESCAPES = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };

/** Makes any value safe to place inside HTML. */
export const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => HTML_ESCAPES[c]);

export const pad2 = (n) => String(n).padStart(2, '0');

export const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

export const clone = (value) => JSON.parse(JSON.stringify(value));

const isPlainObject = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);

/** Reads "a.b.c" from an object. */
export function getPath(obj, path) {
  return path.split('.').reduce((acc, key) => (acc == null ? undefined : acc[key]), obj);
}

/** Writes "a.b.c" into an object, creating missing levels. */
export function setPath(obj, path, value) {
  const keys = path.split('.');
  let target = obj;
  for (let i = 0; i < keys.length - 1; i++) {
    if (!isPlainObject(target[keys[i]])) target[keys[i]] = {};
    target = target[keys[i]];
  }
  target[keys[keys.length - 1]] = value;
}

/**
 * Lays saved values over the defaults. Unknown saved keys are kept (they may belong to a
 * module added in a later version); values of the wrong type fall back to the default.
 */
export function deepMerge(base, over) {
  if (!isPlainObject(over)) return base;
  const out = { ...base };
  for (const key of Object.keys(over)) {
    const b = base[key];
    const o = over[key];
    if (isPlainObject(b)) out[key] = deepMerge(b, o);
    else if (b === undefined || typeof b === typeof o) out[key] = o;
  }
  return out;
}

/** Date -> "2026-11-14" in local time. */
export const ymd = (date) => `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
