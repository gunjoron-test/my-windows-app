// Runs inside every desktop widget window. The window label ("widget-prayer", "widget-clock",
// "widget-next") decides which widget is drawn. Widgets only read settings; changes are sent
// to the main window, which is the single place that saves them.

import { fmtBanglaDate } from './core/bangla-date.js';
import { currentWindowLabel, emit, listen, log, startDragging, startResizing } from './core/bridge.js';
import { fmtCountdown, fmtDate, fmtTime, num, setLang, t } from './core/i18n.js';
import * as store from './core/store.js';
import { esc, pad2 } from './core/util.js';
import { TIMETABLE } from './modules/prayer/methods.js';
import { computeState, fmtHijri, hijri, locationName } from './modules/prayer/service.js';
import { WIDGET_TYPES, widgetConfig } from './modules/widgets/types.js';

const root = document.getElementById('widget');

function detectId() {
  const label = currentWindowLabel();
  const fromLabel = label && label.startsWith('widget-') ? label.slice(7) : null;
  const fromQuery = new URLSearchParams(location.search).get('type'); // browser preview only
  const id = fromLabel || fromQuery || 'prayer';
  return WIDGET_TYPES[id] ? id : 'prayer';
}

const id = detectId();
let renderKey = '';

// ---------------------------------------------------------------- the three widgets

function prayerWidget(s, st, now) {
  const tf = s.general.timeFormat;
  const rows = TIMETABLE.map((key) => {
    const isCurrent = key === st.current;
    const isNext = key === st.next.key && st.next.at === st.today[key];
    return `<li class="${isCurrent ? 'current' : ''} ${isNext ? 'next' : ''}">
      <span>${esc(t(`waqt.${key}`))}</span><b>${esc(fmtTime(st.today[key], tf))}</b>
    </li>`;
  }).join('');
  return `
    <div class="w-head"><span>📍 ${esc(locationName(s))}</span><span>${esc(fmtHijri(hijri(st.date, s.prayer.hijriAdjust)))}</span></div>
    <div class="w-nextline">
      <span>${esc(t('dash.next'))}: <b>${esc(t(`waqt.${st.next.key}`))}</b></span>
      <b class="w-count" id="w-count">${esc(fmtCountdown(st.next.at - now))}</b>
    </div>
    <ul class="w-list">${rows}</ul>`;
}

function clockParts(s, now) {
  const d = new Date(now);
  if (s.general.timeFormat === '24h') {
    return { main: num(`${pad2(d.getHours())}:${pad2(d.getMinutes())}`), seconds: num(pad2(d.getSeconds())), suffix: '' };
  }
  const h12 = d.getHours() % 12 === 0 ? 12 : d.getHours() % 12;
  return { main: num(`${h12}:${pad2(d.getMinutes())}`), seconds: num(pad2(d.getSeconds())), suffix: d.getHours() < 12 ? 'AM' : 'PM' };
}

function clockWidget(s, st, now) {
  const c = clockParts(s, now);
  return `
    <div class="w-clock"><span id="w-clock-main">${esc(c.main)}</span><span class="w-sec"><span id="w-clock-sec">${esc(c.seconds)}</span> ${esc(c.suffix)}</span></div>
    <div class="w-dates">
      <div>${esc(fmtDate(st.date))}</div>
      <div>${esc(fmtHijri(hijri(st.date, s.prayer.hijriAdjust)))}</div>
      <div>${esc(fmtBanglaDate(st.date))}</div>
    </div>`;
}

function nextWidget(s, st, now) {
  return `
    <div class="w-mini-label">${esc(t('dash.next'))}</div>
    <div class="w-mini-row">
      <div><div class="w-mini-name">${esc(t(`waqt.${st.next.key}`))}</div><div class="w-mini-time">${esc(fmtTime(st.next.at, s.general.timeFormat))}</div></div>
      <b class="w-count big" id="w-count">${esc(fmtCountdown(st.next.at - now))}</b>
    </div>`;
}

const RENDERERS = { prayer: prayerWidget, clock: clockWidget, next: nextWidget };

// ---------------------------------------------------------------- drawing

function toolbar(cfg) {
  return `<div class="w-tools">
    <button type="button" data-act="toggleLock" title="${esc(t(cfg.locked ? 'widgets.unlock' : 'widgets.lock'))}" aria-label="${esc(t(cfg.locked ? 'widgets.unlock' : 'widgets.lock'))}">${cfg.locked ? '🔒' : '🔓'}</button>
    <button type="button" data-act="settings" title="${esc(t('widgets.openSettings'))}" aria-label="${esc(t('widgets.openSettings'))}">⚙</button>
    <button type="button" data-act="hide" title="${esc(t('widgets.hide'))}" aria-label="${esc(t('widgets.hide'))}">✕</button>
  </div>`;
}

function keyFor(s, st, cfg) {
  const d = st.date;
  return [id, s.general.language, s.general.timeFormat, cfg.style, cfg.locked, st.next.key, st.next.at, st.current, d.getDate(), d.getMinutes(), locationName(s)].join('|');
}

function render(force) {
  const s = store.get();
  const now = Date.now();
  const st = computeState(s, now);
  const cfg = widgetConfig(s, id);
  const key = keyFor(s, st, cfg);

  root.style.opacity = String(cfg.opacity / 100);

  if (force || key !== renderKey) {
    renderKey = key;
    root.className = `widget type-${id} style-${cfg.style} ${cfg.locked ? 'locked' : ''}`;
    root.innerHTML = `${RENDERERS[id](s, st, now)}${toolbar(cfg)}${cfg.locked ? '' : '<div class="w-grip" data-grip="1" aria-hidden="true"></div>'}`;
    return;
  }

  // Nothing changed except the running numbers: update only those.
  const count = document.getElementById('w-count');
  if (count) count.textContent = fmtCountdown(st.next.at - now);
  const sec = document.getElementById('w-clock-sec');
  if (sec) sec.textContent = clockParts(s, now).seconds;
}

async function reload() {
  await store.load();
  setLang(store.get().general.language);
  render(true);
}

// ---------------------------------------------------------------- interaction

root.addEventListener('mousedown', (event) => {
  if (event.button !== 0) return;
  if (event.target.closest('button')) return;
  if (widgetConfig(store.get(), id).locked) return;
  if (event.target.closest('[data-grip]')) startResizing();
  else startDragging();
});

root.addEventListener('click', (event) => {
  const button = event.target.closest('[data-act]');
  if (!button) return;
  emit('widget-action', { id, action: button.dataset.act }).catch((e) => log('warn', e));
});

document.addEventListener('contextmenu', (event) => event.preventDefault());

async function boot() {
  await reload();
  await listen('settings-changed', () => reload().catch((e) => log('error', e)));
  setInterval(() => {
    try {
      render(false);
    } catch (e) {
      log('error', e);
    }
  }, 1000);
}

boot().catch((e) => log('error', e));
