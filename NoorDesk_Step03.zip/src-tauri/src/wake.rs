//! Optional "wake the PC from sleep" timer (Windows waitable timer with resume).
//! This is best effort only: it depends on the hardware and on the Windows power setting
//! "Allow wake timers". It can never start a PC that is fully shut down.

#[cfg(windows)]
mod imp {
    use std::ffi::c_void;
    use std::sync::Mutex;

    #[link(name = "kernel32")]
    extern "system" {
        fn CreateWaitableTimerW(
            attributes: *mut c_void,
            manual_reset: i32,
            name: *const u16,
        ) -> *mut c_void;
        fn SetWaitableTimer(
            timer: *mut c_void,
            due_time: *const i64,
            period: i32,
            completion_routine: *mut c_void,
            completion_arg: *mut c_void,
            resume: i32,
        ) -> i32;
        fn CancelWaitableTimer(timer: *mut c_void) -> i32;
    }

    /// Timer handle stored as an integer so it can live in a static.
    static TIMER: Mutex<isize> = Mutex::new(0);

    /// Milliseconds between 1601-01-01 (Windows FILETIME epoch) and 1970-01-01 (Unix epoch).
    const EPOCH_DIFF_MS: i64 = 11_644_473_600_000;

    pub fn arm(at_unix_ms: i64) -> bool {
        let mut handle = TIMER.lock().unwrap_or_else(|e| e.into_inner());
        unsafe {
            if *handle == 0 {
                let created = CreateWaitableTimerW(std::ptr::null_mut(), 1, std::ptr::null());
                if created.is_null() {
                    return false;
                }
                *handle = created as isize;
            }
            // Positive value = absolute UTC time in 100-nanosecond units.
            let due: i64 = (at_unix_ms + EPOCH_DIFF_MS) * 10_000;
            SetWaitableTimer(
                *handle as *mut c_void,
                &due,
                0,
                std::ptr::null_mut(),
                std::ptr::null_mut(),
                1,
            ) != 0
        }
    }

    pub fn disarm() {
        let handle = TIMER.lock().unwrap_or_else(|e| e.into_inner());
        if *handle != 0 {
            unsafe {
                CancelWaitableTimer(*handle as *mut c_void);
            }
        }
    }
}

#[cfg(not(windows))]
mod imp {
    pub fn arm(_at_unix_ms: i64) -> bool {
        false
    }
    pub fn disarm() {}
}

/// Asks Windows to wake the PC at the given time. Returns false if the timer could not be set.
pub fn arm(at_unix_ms: i64) -> bool {
    imp::arm(at_unix_ms)
}

pub fn disarm() {
    imp::disarm()
}
