//! Generic alarm scheduler.
//!
//! The user interface calculates *when* things should ring (prayer times today, later also
//! reminders from other modules) and hands this service a list of timed items. A background
//! thread checks the system clock once per second, so alarms stay accurate even while the
//! window is hidden in the tray, and correct themselves after sleep/resume or clock changes.

use std::collections::HashMap;
use std::fs;
use std::sync::{Arc, Mutex, MutexGuard};
use std::thread;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use serde::{Deserialize, Serialize};
use tauri::{AppHandle, Emitter, Manager, State};
use tauri_plugin_notification::NotificationExt;

use crate::{logging, paths, wake};

/// An alarm that is at most this late still rings (e.g. the PC just woke up).
const LATE_GRACE_MS: i64 = 120_000;
/// Older alarms than this are dropped silently instead of being reported as missed.
const MISSED_WINDOW_MS: i64 = 24 * 3600 * 1000;
/// How long the ids of alarms that already rang are remembered.
const FIRED_KEEP_MS: i64 = 48 * 3600 * 1000;
/// A gap this large between two clock checks means sleep/resume or a clock change.
const TIME_JUMP_MS: i64 = 30_000;
/// The PC is woken this long before an alarm so it is fully awake when it rings.
const WAKE_LEAD_MS: i64 = 60_000;

const MAX_ITEMS: usize = 600;
const MAX_MISSED: usize = 20;

#[derive(Clone, Debug, Default, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", default)]
pub struct AlarmItem {
    /// Unique id, e.g. "2026-11-14:fajr:main".
    pub id: String,
    /// When to ring, as Unix time in milliseconds.
    pub at: i64,
    /// "main", "pre", "sehri", "iftar" or "snooze".
    pub kind: String,
    pub waqt: String,
    /// Text for the notification, already translated by the user interface.
    pub title: String,
    pub body: String,
    pub missed_body: String,
    /// Silent items only show a notification and a short sound, without the alarm popup.
    pub silent: bool,
}

#[derive(Default, Serialize, Deserialize)]
#[serde(default)]
struct Persisted {
    items: Vec<AlarmItem>,
    fired: HashMap<String, i64>,
    missed: Vec<AlarmItem>,
}

#[derive(Default)]
pub struct Scheduler {
    data: Persisted,
    /// The alarm whose popup is currently open.
    active: Option<AlarmItem>,
    wake_enabled: bool,
    last_tick: i64,
}

pub type SharedScheduler = Arc<Mutex<Scheduler>>;

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AlarmState {
    active: Option<AlarmItem>,
    missed: Vec<AlarmItem>,
    pending: usize,
    next_at: Option<i64>,
}

fn now_ms() -> i64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as i64)
        .unwrap_or(0)
}

fn lock(shared: &SharedScheduler) -> MutexGuard<'_, Scheduler> {
    shared.lock().unwrap_or_else(|e| e.into_inner())
}

fn clip(text: &str, max_chars: usize) -> String {
    text.chars().take(max_chars).collect()
}

fn sanitize(item: AlarmItem) -> AlarmItem {
    AlarmItem {
        id: clip(&item.id, 120),
        at: item.at,
        kind: clip(&item.kind, 20),
        waqt: clip(&item.waqt, 20),
        title: clip(&item.title, 120),
        body: clip(&item.body, 300),
        missed_body: clip(&item.missed_body, 300),
        silent: item.silent,
    }
}

fn load(app: &AppHandle) -> Persisted {
    fs::read_to_string(paths::schedule_file(app))
        .ok()
        .and_then(|text| serde_json::from_str::<Persisted>(&text).ok())
        .unwrap_or_default()
}

fn save(app: &AppHandle, data: &Persisted) {
    let path = paths::schedule_file(app);
    let temp = path.with_extension("json.tmp");
    match serde_json::to_string(data) {
        Ok(text) => {
            if fs::write(&temp, text.as_bytes()).is_ok() {
                let _ = fs::rename(&temp, &path);
            }
        }
        Err(e) => logging::write("WARN", &format!("Could not save schedule: {}", e)),
    }
}

/// Sets or clears the wake-from-sleep timer for the next upcoming alarm.
fn rearm_wake(scheduler: &Scheduler, now: i64) {
    if !scheduler.wake_enabled {
        wake::disarm();
        return;
    }
    let next = scheduler
        .data
        .items
        .iter()
        .filter(|i| !i.silent && i.at > now + WAKE_LEAD_MS + 30_000)
        .map(|i| i.at)
        .min();
    match next {
        Some(at) => {
            if !wake::arm(at - WAKE_LEAD_MS) {
                logging::write("WARN", "Windows refused the wake timer");
            }
        }
        None => wake::disarm(),
    }
}

/// Moves every item whose time has come out of the list and sorts it into
/// "ring now" and "missed". Must be called with the lock held.
fn process_due(scheduler: &mut Scheduler, now: i64) -> (Vec<AlarmItem>, Vec<AlarmItem>) {
    let mut to_fire: Vec<AlarmItem> = Vec::new();
    let mut missed: Vec<AlarmItem> = Vec::new();
    let mut remaining: Vec<AlarmItem> = Vec::new();

    let items = std::mem::take(&mut scheduler.data.items);
    for item in items {
        if item.at > now {
            remaining.push(item);
            continue;
        }
        if scheduler.data.fired.contains_key(&item.id) {
            continue;
        }
        scheduler.data.fired.insert(item.id.clone(), item.at);
        let late = now - item.at;
        if late <= LATE_GRACE_MS {
            to_fire.push(item);
        } else if late <= MISSED_WINDOW_MS && !item.silent {
            missed.push(item);
        }
    }
    scheduler.data.items = remaining;

    if !to_fire.is_empty() || !missed.is_empty() {
        scheduler
            .data
            .fired
            .retain(|_, at| now - *at < FIRED_KEEP_MS);
        for item in &missed {
            scheduler.data.missed.push(item.clone());
        }
        let extra = scheduler.data.missed.len().saturating_sub(MAX_MISSED);
        if extra > 0 {
            scheduler.data.missed.drain(0..extra);
        }
        if let Some(main) = to_fire.iter().find(|i| !i.silent) {
            scheduler.active = Some(main.clone());
        }
    }
    (to_fire, missed)
}

pub fn toast(app: &AppHandle, title: &str, body: &str) {
    if let Err(e) = app
        .notification()
        .builder()
        .title(title)
        .body(body)
        .show()
    {
        logging::write("WARN", &format!("Notification failed: {}", e));
    }
}

/// Brings the main window to the front, above other windows, for the alarm popup.
fn raise_for_alarm(app: &AppHandle) {
    if let Some(window) = app.get_webview_window("main") {
        let _ = window.show();
        let _ = window.unminimize();
        let _ = window.set_always_on_top(true);
        let _ = window.set_focus();
    }
}

/// Notifies the user and the interface. Must be called WITHOUT the lock held.
fn dispatch(app: &AppHandle, to_fire: Vec<AlarmItem>, missed: Vec<AlarmItem>) {
    if !missed.is_empty() {
        logging::write("INFO", &format!("{} alarm(s) missed", missed.len()));
        if let Some(last) = missed.last() {
            toast(app, &last.title, &last.missed_body);
        }
        let _ = app.emit("alarm-missed", missed.clone());
    }
    for item in to_fire {
        logging::write("INFO", &format!("Alarm fired: {}", item.id));
        toast(app, &item.title, &item.body);
        if !item.silent {
            raise_for_alarm(app);
        }
        let _ = app.emit("alarm-fire", item.clone());
    }
}

fn tick(app: &AppHandle, shared: &SharedScheduler) {
    let now = now_ms();
    let jumped;
    let (to_fire, missed);
    {
        let mut scheduler = lock(shared);
        jumped = scheduler.last_tick != 0 && (now - scheduler.last_tick).abs() > TIME_JUMP_MS;
        scheduler.last_tick = now;

        let result = process_due(&mut scheduler, now);
        to_fire = result.0;
        missed = result.1;

        if !to_fire.is_empty() || !missed.is_empty() {
            save(app, &scheduler.data);
            rearm_wake(&scheduler, now);
        }
    }

    if jumped {
        // Sleep/resume or a manual clock change: the interface recalculates everything.
        logging::write("INFO", "Clock jump detected (sleep/resume or clock change)");
        let _ = app.emit("time-jump", ());
    }
    if !to_fire.is_empty() || !missed.is_empty() {
        dispatch(app, to_fire, missed);
    }
}

/// Loads the saved schedule and starts the background clock thread.
pub fn start(app: &AppHandle) {
    let shared: SharedScheduler = Arc::new(Mutex::new(Scheduler {
        data: load(app),
        ..Default::default()
    }));
    app.manage(shared.clone());

    let handle = app.clone();
    thread::spawn(move || loop {
        thread::sleep(Duration::from_millis(1000));
        tick(&handle, &shared);
    });
}

/// Replaces the planned alarms with a fresh list from the interface.
/// Pending snoozes are kept. Returns the number of planned alarms.
#[tauri::command]
pub fn set_schedule(
    app: AppHandle,
    state: State<'_, SharedScheduler>,
    items: Vec<AlarmItem>,
    wake: bool,
) -> Result<usize, String> {
    if items.len() > MAX_ITEMS {
        return Err("Too many alarms".into());
    }
    let now = now_ms();
    let count;
    let (to_fire, missed);
    {
        let mut scheduler = lock(state.inner());

        // Handle anything already due first, so replacing the list never hides a missed alarm.
        let result = process_due(&mut scheduler, now);
        to_fire = result.0;
        missed = result.1;

        let mut next: Vec<AlarmItem> = scheduler
            .data
            .items
            .iter()
            .filter(|i| i.kind == "snooze")
            .cloned()
            .collect();
        for item in items {
            let item = sanitize(item);
            if item.id.is_empty() || item.kind == "snooze" {
                continue;
            }
            if scheduler.data.fired.contains_key(&item.id) {
                continue;
            }
            next.push(item);
        }
        next.sort_by_key(|i| i.at);

        scheduler.data.items = next;
        scheduler.wake_enabled = wake;
        count = scheduler.data.items.len();
        save(&app, &scheduler.data);
        rearm_wake(&scheduler, now);
    }
    if !to_fire.is_empty() || !missed.is_empty() {
        dispatch(&app, to_fire, missed);
    }
    Ok(count)
}

/// Adds one extra alarm (used for snooze).
#[tauri::command]
pub fn add_alarm(
    app: AppHandle,
    state: State<'_, SharedScheduler>,
    item: AlarmItem,
) -> Result<(), String> {
    let item = sanitize(item);
    if item.id.is_empty() {
        return Err("Alarm id is missing".into());
    }
    let now = now_ms();
    if item.at < now - LATE_GRACE_MS || item.at > now + 24 * 3600 * 1000 {
        return Err("Alarm time is out of range".into());
    }
    let mut scheduler = lock(state.inner());
    if scheduler.data.items.len() >= MAX_ITEMS {
        return Err("Too many alarms".into());
    }
    scheduler.data.items.push(item);
    scheduler.data.items.sort_by_key(|i| i.at);
    save(&app, &scheduler.data);
    rearm_wake(&scheduler, now);
    Ok(())
}

#[tauri::command]
pub fn get_alarm_state(state: State<'_, SharedScheduler>) -> AlarmState {
    let scheduler = lock(state.inner());
    AlarmState {
        active: scheduler.active.clone(),
        missed: scheduler.data.missed.clone(),
        pending: scheduler.data.items.len(),
        next_at: scheduler.data.items.iter().map(|i| i.at).min(),
    }
}

#[tauri::command]
pub fn clear_missed(app: AppHandle, state: State<'_, SharedScheduler>) {
    let mut scheduler = lock(state.inner());
    scheduler.data.missed.clear();
    save(&app, &scheduler.data);
}

/// Called when the user stops or snoozes the alarm popup.
#[tauri::command]
pub fn end_alarm(app: AppHandle, state: State<'_, SharedScheduler>) {
    {
        let mut scheduler = lock(state.inner());
        scheduler.active = None;
    }
    if let Some(window) = app.get_webview_window("main") {
        let _ = window.set_always_on_top(false);
    }
}
