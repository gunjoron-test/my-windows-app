//! Settings are one JSON file. The frontend owns the schema (defaults + migration), so new
//! modules can add their own section without any change here.

use std::fs;

use serde_json::Value;
use tauri::{AppHandle, Emitter};

use crate::{logging, paths};

const MAX_SETTINGS_BYTES: usize = 1_000_000;

fn read_json(path: &std::path::Path) -> Option<Value> {
    let text = fs::read_to_string(path).ok()?;
    let value: Value = serde_json::from_str(&text).ok()?;
    if value.is_object() {
        Some(value)
    } else {
        None
    }
}

/// Returns the saved settings, or null on first run. If the main file is damaged
/// (for example after a crash while writing), the backup copy is used instead.
#[tauri::command]
pub fn load_settings(app: AppHandle) -> Value {
    let main = paths::settings_file(&app);
    if let Some(value) = read_json(&main) {
        return value;
    }
    if main.exists() {
        logging::write("WARN", "settings.json is unreadable, trying the backup copy");
    }
    if let Some(value) = read_json(&paths::settings_backup_file(&app)) {
        logging::write("INFO", "Settings restored from backup");
        return value;
    }
    Value::Null
}

#[tauri::command]
pub fn save_settings(app: AppHandle, settings: Value) -> Result<(), String> {
    if !settings.is_object() {
        return Err("Settings must be a JSON object".into());
    }
    let text = serde_json::to_string_pretty(&settings).map_err(|e| e.to_string())?;
    if text.len() > MAX_SETTINGS_BYTES {
        return Err("Settings are too large".into());
    }

    let main = paths::settings_file(&app);
    let temp = main.with_extension("json.tmp");

    // Write to a temporary file first, then swap, so a crash can never leave a half-written file.
    fs::write(&temp, text.as_bytes()).map_err(|e| e.to_string())?;
    if main.exists() {
        let _ = fs::copy(&main, paths::settings_backup_file(&app));
    }
    fs::rename(&temp, &main).map_err(|e| e.to_string())?;

    // Other windows (desktop widgets) reload their settings when they hear this.
    let _ = app.emit("settings-changed", ());
    Ok(())
}
