//! Small local log file (no telemetry: the log never leaves the PC unless the user exports it).

use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::PathBuf;
use std::sync::{Mutex, OnceLock};

use tauri::AppHandle;

use crate::paths;

const MAX_LOG_BYTES: u64 = 1_000_000;
const MAX_LINE_CHARS: usize = 2_000;

static LOG_PATH: OnceLock<PathBuf> = OnceLock::new();
static WRITE_LOCK: Mutex<()> = Mutex::new(());

pub fn init(app: &AppHandle) {
    let _ = LOG_PATH.set(paths::log_dir(app).join("app.log"));

    // Record crashes so they can be diagnosed from the exported log.
    std::panic::set_hook(Box::new(|info| {
        write("PANIC", &info.to_string());
    }));
}

pub fn log_path() -> Option<PathBuf> {
    LOG_PATH.get().cloned()
}

pub fn write(level: &str, message: &str) {
    let Some(path) = LOG_PATH.get() else {
        return;
    };
    let _guard = WRITE_LOCK.lock().unwrap_or_else(|e| e.into_inner());

    // Keep the log small: when it grows past the limit, keep one old copy and start again.
    if let Ok(meta) = fs::metadata(path) {
        if meta.len() > MAX_LOG_BYTES {
            let _ = fs::rename(path, path.with_extension("old.log"));
        }
    }

    let clean: String = message
        .chars()
        .map(|c| if c == '\n' || c == '\r' { ' ' } else { c })
        .take(MAX_LINE_CHARS)
        .collect();
    let stamp = chrono::Local::now().format("%Y-%m-%d %H:%M:%S");

    if let Ok(mut file) = OpenOptions::new().create(true).append(true).open(path) {
        let _ = writeln!(file, "{} [{}] {}", stamp, level, clean);
    }
}
