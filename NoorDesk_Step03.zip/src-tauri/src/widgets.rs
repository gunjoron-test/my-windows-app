//! Module A: desktop widget windows.
//!
//! Each widget is a small frameless, transparent window that shows `widget.html`.
//! Which widgets are on, their style, opacity, lock and layer mode live in settings.json
//! (owned by the interface). Only the window position and size are remembered here, in
//! widgets.json, because they change while the user drags a widget.

use std::collections::HashMap;
use std::fs;
use std::sync::{Arc, Mutex, MutexGuard};
use std::thread;
use std::time::Duration;

use serde::{Deserialize, Serialize};
use tauri::{
    AppHandle, LogicalSize, Manager, PhysicalPosition, PhysicalSize, WebviewUrl, WebviewWindow,
    WebviewWindowBuilder,
};

use crate::{logging, paths, tray};

pub const LABEL_PREFIX: &str = "widget-";

const MIN_WIDTH: f64 = 140.0;
const MIN_HEIGHT: f64 = 70.0;
const MAX_SIZE: f64 = 1600.0;

/// Position and size of one widget window, in physical screen pixels.
#[derive(Clone, Copy, Debug, Default, Serialize, Deserialize)]
#[serde(default)]
pub struct Geometry {
    x: i32,
    y: i32,
    w: u32,
    h: u32,
    /// True once the window has reported a real position.
    placed: bool,
    /// True once the window has reported a real size.
    sized: bool,
}

#[derive(Default)]
pub struct WidgetStore {
    map: HashMap<String, Geometry>,
    dirty: bool,
}

pub type SharedWidgets = Arc<Mutex<WidgetStore>>;

fn lock(shared: &SharedWidgets) -> MutexGuard<'_, WidgetStore> {
    shared.lock().unwrap_or_else(|e| e.into_inner())
}

fn valid_id(id: &str) -> bool {
    !id.is_empty()
        && id.len() <= 30
        && id
            .chars()
            .all(|c| c.is_ascii_lowercase() || c.is_ascii_digit() || c == '-')
}

fn load(app: &AppHandle) -> HashMap<String, Geometry> {
    fs::read_to_string(paths::widgets_file(app))
        .ok()
        .and_then(|text| serde_json::from_str::<HashMap<String, Geometry>>(&text).ok())
        .unwrap_or_default()
}

fn save(app: &AppHandle, map: &HashMap<String, Geometry>) {
    let path = paths::widgets_file(app);
    let temp = path.with_extension("json.tmp");
    if let Ok(text) = serde_json::to_string_pretty(map) {
        if fs::write(&temp, text.as_bytes()).is_ok() {
            let _ = fs::rename(&temp, &path);
        }
    }
}

/// Loads saved positions and starts a small thread that writes changes to disk
/// (at most every two seconds, so dragging a widget does not hammer the disk).
pub fn start(app: &AppHandle) {
    let shared: SharedWidgets = Arc::new(Mutex::new(WidgetStore {
        map: load(app),
        dirty: false,
    }));
    app.manage(shared.clone());

    let handle = app.clone();
    thread::spawn(move || loop {
        thread::sleep(Duration::from_secs(2));
        let snapshot = {
            let mut store = lock(&shared);
            if store.dirty {
                store.dirty = false;
                Some(store.map.clone())
            } else {
                None
            }
        };
        if let Some(map) = snapshot {
            save(&handle, &map);
        }
    });
}

/// Called for every window event; remembers where widget windows are moved and resized.
pub fn handle_window_event(window: &tauri::Window, event: &tauri::WindowEvent) {
    let label = window.label().to_string();
    if !label.starts_with(LABEL_PREFIX) {
        return;
    }
    match event {
        // Alt+F4 must not remove a widget; widgets are turned off from the app.
        tauri::WindowEvent::CloseRequested { api, .. } => api.prevent_close(),
        tauri::WindowEvent::Moved(position) => {
            // Windows reports -32000 while a window is minimised; ignore that.
            if position.x > -30000 && position.y > -30000 {
                if let Some(state) = window.try_state::<SharedWidgets>() {
                    let mut store = lock(state.inner());
                    let entry = store.map.entry(label).or_default();
                    entry.x = position.x;
                    entry.y = position.y;
                    entry.placed = true;
                    store.dirty = true;
                }
            }
        }
        tauri::WindowEvent::Resized(size) => {
            if size.width >= 80 && size.height >= 40 {
                if let Some(state) = window.try_state::<SharedWidgets>() {
                    let mut store = lock(state.inner());
                    let entry = store.map.entry(label).or_default();
                    entry.w = size.width;
                    entry.h = size.height;
                    entry.sized = true;
                    store.dirty = true;
                }
            }
        }
        _ => {}
    }
}

fn saved_geometry(app: &AppHandle, label: &str) -> Option<Geometry> {
    let state = app.try_state::<SharedWidgets>()?;
    let store = lock(state.inner());
    let geometry = store.map.get(label).copied();
    geometry
}

/// True if the point is on a screen that is connected right now
/// (a saved position can point at a monitor that was unplugged).
fn on_some_monitor(window: &WebviewWindow, x: i32, y: i32) -> bool {
    match window.available_monitors() {
        Ok(monitors) if !monitors.is_empty() => monitors.iter().any(|monitor| {
            let origin = monitor.position();
            let size = monitor.size();
            x + 60 > origin.x
                && y + 20 > origin.y
                && x + 40 < origin.x + size.width as i32
                && y + 20 < origin.y + size.height as i32
        }),
        _ => true,
    }
}

fn create(app: &AppHandle, label: &str, width: f64, height: f64) -> Result<WebviewWindow, String> {
    // Read the saved place BEFORE the window exists: creating it produces move/resize events.
    let saved = saved_geometry(app, label);

    let window = WebviewWindowBuilder::new(app, label, WebviewUrl::App("widget.html".into()))
        .title("NoorDesk Widget")
        .inner_size(width, height)
        .min_inner_size(MIN_WIDTH, MIN_HEIGHT)
        .decorations(false)
        .transparent(true)
        .shadow(false)
        .skip_taskbar(true)
        .resizable(true)
        .maximizable(false)
        .minimizable(false)
        .focused(false)
        .visible(false)
        .build()
        .map_err(|e| e.to_string())?;

    if let Some(geometry) = saved {
        if geometry.sized && geometry.w >= 80 && geometry.h >= 40 {
            let _ = window.set_size(PhysicalSize::new(geometry.w, geometry.h));
        }
        if geometry.placed {
            if on_some_monitor(&window, geometry.x, geometry.y) {
                let _ = window.set_position(PhysicalPosition::new(geometry.x, geometry.y));
            } else {
                let _ = window.center();
            }
        }
    }

    let _ = window.show();
    logging::write("INFO", &format!("Widget opened: {}", label));
    Ok(window)
}

/// mode: "normal", "top" (always above other windows) or "desktop" (always behind them).
fn apply(window: &WebviewWindow, mode: &str, locked: bool) {
    if mode != "top" {
        let _ = window.set_always_on_top(false);
    }
    if mode != "desktop" {
        let _ = window.set_always_on_bottom(false);
    }
    if mode == "top" {
        let _ = window.set_always_on_top(true);
    }
    if mode == "desktop" {
        let _ = window.set_always_on_bottom(true);
    }
    let _ = window.set_resizable(!locked);
}

fn clamp_size(value: f64, min: f64) -> f64 {
    if value.is_finite() {
        value.clamp(min, MAX_SIZE)
    } else {
        min
    }
}

/// Makes the real window match the settings: opens or closes the widget and applies
/// its layer mode and lock. Safe to call again and again.
#[tauri::command]
pub async fn widget_sync(
    app: AppHandle,
    id: String,
    open: bool,
    mode: String,
    locked: bool,
    width: f64,
    height: f64,
) -> Result<(), String> {
    if !valid_id(&id) {
        return Err("Invalid widget id".into());
    }
    let label = format!("{}{}", LABEL_PREFIX, id);
    let existing = app.get_webview_window(&label);

    if !open {
        if let Some(window) = existing {
            window.destroy().map_err(|e| e.to_string())?;
            logging::write("INFO", &format!("Widget closed: {}", label));
        }
        return Ok(());
    }

    let window = match existing {
        Some(window) => window,
        None => create(
            &app,
            &label,
            clamp_size(width, MIN_WIDTH),
            clamp_size(height, MIN_HEIGHT),
        )?,
    };
    apply(&window, &mode, locked);
    Ok(())
}

/// Puts a widget back to its starting size in the middle of the screen.
#[tauri::command]
pub async fn widget_reset(app: AppHandle, id: String, width: f64, height: f64) -> Result<(), String> {
    if !valid_id(&id) {
        return Err("Invalid widget id".into());
    }
    let label = format!("{}{}", LABEL_PREFIX, id);
    if let Some(state) = app.try_state::<SharedWidgets>() {
        let mut store = lock(state.inner());
        store.map.remove(&label);
        store.dirty = true;
    }
    if let Some(window) = app.get_webview_window(&label) {
        let _ = window.set_size(LogicalSize::new(
            clamp_size(width, MIN_WIDTH),
            clamp_size(height, MIN_HEIGHT),
        ));
        let _ = window.center();
    }
    Ok(())
}

/// Lets a widget bring the main window to the front (its "settings" button).
#[tauri::command]
pub fn show_main(app: AppHandle) {
    tray::show_main_window(&app);
}
