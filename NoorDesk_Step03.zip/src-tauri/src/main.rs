// Hide the console window in release builds on Windows.
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod alarm;
mod blocker;
mod commands;
mod logging;
mod paths;
mod settings;
mod tray;
mod wake;
mod widgets;

fn main() {
    // "--minimized" is passed when Windows starts the app automatically at login.
    let start_minimized = std::env::args().any(|a| a == "--minimized");

    let app = tauri::Builder::default()
        // Must be the first plugin: a second launch only brings the first window to front.
        .plugin(tauri_plugin_single_instance::init(|app, _args, _cwd| {
            tray::show_main_window(app);
        }))
        .plugin(tauri_plugin_autostart::init(
            tauri_plugin_autostart::MacosLauncher::LaunchAgent,
            Some(vec!["--minimized"]),
        ))
        .plugin(tauri_plugin_notification::init())
        .plugin(tauri_plugin_dialog::init())
        .setup(move |app| {
            let handle = app.handle().clone();

            logging::init(&handle);
            let unclean = paths::mark_running(&handle);
            logging::write(
                "INFO",
                &format!(
                    "App started (minimized: {}, previous session clean: {})",
                    start_minimized, !unclean
                ),
            );

            tray::create(&handle)?;
            alarm::start(&handle);
            widgets::start(&handle);
            blocker::start(&handle);

            if !start_minimized {
                tray::show_main_window(&handle);
            }
            Ok(())
        })
        .on_window_event(|window, event| {
            // Widget windows: remember position/size and ignore Alt+F4.
            widgets::handle_window_event(window, event);

            // Closing the main window only hides it; the app keeps running in the tray
            // so that alarms can still ring.
            if let tauri::WindowEvent::CloseRequested { api, .. } = event {
                if window.label() == "main" {
                    api.prevent_close();
                    let _ = window.hide();
                }
            }
        })
        .invoke_handler(tauri::generate_handler![
            settings::load_settings,
            settings::save_settings,
            alarm::set_schedule,
            alarm::add_alarm,
            alarm::get_alarm_state,
            alarm::clear_missed,
            alarm::end_alarm,
            tray::set_tray_text,
            widgets::widget_sync,
            widgets::widget_reset,
            widgets::show_main,
            blocker::blocker_status,
            blocker::blocker_configure,
            blocker::blocker_enable,
            blocker::blocker_disable,
            blocker::blocker_repair,
            blocker::blocker_update,
            blocker::blocker_pause,
            blocker::blocker_clear_log,
            blocker::blocker_open_folder,
            commands::app_info,
            commands::write_log,
            commands::export_logs,
            commands::get_autostart,
            commands::set_autostart,
            commands::read_audio_file,
            commands::test_notification,
            commands::quit_app
        ])
        .build(tauri::generate_context!())
        .expect("error while building the application");

    app.run(|app_handle, event| {
        if let tauri::RunEvent::Exit = event {
            wake::disarm();
            blocker::shutdown(app_handle);
            paths::clear_running(app_handle);
            logging::write("INFO", "App exited normally");
        }
    });
}
