//! General commands the user interface can call.

use std::fs;
use std::path::PathBuf;

use serde_json::{json, Value};
use tauri::{AppHandle, Manager};
use tauri_plugin_autostart::ManagerExt;

use crate::{alarm, logging, paths};

const AUDIO_EXTENSIONS: [&str; 6] = ["mp3", "wav", "ogg", "m4a", "aac", "flac"];
const MAX_AUDIO_BYTES: u64 = 30 * 1024 * 1024;

#[tauri::command]
pub fn app_info(app: AppHandle) -> Value {
    json!({
        "version": app.package_info().version.to_string(),
        "dataDir": paths::data_dir(&app).to_string_lossy(),
        "logFile": logging::log_path().map(|p| p.to_string_lossy().to_string()),
        "uncleanPreviousExit": paths::previous_exit_was_unclean(),
    })
}

#[tauri::command]
pub fn write_log(level: String, message: String) {
    let level = match level.as_str() {
        "error" => "ERROR",
        "warn" => "WARN",
        _ => "INFO",
    };
    logging::write(level, &format!("[ui] {}", message));
}

/// Copies the log file to a place the user picked in the "Save as" dialog.
#[tauri::command]
pub fn export_logs(destination: String) -> Result<(), String> {
    let dest = PathBuf::from(&destination);
    let ext = dest
        .extension()
        .and_then(|e| e.to_str())
        .map(|e| e.to_ascii_lowercase())
        .unwrap_or_default();
    if ext != "txt" && ext != "log" {
        return Err("The log can only be saved as a .txt or .log file".into());
    }
    let source = logging::log_path().ok_or("Log file is not available")?;
    if !source.exists() {
        fs::write(&dest, b"(log is empty)\n").map_err(|e| e.to_string())?;
        return Ok(());
    }
    fs::copy(&source, &dest).map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
pub fn get_autostart(app: AppHandle) -> bool {
    app.autolaunch().is_enabled().unwrap_or(false)
}

/// Turns "Start with Windows" on or off and returns the resulting state.
#[tauri::command]
pub fn set_autostart(app: AppHandle, enabled: bool) -> Result<bool, String> {
    let manager = app.autolaunch();
    if enabled {
        manager.enable().map_err(|e| e.to_string())?;
    } else {
        // Disabling fails when it was never enabled; that is not an error for the user.
        let _ = manager.disable();
    }
    let now_enabled = manager.is_enabled().unwrap_or(false);
    logging::write("INFO", &format!("Start with Windows: {}", now_enabled));
    Ok(now_enabled)
}

/// Returns the bytes of a custom alarm sound chosen by the user.
#[tauri::command]
pub fn read_audio_file(path: String) -> Result<tauri::ipc::Response, String> {
    let file = PathBuf::from(&path);
    let ext = file
        .extension()
        .and_then(|e| e.to_str())
        .map(|e| e.to_ascii_lowercase())
        .unwrap_or_default();
    if !AUDIO_EXTENSIONS.contains(&ext.as_str()) {
        return Err("Unsupported audio file type".into());
    }
    let meta = fs::metadata(&file).map_err(|e| e.to_string())?;
    if !meta.is_file() {
        return Err("Not a file".into());
    }
    if meta.len() > MAX_AUDIO_BYTES {
        return Err("Audio file is larger than 30 MB".into());
    }
    let bytes = fs::read(&file).map_err(|e| e.to_string())?;
    Ok(tauri::ipc::Response::new(bytes))
}

#[tauri::command]
pub fn test_notification(app: AppHandle, title: String, body: String) {
    let clip = |s: &str, n: usize| s.chars().take(n).collect::<String>();
    alarm::toast(&app, &clip(&title, 120), &clip(&body, 300));
}

#[tauri::command]
pub fn quit_app(app: AppHandle) {
    app.exit(0);
}
